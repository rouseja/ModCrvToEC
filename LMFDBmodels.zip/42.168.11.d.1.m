
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 42.168.11.d.1

// Other names and/or labels
// Cummins-Pauli label: 42A11
// Rouse-Sutherland-Zureick-Brown label: 42.168.11.3

// Group data
level := 42;
// Elements that, together with Gamma(level), generate the group
gens := [[0, 31, 17, 36], [8, 33, 33, 19], [14, 1, 29, 5], [17, 29, 28, 11]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 168;

// Curve data
conductor := [[2, 16], [3, 13], [7, 18]];
bad_primes := [2, 3, 7];
// Genus
g := 11;
// Rank
r := 3
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 4
;// Number of rational cusps
Nrat_cusps := 1
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["21.84.3.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r,s,a,b> := PolynomialRing(Rationals(), 11);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [z*w-z*v-z*s+t*s-v*s,z*t-z*b-w*t+w*v,z*w+z*t+z*v+w^2-w*t-w*r+t*s+v*r-v*s-r*s,z*s-w*r+u*s-v*r-v*s-r*s-r*b+s^2+s*b,z^2-z*w-z*t-z*v+w*r+u^2-u*v+u*s+u*b,z^2-z*w-z*t-z*u-z*v-z*r+t*r-v*r,z*t-w*t+w*u-t*v-t*b+u^2-u*v+u*b+v*r,w*t-w*r+t*v+t*s+t*b-u*s+v*r-v*s-r*s,z^2+z*v+w^2-w*r-t*v-t*b+u*r,w^2-w*v-w*s+t*s-s*b,z*w-z*v+w*u+w*s+u*v+u*s+u*b,z*s-w*r-w*s-t*s-u*s+v*r-v*s,z*t+z*v-w*t-w*u+t*v-t*b+u*r-u*b-v*r+v*s,z*w-w^2-w*t-w*u-w*v-w*r+t*r-r*b,z^2-z*t+z*u-z*v-z*r-w^2-w*t-w*u+w*r-t*u+t*r-u*v,z*w+z*t-z*r+w^2-w*r-t^2-t*u-t*v+t*r-u^2+u*v-v*s,z*s+w^2-w*t+w*b+t*v-t*s+u*s+v^2,z*t-z*r+w*r+t*u-t*v+t*r+t*s+t*b-r^2,x*z-x*t-x*v+x*r-x*s+y*w+y*u,x*z-x*w-x*u+x*v-x*r-x*b-y*w-y*u-y*v,2*x*z-x*w+x*r+x*s-y*z+y*t,x*w-x*t-x*u+x*v-x*r+x*s+y*z-y*w-y*t,2*x*w+x*u-x*r+2*x*b-y*v-v*a,x*z+x*w+x*t-x*r-x*s-x*b-y*z+y*t-y*v-z*a+t*a,2*x*z+x*t+x*u-x*v-x*r+y*w-u*a,2*y*t-y*u-y*r+y*s+z*a-t*a+s*a,x*u-2*x*v-x*r+x*s-y*w-w*a,x*z+x*w+x*t+x*u+x*r-x*s+x*b-y*z-y*u+y*v+2*y*r+t*a+s*a,x*z-x*w-x*t-x*v-x*r-x*s-2*y*z+y*w-y*u-y*s-z*a-r*a,x*w+2*x*r+y*z+y*t+y*u-y*r-y*s-3*y*b+z*a-t*a-u*a-2*s*a-a*b,3*x*y+x*a+2*y^2-y*a+z*w-z*v-z*r-z*b-w^2-w*u+w*b-t^2+t*u-2*t*v-t*s+u^2-u*v+u*s+v^2-v*r+2*v*b+r^2+r*b+a^2,x*y-2*x*a-4*y^2-2*y*a+z^2-z*t+z*r+z*b-w^2-w*t+w*u+w*r+w*s-2*t^2-t*r+2*t*b-u^2+u*v+2*u*r-u*s-u*b-v^2-v*r+v*s-v*b-r^2+r*s-a^2,x*y-2*x*a+5*y^2+y*a-z^2+z*w-z*t+z*r-z*s+w^2+w*t+w*r-w*s+2*t^2+t*r+u*v+u*r+2*u*b-v^2+v*s-v*b-2*r*b+s*b-a^2,4*x*y-x*a-5*y^2+3*y*a+z^2-2*z*w-z*v+z*r+z*b-w^2-w*t-w*u-w*r+w*s+w*b+t^2-t*r+t*s-t*b-u^2+u*v-2*u*r+u*s-v*r-2*v*b-2*r^2+2*r*s-s*b,2*x*y+3*x*a+4*y*a+z^2-z*w-z*t+z*u-2*z*v+z*b-w^2+w*u+w*r-2*t^2+t*u+t*r-2*t*b-u^2+2*u*v-u*r-u*b+v^2+2*v*r-3*v*b+r^2-2*r*b+s^2-a^2,7*x^2+x*y-2*x*a-y^2-y*a-z*w-z*s+w^2-w*t+w*r+2*t^2-2*t*u+t*r+t*b+u^2-u*v-v^2-v*r+v*s-v*b-2*r^2+2*r*s-s^2-a^2];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 21.84.3.a.1
//   Coordinate number 0:
map_0_coord_0 := 1*(-7*x);
//   Coordinate number 1:
map_0_coord_1 := 1*(3*y+a);
//   Coordinate number 2:
map_0_coord_2 := 1*(-y+2*a);
// Codomain equation:
map_0_codomain := [x^3*y-y^4-x^3*z-2*y^3*z+y^2*z^2+y*z^3];
