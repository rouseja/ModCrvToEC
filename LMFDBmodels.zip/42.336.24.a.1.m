
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 42.336.24.a.1

// Other names and/or labels
// Cummins-Pauli label: 42A24
// Rouse-Sutherland-Zureick-Brown label: 42.336.24.1

// Group data
level := 42;
// Elements that, together with Gamma(level), generate the group
gens := [[10, 33, 31, 32], [25, 20, 7, 31], [37, 19, 26, 19]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 336;

// Curve data
conductor := [[2, 18], [3, 46], [7, 46]];
bad_primes := [2, 3, 7];
// Genus
g := 24;
// Rank
r := 12
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 8
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-3];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["42.112.5.f.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
