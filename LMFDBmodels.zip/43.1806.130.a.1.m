
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 43.1806.130.a.1

// Other names and/or labels
// Curve name: Xns(43)
// Rouse-Sutherland-Zureick-Brown label: 43.1806.130.2
// Sutherland label: 43Cn

// Group data
level := 43;
// Elements that, together with Gamma(level), generate the group
gens := [[12, 28, 38, 12]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 1806;

// Curve data
conductor := [[43, 260]];
bad_primes := [43];
// Genus
g := 130;
// Rank
r := 60
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 42
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["43.903.60.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
