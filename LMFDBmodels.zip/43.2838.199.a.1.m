
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 43.2838.199.a.1

// Other names and/or labels
// Rouse-Sutherland-Zureick-Brown label: 43.2838.199.1
// Sutherland label: 43Ns.2.1.7

// Group data
level := 43;
// Elements that, together with Gamma(level), generate the group
gens := [[0, 24, 21, 0], [31, 0, 0, 3]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 2838;

// Curve data
conductor := [[43, 392]];
bad_primes := [43];
// Genus
g := 199;
// Rank
r := 125
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 66
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-3];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["43.946.63.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
