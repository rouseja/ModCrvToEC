
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 43.6622.468.a.1

// Other names and/or labels
// Rouse-Sutherland-Zureick-Brown label: 43.6622.468.1
// Sutherland label: 43Ns.7.1.5

// Group data
level := 43;
// Elements that, together with Gamma(level), generate the group
gens := [[0, 25, 32, 0], [39, 0, 0, 15]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 6622;

// Curve data
conductor := [[43, 924]];
bad_primes := [43];
// Genus
g := 468;
// Rank
r := 250
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 154
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["43.946.63.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
