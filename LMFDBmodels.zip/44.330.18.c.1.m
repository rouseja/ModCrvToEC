
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 44.330.18.c.1

// Other names and/or labels
// Cummins-Pauli label: 44A18
// Rouse-Sutherland-Zureick-Brown label: 44.330.18.3

// Group data
level := 44;
// Elements that, together with Gamma(level), generate the group
gens := [[19, 9, 0, 25], [19, 30, 30, 39], [39, 22, 4, 5], [39, 25, 34, 5]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 330;

// Curve data
conductor := [[2, 16], [11, 34]];
bad_primes := [2, 11];
// Genus
g := 18;
// Rank
r := 5
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 15
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["22.165.8.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
