
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 44.330.20.c.1

// Other names and/or labels
// Cummins-Pauli label: 44B20
// Rouse-Sutherland-Zureick-Brown label: 44.330.20.1

// Group data
level := 44;
// Elements that, together with Gamma(level), generate the group
gens := [[6, 13, 29, 16], [7, 34, 12, 37], [26, 11, 25, 18], [39, 38, 30, 27]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 330;

// Curve data
conductor := [[2, 42], [11, 40]];
bad_primes := [2, 11];
// Genus
g := 20;
// Rank
r := 9
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 10
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['4.6.0.d.1', '11.55.1.b.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["4.6.0.d.1", "22.165.8.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
