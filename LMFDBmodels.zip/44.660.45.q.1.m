
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 44.660.45.q.1


// Group data
level := 44;
// Elements that, together with Gamma(level), generate the group
gens := [[21, 28, 8, 1], [25, 2, 22, 19], [27, 21, 8, 17], [33, 18, 26, 11]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 660;

// Curve data
conductor := [[2, 154], [11, 90]];
bad_primes := [2, 11];
// Genus
g := 45;
// Rank
r := 28
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 15
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-3, -4];
// Modular curve is a fiber product of the following curvesfactors := ['4.12.0.e.1', '11.55.1.b.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["4.12.0.e.1", "44.220.13.m.1", "44.330.20.d.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
