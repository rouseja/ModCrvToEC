
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 44.660.45.t.1


// Group data
level := 44;
// Elements that, together with Gamma(level), generate the group
gens := [[12, 17, 43, 4], [15, 32, 24, 9], [20, 19, 37, 24], [34, 25, 5, 30]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 660;

// Curve data
conductor := [[2, 108], [11, 90]];
bad_primes := [2, 11];
// Genus
g := 45;
// Rank
r := 26
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 15
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["44.12.0.n.1", "44.330.20.d.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
