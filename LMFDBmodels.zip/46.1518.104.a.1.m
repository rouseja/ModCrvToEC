
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 46.1518.104.a.1


// Group data
level := 46;
// Elements that, together with Gamma(level), generate the group
gens := [[19, 17, 29, 2], [21, 0, 25, 25]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 1518;

// Curve data
conductor := [[2, 78], [23, 205]];
bad_primes := [2, 23];
// Genus
g := 104;
// Rank
r := 62
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 33
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-3];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["46.506.31.b.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
