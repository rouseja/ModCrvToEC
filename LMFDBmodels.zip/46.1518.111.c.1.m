
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 46.1518.111.c.1


// Group data
level := 46;
// Elements that, together with Gamma(level), generate the group
gens := [[5, 17, 9, 18], [45, 26, 19, 1]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 1518;

// Curve data
conductor := [[2, 134], [23, 218]];
bad_primes := [2, 23];
// Genus
g := 111;
// Rank
r := 54
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 33
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["23.759.44.a.1", "46.506.37.b.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
