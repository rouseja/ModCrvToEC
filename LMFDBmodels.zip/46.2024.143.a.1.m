
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 46.2024.143.a.1


// Group data
level := 46;
// Elements that, together with Gamma(level), generate the group
gens := [[35, 12, 7, 39], [36, 19, 45, 10]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 2024;

// Curve data
conductor := [[2, 164], [23, 278]];
bad_primes := [2, 23];
// Genus
g := 143;
// Rank
r := 69
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 44
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["23.1012.61.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
