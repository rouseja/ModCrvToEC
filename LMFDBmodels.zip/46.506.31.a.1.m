
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 46.506.31.a.1


// Group data
level := 46;
// Elements that, together with Gamma(level), generate the group
gens := [[17, 5, 20, 29], [25, 11, 23, 44]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 506;

// Curve data
conductor := [[2, 36], [23, 60]];
bad_primes := [2, 23];
// Genus
g := 31;
// Rank
r := 20
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 11
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["23.253.13.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
