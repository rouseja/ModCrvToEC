
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 46.552.35.b.1


// Group data
level := 46;
// Elements that, together with Gamma(level), generate the group
gens := [[12, 21, 39, 34], [28, 11, 27, 19]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 552;

// Curve data
conductor := [[2, 40], [23, 66]];
bad_primes := [2, 23];
// Genus
g := 35;
// Rank
r := 32
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 12
;// Number of rational cusps
Nrat_cusps := 1
;// CM discriminants
CM_discs := [-7, -11, -19, -43, -67];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["23.276.15.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
