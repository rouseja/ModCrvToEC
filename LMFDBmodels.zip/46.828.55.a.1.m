
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 46.828.55.a.1


// Group data
level := 46;
// Elements that, together with Gamma(level), generate the group
gens := [[29, 14, 26, 5], [29, 40, 14, 17], [31, 19, 20, 15]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 828;

// Curve data
conductor := [[2, 25], [23, 105]];
bad_primes := [2, 23];
// Genus
g := 55;
// Rank
r := 35
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 24
;// Number of rational cusps
Nrat_cusps := 2
;// CM discriminants
CM_discs := [-7, -28];
// Modular curve is a fiber product of the following curvesfactors := ['2.3.0.a.1', '23.276.15.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["2.3.0.a.1", "23.276.15.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
