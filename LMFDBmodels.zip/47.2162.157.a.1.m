
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 47.2162.157.a.1

// Other names and/or labels
// Curve name: Xns(47)
// Rouse-Sutherland-Zureick-Brown label: 47.2162.157.2
// Sutherland label: 47Cn

// Group data
level := 47;
// Elements that, together with Gamma(level), generate the group
gens := [[27, 15, 3, 27]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 2162;

// Curve data
conductor := [[47, 314]];
bad_primes := [47];
// Genus
g := 157;
// Rank
r := 73
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 46
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["47.1081.73.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
