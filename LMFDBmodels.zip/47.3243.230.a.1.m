
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 47.3243.230.a.1

// Other names and/or labels
// Rouse-Sutherland-Zureick-Brown label: 47.3243.230.1
// Sutherland label: 47Nn.1.19

// Group data
level := 47;
// Elements that, together with Gamma(level), generate the group
gens := [[22, 21, 26, 1], [32, 24, 39, 15]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 3243;

// Curve data
conductor := [[47, 456]];
bad_primes := [47];
// Genus
g := 230;
// Rank
r := 146
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 69
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-3];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["47.1081.73.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
