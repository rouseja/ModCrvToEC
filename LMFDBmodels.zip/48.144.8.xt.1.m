
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 48.144.8.xt.1

// Other names and/or labels
// Cummins-Pauli label: 48R8
// Rouse-Sutherland-Zureick-Brown label: 48.144.8.45

// Group data
level := 48;
// Elements that, together with Gamma(level), generate the group
gens := [[1, 45, 30, 35], [3, 44, 46, 21], [9, 4, 10, 15], [9, 34, 44, 21], [19, 47, 34, 1], [27, 8, 16, 3]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 144;

// Curve data
conductor := [[2, 54], [3, 8]];
bad_primes := [2, 3];
// Genus
g := 8;
// Rank
r := 3
;// Exact gonality known
gamma := 4;

// Modular data
// Number of cusps
Ncusps := 4
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["24.72.2.jo.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r> := PolynomialRing(Rationals(), 8);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x*z-x*w+y*r,x*z+x*w-y*u,z*u-w*u+z*r+w*r,z^2+z*w+z*t-z*u+z*v-u*v-z*r+u*r+v*r-r^2,z^2+w^2-t^2+t*u-u*v-v^2+t*r+v*r,z^2+w^2+z*t-z*u+w*v-u*v-w*r+t*r,2*x^2-y^2+z*r+w*r,z*t-w*t+t^2-u^2+z*v+w*v+v^2-r^2,z*w+w^2+t*u-u^2+z*v+w*v-u*v-z*r-w*r+u*r,y*w+x*t-x*u-x*v+y*v+x*r-y*r,y*z-x*t+y*t+x*u-y*u-x*v+x*r,3*x*y+z*w-w*u-t*v+u*v-z*r+t*r-u*r,3*x*y+3*y^2-z^2-z*w+w^2-z*t+z*u-t*u+u^2-z*v-v^2+z*r+v*r,2*x^2+2*y^2+z^2+2*z*w-w^2+z*t+z*u-w*u-u^2+z*v-t*v+v^2-z*r-w*r-u*r,2*x^2+2*y^2-z*w-w^2-z*t+w*t+t^2+z*u-w*u-t*u+z*v+w*v-t*v+u*v];

// Singular plane model
model_1 := [4*x^9-8*x^8*z-4*x^6*y^2*z+4*x^7*z^2-x^3*y^4*z^2+4*x^6*z^3+6*x^4*y^2*z^3+2*x^2*y^4*z^3-7*x^5*z^4-8*x^3*y^2*z^4-2*x*y^4*z^4+2*x^4*z^5+4*x^2*y^2*z^5+y^4*z^5+2*x^3*z^6-2*x*y^2*z^6-x^2*z^7];

// Maps from this modular curve, if computed

// j-invariant map from the canonical model
//   Coordinate number 0:
map_0_coord_0 := 2^6*3^3*(859392*z*v^10+75719016*z*v^9*r-849953160*z*v^8*r^2+7281644112*z*v^7*r^3-31110945408*z*v^6*r^4+86837388168*z*v^5*r^5-107747795280*z*v^4*r^6+10730272918*z*v^3*r^7+211910256756*z*v^2*r^8-84390309700*z*v*r^9-92730607566*z*r^10-1027224*w*u*v^9+3674232*w*u*v^8*r-96617952*w*u*v^7*r^2+527241456*w*u*v^6*r^3-2325749736*w*u*v^5*r^4+4849041528*w*u*v^4*r^5-7167969226*w*u*v^3*r^6+3636957854*w*u*v^2*r^7-6568931444*w*u*v*r^8+7148212000*w*u*r^9+261072*w*v^10-44862624*w*v^9*r+747916272*w*v^8*r^2-7041413808*w*v^7*r^3+40656918192*w*v^6*r^4-148927514448*w*v^5*r^5+344740449500*w*v^4*r^6-425205006728*w*v^3*r^7+92598192148*w*v^2*r^8+499263719804*w*v*r^9-396782067924*w*r^10-1545984*t*v^10+66807432*t*v^9*r-997369128*t*v^8*r^2+8509957776*t*v^7*r^3-43298546688*t*v^6*r^4+140996506344*t*v^5*r^5-277994479752*t*v^4*r^6+278198008526*t*v^3*r^7+32389422660*t*v^2*r^8-349541394623*t*v*r^9+211669199037*t*r^10+156744*u^2*v^9+32468616*u^2*v^8*r-395598096*u^2*v^7*r^2+3370262688*u^2*v^6*r^3-15271330380*u^2*v^5*r^4+45200582748*u^2*v^4*r^5-69934599926*u^2*v^3*r^6+41252148740*u^2*v^2*r^7+65958365813*u^2*v*r^8-70209815699*u^2*r^9+1258632*u*v^10-94586472*u*v^9*r+1422299664*u*v^8*r^2-12574524672*u*v^7*r^3+66337899336*u*v^6*r^4-224877000048*u*v^5*r^5+468156419358*u*v^4*r^6-506377683514*u*v^3*r^7-182823277*u*v^2*r^8+637164265507*u*v*r^9-428967170498*u*r^10-734256*v^11-49507488*v^10*r+727988904*v^9*r^2-7218528264*v^8*r^3+41760198096*v^7*r^4-160935352032*v^6*r^5+396486522392*v^5*r^6-589975335860*v^4*r^7+349132516050*v^3*r^8+322021534362*v^2*r^9-649810875425*v*r^10+297859082609*r^11);
//   Coordinate number 1:
map_0_coord_1 := 1*((v-r)*(685728*z*v^9-9488952*z*v^8*r+55808640*z*v^7*r^2-175384080*z*v^6*r^3+288769968*z*v^5*r^4-137499720*z*v^4*r^5-311156280*z*v^3*r^6+479691094*z*v^2*r^7-64587758*z*v*r^8-187571730*z*r^9+64008*w*u*v^8-650016*w*u*v^7*r+2651040*w*u*v^6*r^2-4845744*w*u*v^5*r^3+1163400*w*u*v^4*r^4+9809088*w*u*v^3*r^5-12075538*w*u*v^2*r^6-2874188*w*u*v*r^7+9467264*w*u*r^8-441360*w*v^9+8083440*w*v^8*r-63525888*w*v^7*r^2+280302480*w*v^6*r^3-746099904*w*v^5*r^4+1147906128*w*v^4*r^5-707625988*w*v^3*r^6-662762316*w*v^2*r^7+1486429912*w*v*r^8-805708908*w*r^9+685728*t*v^9-10500120*t*v^8*r+70656768*t*v^7*r^2-269616528*t*v^6*r^3+618331248*t*v^5*r^4-791460264*t*v^4*r^5+294162576*t*v^3*r^6+647548118*t*v^2*r^7-975828862*t*v*r^8+432916803*t*r^9+301896*u^2*v^8-4256208*u^2*v^7*r+25977600*u^2*v^6*r^2-87313536*u^2*v^5*r^3+165600948*u^2*v^4*r^4-142216080*u^2*v^3*r^5-55268942*u^2*v^2*r^6+225974310*u^2*v*r^7-144660589*u^2*r^8-947160*u*v^9+15243264*u*v^8*r-107607888*u*v^7*r^2+431137584*u*v^6*r^3-1043508168*u*v^5*r^4+1435619208*u*v^4*r^5-676164546*u*v^3*r^6-1035747604*u*v^2*r^7+1804540495*u*v*r^8-871181854*u*r^9-441360*v^10+8083440*v^9*r-64513512*v^8*r^2+294669360*v^7*r^3-836789088*v^6*r^4+1464428640*v^5*r^5-1336588120*v^4*r^6-76029324*v^3*r^7+1640093694*v^2*r^8-1683996216*v*r^9+606943087*r^10));

// Map from the canonical model to the plane model of modular curve with label 48.144.8.xt.1
//   Coordinate number 0:
map_1_coord_0 := 1*(x);
//   Coordinate number 1:
map_1_coord_1 := 1*(r);
//   Coordinate number 2:
map_1_coord_2 := 1*(y);
// Codomain equation:
map_1_codomain := [4*x^9-8*x^8*z-4*x^6*y^2*z+4*x^7*z^2-x^3*y^4*z^2+4*x^6*z^3+6*x^4*y^2*z^3+2*x^2*y^4*z^3-7*x^5*z^4-8*x^3*y^2*z^4-2*x*y^4*z^4+2*x^4*z^5+4*x^2*y^2*z^5+y^4*z^5+2*x^3*z^6-2*x*y^2*z^6-x^2*z^7];
