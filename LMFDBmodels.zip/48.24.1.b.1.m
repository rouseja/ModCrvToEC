
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 48.24.1.b.1

// Other names and/or labels
// Cummins-Pauli label: 16A1
// Rouse-Sutherland-Zureick-Brown label: 48.24.1.2

// Group data
level := 48;
// Elements that, together with Gamma(level), generate the group
gens := [[9, 11, 16, 35], [17, 11, 16, 47], [23, 41, 20, 15], [29, 23, 20, 13], [31, 23, 40, 25], [31, 32, 24, 43]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 24;

// Curve data
conductor := [[2, 5], [3, 2]];
bad_primes := [2, 3];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 4
;// Number of rational cusps
Nrat_cusps := 4
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["8.12.0.n.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3-y^2*z-9*x*z^2];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := 2^4*(62208*x^2*y^4*z^2+36864*x*y^6*z+314928*x*y^2*z^5+4096*y^8+531441*z^8);
//   Coordinate number 1:
map_0_coord_1 := 3^8*(z^5*y^2*x);
