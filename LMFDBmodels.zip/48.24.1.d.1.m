
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 48.24.1.d.1

// Other names and/or labels
// Cummins-Pauli label: 16A1
// Rouse-Sutherland-Zureick-Brown label: 48.24.1.3

// Group data
level := 48;
// Elements that, together with Gamma(level), generate the group
gens := [[5, 4, 16, 9], [23, 21, 4, 11], [31, 13, 12, 17], [39, 40, 40, 15], [41, 30, 16, 29]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 24;

// Curve data
conductor := [[2, 5], [3, 2]];
bad_primes := [2, 3];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 4
;// Number of rational cusps
Nrat_cusps := 2
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["8.12.0.o.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3-y^2*z+36*x*z^2];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := 2^8*(243*x^2*y^4*z^2-36*x*y^6*z+19683*x*y^2*z^5+y^8+531441*z^8);
//   Coordinate number 1:
map_0_coord_1 := 3^8*(z^5*y^2*x);
