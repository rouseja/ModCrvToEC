
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 48.24.1.f.1

// Other names and/or labels
// Cummins-Pauli label: 8D1
// Rouse-Sutherland-Zureick-Brown label: 48.24.1.11

// Group data
level := 48;
// Elements that, together with Gamma(level), generate the group
gens := [[23, 46, 8, 3], [25, 25, 12, 11], [31, 23, 0, 17], [35, 23, 38, 1], [35, 37, 34, 21]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 24;

// Curve data
conductor := [[2, 8], [3, 2]];
bad_primes := [2, 3];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 3
;// Number of rational cusps
Nrat_cusps := 1
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["8.12.0.s.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3-y^2*z-30*x*z^2-56*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := 2^4*(24*x^2*y^6-4860*x^2*y^4*z^2-1399680*x^2*y^2*z^4-69914016*x^2*z^6-276*x*y^6*z-15552*x*y^4*z^3+1714608*x*y^2*z^5+279656064*x*z^7-y^8+1536*y^6*z^2+412128*y^4*z^4+50668416*y^2*z^6+3155578560*z^8);
//   Coordinate number 1:
map_0_coord_1 := 3^4*(z^2*(x^2*y^4-432*x^2*y^2*z^2+5832*x^2*z^4-16*x*y^4*z+2052*x*y^2*z^3-23328*x*z^5+100*y^4*z^2+3456*y^2*z^4-81648*z^6));
