
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 48.24.1.f.2

// Other names and/or labels
// Cummins-Pauli label: 8D1
// Rouse-Sutherland-Zureick-Brown label: 48.24.1.9

// Group data
level := 48;
// Elements that, together with Gamma(level), generate the group
gens := [[1, 8, 42, 47], [7, 3, 14, 13], [11, 1, 28, 37], [31, 34, 22, 9], [47, 0, 0, 7]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 24;

// Curve data
conductor := [[2, 8], [3, 2]];
bad_primes := [2, 3];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 3
;// Number of rational cusps
Nrat_cusps := 1
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["8.12.0.s.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3-y^2*z-120*x*z^2+448*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := -1*(48*x^2*y^6+77760*x^2*y^4*z^2-179159040*x^2*y^2*z^4+71591952384*x^2*z^6+1104*x*y^6*z-497664*x*y^4*z^3-438939648*x*y^2*z^5+572735619072*x*z^7+y^8+12288*y^6*z^2-26376192*y^4*z^4+25942228992*y^2*z^6-12925249781760*z^8);
//   Coordinate number 1:
map_0_coord_1 := 3^4*(z^2*(x^2*y^4+3456*x^2*y^2*z^2+373248*x^2*z^4+32*x*y^4*z+32832*x*y^2*z^3+2985984*x*z^5+400*y^4*z^2-110592*y^2*z^4-20901888*z^6));
