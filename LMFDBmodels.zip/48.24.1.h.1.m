
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 48.24.1.h.1

// Other names and/or labels
// Cummins-Pauli label: 16C1
// Rouse-Sutherland-Zureick-Brown label: 48.24.1.15

// Group data
level := 48;
// Elements that, together with Gamma(level), generate the group
gens := [[3, 44, 20, 23], [5, 41, 32, 27], [41, 25, 38, 3], [41, 29, 10, 3], [43, 38, 46, 1]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 24;

// Curve data
conductor := [[2, 8], [3, 2]];
bad_primes := [2, 3];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 3
;// Number of rational cusps
Nrat_cusps := 1
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["8.12.0.v.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3-y^2*z-120*x*z^2+448*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := 1*(48*x^2*y^6+136080*x^2*y^4*z^2+22394880*x^2*y^2*z^4+846526464*x^2*z^6+1104*x*y^6*z+1368576*x*y^4*z^3+190916352*x*y^2*z^5+6772211712*x*z^7+y^8+12288*y^6*z^2-3048192*y^4*z^4-1065996288*y^2*z^6-49582264320*z^8);
//   Coordinate number 1:
map_0_coord_1 := 3^8*(z^5*(72*x^2*z+x*y^2+576*x*z^2+16*y^2*z-4032*z^3));
