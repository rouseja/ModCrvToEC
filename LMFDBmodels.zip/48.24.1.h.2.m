
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 48.24.1.h.2

// Other names and/or labels
// Cummins-Pauli label: 16C1
// Rouse-Sutherland-Zureick-Brown label: 48.24.1.16

// Group data
level := 48;
// Elements that, together with Gamma(level), generate the group
gens := [[11, 35, 30, 17], [13, 38, 4, 25], [23, 15, 42, 5], [33, 13, 46, 3], [35, 39, 8, 29]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 24;

// Curve data
conductor := [[2, 8], [3, 2]];
bad_primes := [2, 3];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 3
;// Number of rational cusps
Nrat_cusps := 1
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["8.12.0.v.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3-y^2*z-30*x*z^2-56*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := -2^8*(24*x^2*y^6-8505*x^2*y^4*z^2+174960*x^2*y^2*z^4-826686*x^2*z^6-276*x*y^6*z+42768*x*y^4*z^3-745767*x*y^2*z^5+3306744*x*z^7-y^8+1536*y^6*z^2+47628*y^4*z^4-2082024*y^2*z^6+12105045*z^8);
//   Coordinate number 1:
map_0_coord_1 := 3^8*(z^5*(18*x^2*z+x*y^2-72*x*z^2-8*y^2*z-252*z^3));
