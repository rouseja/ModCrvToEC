
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 48.24.1.i.1

// Other names and/or labels
// Cummins-Pauli label: 16D1
// Rouse-Sutherland-Zureick-Brown label: 48.24.1.8

// Group data
level := 48;
// Elements that, together with Gamma(level), generate the group
gens := [[5, 33, 6, 25], [5, 45, 22, 47], [25, 26, 40, 15], [31, 33, 14, 43], [37, 11, 34, 19]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 24;

// Curve data
conductor := [[2, 7], [3, 2]];
bad_primes := [2, 3];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 2
;// Number of rational cusps
Nrat_cusps := 2
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["8.12.0.w.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3-y^2*z+6*x*z^2+20*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := 2^8*(24*x^2*y^6+2187*x^2*y^4*z^2-87480*x^2*y^2*z^4+826686*x^2*z^6+240*x*y^6*z-11664*x*y^4*z^3+220887*x*y^2*z^5-1653372*x*z^7+y^8+1248*y^6*z^2-61236*y^4*z^4+1067256*y^2*z^6-6082047*z^8);
//   Coordinate number 1:
map_0_coord_1 := 3^8*(z^5*(18*x^2*z+x*y^2-36*x*z^2+8*y^2*z-144*z^3));
