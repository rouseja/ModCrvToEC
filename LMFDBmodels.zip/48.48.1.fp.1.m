
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 48.48.1.fp.1

// Other names and/or labels
// Cummins-Pauli label: 16H1
// Rouse-Sutherland-Zureick-Brown label: 48.48.1.115

// Group data
level := 48;
// Elements that, together with Gamma(level), generate the group
gens := [[1, 34, 40, 45], [7, 16, 10, 9], [9, 32, 46, 15], [31, 29, 0, 29], [45, 35, 46, 43]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 48;

// Curve data
conductor := [[2, 5], [3, 2]];
bad_primes := [2, 3];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 6
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["8.24.0.bi.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w> := PolynomialRing(Rationals(), 4);
// Isomorphic to P^1?
is_P1 := false;

// Embedded model
model_0 := [x*y-2*y*z+x*w,3*x^2+2*y^2-6*z^2+4*y*w-2*w^2];

// Singular plane model
model_1 := [x^4+3*x^2*y^2+4*x^3*z-6*x*y^2*z+4*x^2*z^2-3*y^2*z^2-z^4];

// Maps from this modular curve, if computed

// j-invariant map from the embedded model
//   Coordinate number 0:
map_0_coord_0 := -1*(209018880*x*z^11-19191158280*x*z^9*w^2+24365372832*x*z^7*w^4-6101139456*x*z^5*w^6+478158336*x*z^3*w^8-11613312*x*z*w^10-3791390733*y^2*z^10+25624409778*y^2*z^8*w^2-18558928872*y^2*z^6*w^4+3584136528*y^2*z^4*w^6-245256912*y^2*z^2*w^8+5474336*y^2*w^10+24894760482*y*z^10*w-30256633404*y*z^8*w^3+2215407888*y*z^6*w^5+996423840*y*z^4*w^7-115608288*y*z^2*w^9+3207232*y*w^11+295612416*z^12-16096497147*z^10*w^2+11905159518*z^8*w^4+1851705576*z^6*w^6-1015011216*z^4*w^8+89986896*z^2*w^10-2267168*w^12);
//   Coordinate number 1:
map_0_coord_1 := 1*(6804*x*z^9*w^2-145476*x*z^7*w^4+312984*x*z^5*w^6-105696*x*z^3*w^8+6720*x*z*w^10+243*y^2*z^10-29484*y^2*z^8*w^2+234063*y^2*z^6*w^4-265950*y^2*z^4*w^6+61296*y^2*z^2*w^8-3168*y^2*w^10-7290*y*z^10*w+180468*y*z^8*w^3-408726*y*z^6*w^5+70020*y*z^4*w^7+19680*y*z^2*w^9-1856*y*w^11+6561*z^10*w^2-123768*z^8*w^4+189945*z^6*w^6+9486*z^4*w^8-18672*z^2*w^10+1312*w^12);

// Map from the embedded model to the plane model of modular curve with label 48.48.1.fp.1
//   Coordinate number 0:
map_1_coord_0 := 1*(y);
//   Coordinate number 1:
map_1_coord_1 := 1*(z);
//   Coordinate number 2:
map_1_coord_2 := 1*(w);
// Codomain equation:
map_1_codomain := [x^4+3*x^2*y^2+4*x^3*z-6*x*y^2*z+4*x^2*z^2-3*y^2*z^2-z^4];
