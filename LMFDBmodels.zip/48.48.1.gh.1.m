
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 48.48.1.gh.1

// Other names and/or labels
// Cummins-Pauli label: 16H1
// Rouse-Sutherland-Zureick-Brown label: 48.48.1.141

// Group data
level := 48;
// Elements that, together with Gamma(level), generate the group
gens := [[5, 6, 32, 17], [13, 24, 0, 37], [25, 43, 28, 11], [33, 25, 34, 31], [35, 16, 2, 21]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 48;

// Curve data
conductor := [[2, 5], [3, 2]];
bad_primes := [2, 3];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 6
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["8.24.0.bq.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w> := PolynomialRing(Rationals(), 4);
// Isomorphic to P^1?
is_P1 := false;

// Embedded model
model_0 := [y^2+2*z^2-4*y*w+2*w^2,6*x^2+z*w];

// Singular plane model
model_1 := [36*x^4+2*y^2*z^2-4*y*z^3+z^4];

// Maps from this modular curve, if computed

// j-invariant map from the embedded model
//   Coordinate number 0:
map_0_coord_0 := 2^6*(432*y*z^10*w-25616*y*z^8*w^3+300416*y*z^6*w^5-1170816*y*z^4*w^7+1761024*y*z^2*w^9-887040*y*w^11-27*z^12+5256*z^10*w^2-97100*z^8*w^4+419008*z^6*w^6-402576*z^4*w^8-404352*z^2*w^10+519616*w^12);
//   Coordinate number 1:
map_0_coord_1 := 1*(z^8*(4*y*z^2*w-12*y*w^3-z^4+6*z^2*w^2+7*w^4));

// Map from the embedded model to the plane model of modular curve with label 48.48.1.gh.1
//   Coordinate number 0:
map_1_coord_0 := 1*(x);
//   Coordinate number 1:
map_1_coord_1 := 1*(1/2*y);
//   Coordinate number 2:
map_1_coord_2 := 1*(w);
// Codomain equation:
map_1_codomain := [36*x^4+2*y^2*z^2-4*y*z^3+z^4];
