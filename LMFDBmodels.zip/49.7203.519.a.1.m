
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 49.7203.519.a.1


// Group data
level := 49;
// Elements that, together with Gamma(level), generate the group
gens := [[20, 42, 8, 29], [21, 30, 8, 40]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 7203;

// Curve data
conductor := [[7, 1998]];
bad_primes := [7];
// Genus
g := 519;
// Rank
r := 276
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 147
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["49.147.9.a.1", "49.1029.69.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
