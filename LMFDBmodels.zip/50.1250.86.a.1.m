
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 50.1250.86.a.1


// Group data
level := 50;
// Elements that, together with Gamma(level), generate the group
gens := [[7, 40, 0, 1], [14, 19, 3, 7]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 1250;

// Curve data
conductor := [[2, 100], [5, 323]];
bad_primes := [2, 5];
// Genus
g := 86;
// Rank
r := 32
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 25
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['2.2.0.a.1', '25.625.36.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["10.10.0.a.1", "25.625.36.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
