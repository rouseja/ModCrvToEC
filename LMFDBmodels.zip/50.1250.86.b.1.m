
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 50.1250.86.b.1


// Group data
level := 50;
// Elements that, together with Gamma(level), generate the group
gens := [[8, 5, 25, 6], [35, 18, 11, 15], [48, 29, 21, 2]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 1250;

// Curve data
conductor := [[2, 100], [5, 323]];
bad_primes := [2, 5];
// Genus
g := 86;
// Rank
r := 42
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 25
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["10.10.0.b.1", "25.625.36.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
