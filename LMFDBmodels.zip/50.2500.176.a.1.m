
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 50.2500.176.a.1


// Group data
level := 50;
// Elements that, together with Gamma(level), generate the group
gens := [[22, 39, 29, 24], [45, 42, 23, 5]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 2500;

// Curve data
conductor := [[2, 200], [5, 662]];
bad_primes := [2, 5];
// Genus
g := 176;
// Rank
r := 78
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 50
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["25.1250.76.a.1", "50.100.4.b.1", "50.500.32.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
