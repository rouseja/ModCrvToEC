
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 51.544.38.a.1


// Group data
level := 51;
// Elements that, together with Gamma(level), generate the group
gens := [[5, 29, 9, 46], [5, 48, 24, 29], [43, 22, 9, 25], [50, 48, 48, 17]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 544;

// Curve data
conductor := [[3, 26], [17, 76]];
bad_primes := [3, 17];
// Genus
g := 38;
// Rank
r := 22
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 16
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-3, -12, -27];
// Modular curve is a fiber product of the following curvesfactors := ['3.4.0.a.1', '17.136.6.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["3.4.0.a.1", "17.136.6.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
