
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 51.816.57.a.1


// Group data
level := 51;
// Elements that, together with Gamma(level), generate the group
gens := [[5, 47, 44, 33], [24, 40, 34, 44], [49, 27, 39, 19]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 816;

// Curve data
conductor := [[3, 102], [17, 114]];
bad_primes := [3, 17];
// Genus
g := 57;
// Rank
r := 27
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 16
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['3.6.0.a.1', '17.136.6.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["3.6.0.a.1", "51.408.25.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
