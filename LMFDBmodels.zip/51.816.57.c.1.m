
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 51.816.57.c.1


// Group data
level := 51;
// Elements that, together with Gamma(level), generate the group
gens := [[12, 20, 28, 39], [13, 37, 37, 21], [17, 39, 48, 17]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 816;

// Curve data
conductor := [[3, 102], [17, 110]];
bad_primes := [3, 17];
// Genus
g := 57;
// Rank
r := 44
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 16
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["51.6.0.a.1", "51.408.25.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
