
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 51.816.61.b.1


// Group data
level := 51;
// Elements that, together with Gamma(level), generate the group
gens := [[2, 13, 13, 43], [25, 16, 50, 31], [33, 29, 29, 12]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 816;

// Curve data
conductor := [[3, 92], [17, 122]];
bad_primes := [3, 17];
// Genus
g := 61;
// Rank
r := 25
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 16
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['3.3.0.a.1', '17.272.15.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["17.272.15.a.1", "51.408.25.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
