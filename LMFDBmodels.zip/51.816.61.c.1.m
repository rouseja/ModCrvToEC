
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 51.816.61.c.1


// Group data
level := 51;
// Elements that, together with Gamma(level), generate the group
gens := [[4, 17, 10, 13], [38, 10, 10, 46], [39, 25, 8, 42]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 816;

// Curve data
conductor := [[3, 110], [17, 122]];
bad_primes := [3, 17];
// Genus
g := 61;
// Rank
r := 34
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 16
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-3];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["51.272.15.a.1", "51.408.25.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
