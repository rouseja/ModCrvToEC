
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 52.1456.107.t.1


// Group data
level := 52;
// Elements that, together with Gamma(level), generate the group
gens := [[25, 34, 11, 15], [35, 21, 46, 17], [45, 20, 21, 7]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 1456;

// Curve data
conductor := [[2, 350], [13, 208]];
bad_primes := [2, 13];
// Genus
g := 107;
// Rank
r := 60
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 28
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["52.364.16.b.1", "52.728.53.c.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
