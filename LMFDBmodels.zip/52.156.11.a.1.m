
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 52.156.11.a.1

// Other names and/or labels
// Cummins-Pauli label: 26A11
// Rouse-Sutherland-Zureick-Brown label: 52.156.11.1

// Group data
level := 52;
// Elements that, together with Gamma(level), generate the group
gens := [[2, 33, 49, 24], [5, 25, 45, 34], [11, 3, 34, 15], [49, 5, 22, 21]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 156;

// Curve data
conductor := [[2, 32], [13, 22]];
bad_primes := [2, 13];
// Genus
g := 11;
// Rank
r := 3
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 6
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['4.2.0.a.1', '13.78.3.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["4.2.0.a.1", "13.78.3.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r,s,a,b> := PolynomialRing(Rationals(), 11);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x*s-x*a-3*x*b+y*s+y*b+z*s-w*s+w*a+w*b-u*a-u*b-v*s-v*a-v*b-r*a,x*s+2*x*a+x*b-y*s-z*s-z*a-z*b+w*s+w*a-2*w*b+3*u*b+v*b-r*a+3*r*b,x*s+x*a-2*x*b-y*s+y*a+3*y*b-z*s-z*a+z*b+w*s+2*w*a+u*a-v*s-v*a-v*b-r*a,x*s-x*a+x*b-y*s-y*b+z*s-2*z*b-2*w*a-w*b+t*s+t*a+u*s+u*b+v*s-v*a-r*a,x*a+x*b-2*y*a-y*b-2*z*s-2*z*a-w*s-w*a-t*s-2*t*a+u*s-u*a+2*v*a+v*b+r*b,x*s+x*b-y*s-y*a+y*b-z*s-z*a-z*b-w*a-t*s+2*t*b+u*s-u*a+2*u*b-v*b-r*a+r*b,x*s-x*a+y*s+2*y*a+z*s-w*s+w*a-2*w*b-t*a-u*a+3*u*b-v*s-2*r*a,x*s-y*s-y*a+3*y*b+w*s+w*a-w*b+t*a-t*b+2*u*s+u*a+v*s-2*v*a-r*s-r*a+2*r*b,2*x*s+x*a+x*b+2*y*a-2*z*s+z*b-w*s+2*w*a-t*a+3*u*s-2*u*a-v*s+v*b-r*s-2*r*a+r*b,x*s-y*s-2*z*s+2*z*a-2*z*b-w*s-w*b+2*u*s-3*u*a-v*s+v*a-v*b-3*r*b,x*s-x*b+y*a-3*z*s+2*z*a+z*b+w*s-w*b+2*t*a-t*b-2*u*s-2*v*s+r*s-r*b,y*a-y*b-2*z*a-2*z*b+w*a+w*b-t*s+2*u*s+u*a-2*u*b-2*v*a+v*b-r*s-r*a+r*b,x*w-x*t-x*v-y^2+2*y*w+2*y*t-4*y*u+y*r+z*w+z*t-z*u+w*t+t^2-t*u-2*t*v-u^2+u*v+u*r-v*r,x*z+2*x*u-y^2-y*u+y*r+2*z*w+2*z*t-z*u+w*t-w*v+t^2-t*u+t*v+2*t*r+2*u*v-v*r-s*b+a^2-a*b,2*x*y+x*w+x*t+x*u-2*x*v+y^2+y*t+y*u-y*v+z*w+z*t-z*u-w*u+w*v+w*r+t*r+u^2-u*v-u*r,x^2+x*y-x*z+x*t+2*x*u-x*v+y^2+2*y*z-y*w-y*t+2*y*u+y*v-y*r-z^2+z*w-2*z*t+z*u+w^2-w*t-2*w*u+w*r+2*t*u+t*r-s*a+s*b-a*b,x*y-2*x*v+y^2-2*y*z-y*t-y*u-y*r+z*w+2*z*t-2*z*u+z*v+2*w*t+w*u+t^2-t*u+t*r+u^2-v^2+s*a-s*b+a*b,x^2-x*y-x*z+2*x*w-x*u+y*t-y*u-y*r+z^2-2*z*w-2*z*u+z*v-w^2+2*w*t+2*w*u-t*u-t*v-2*t*r+u^2-u*v,x*y+x*z-2*x*v+x*r+y*z+2*y*v+y*r-2*z^2-2*z*t-z*u-w*v+t^2-t*u-4*t*v-2*u^2-u*v+u*r-v*r-2*s*a-a^2+a*b,x^2-2*x*y-2*x*z-2*x*t-2*x*u+x*v+x*r+3*y*z+y*w+2*y*t-2*y*u+y*v-y*r+2*z^2+2*z*t+z*u+w*u+w*v-w*r-2*u^2-v^2+r^2,2*x*y+x*z+2*x*t-x*u-x*v-x*r+2*y^2-y*t-y*u-y*v+2*z^2+z*t+z*u+w^2-w*u+t*u+t*v+t*r-u^2+2*u*v+2*u*r-r^2+2*s*a+s*b,x^2-3*x*y-x*z+x*w+x*u+x*v-y^2-2*y*z-y*t-y*v-z^2-2*z*t+z*u-z*v-w*t-w*u-t^2-t*v-u^2-u*v+v^2-v*r+s^2-3*s*a+s*b,2*x*y+x*z+2*x*w-x*u-2*x*v-x*r+y^2+2*y*z+2*y*w-y*u+y*v+y*r+z^2-z*u-w^2+w*t+w*u-w*v-w*r-t*u-t*r+u^2+u*v+u*r-v^2-v*r-r^2,x*y+x*w+x*u+x*r+y^2-y*t-y*u+3*y*r+2*z*w-z*v+w^2-2*w*u-t*v+t*r-u^2+u*v-v*r-3*s*a+s*b+a^2+a*b,x^2-2*x*y+x*w-x*t+2*x*u+x*v-y^2+2*y*z+y*w+2*y*t-2*y*u-2*z^2+z*w-2*z*t-z*v+w*v-t*u-2*t*v-t*r+u*r-2*s*a-a^2+a*b,2*x^2-x*y-x*u+2*x*v+x*r-y*z+y*w-2*y*u-y*v-y*r+2*z^2+2*z*t-z*u+z*v-w^2+w*t+w*u-w*v-t*u+t*v+2*t*r-3*u^2+u*v+v^2-v*r+r^2+s*a+s*b+a^2-2*a*b,x*y-x*z+x*w+x*t+x*u-3*x*v+y^2-y*z-3*y*w-y*t+y*u-y*v-z*t+z*v+w^2+w*r-2*t*v+t*r-u^2+2*u*r+v^2-r^2,x*z+2*x*w-x*t+2*x*u-x*v-y^2+2*y*z-y*w+y*u+y*r-2*z^2+3*z*w-z*t-2*z*v+z*r-w*t-w*u+w*r-t*u-t*v+t*r+u^2-u*r-v*r-2*s*a-s*b,x*y+x*z+x*v-y^2-2*y*z+y*u+y*r-z^2+z*t-z*v+z*r+w*t-w*u-w*v-t*u+t*v+t*r+u^2+u*v-u*r,x^2+x*y-2*x*w-x*u+x*v+x*r+y^2-2*y*u-y*v-y*r-2*z*w-z*t+z*u+w^2-w*t+w*u-t^2+t*u+t*v+t*r-u^2+2*u*v+2*u*r+2*v*r-s^2+3*s*a-a^2+a*b,x*z-x*u+x*r-y*z+y*u-y*r-z^2+2*z*u+z*v-w*t+w*u+w*v+t*u+t*r-2*u^2-2*u*v-u*r+r^2,x^2+x*y-x*z-x*w+x*t-x*u+x*r-y*z-y*w+y*u+y*v+z^2-z*w-z*t-z*u-z*r+w^2-t^2-t*v-2*u^2-u*v+u*r+s*b-a^2+a*b,x^2-x*y+2*x*w-2*x*u+x*r-y*w+y*t+z^2+2*z*t-z*u-z*r+2*w*t+w*u-3*t*u-t*v-2*u^2+u*r-v*r,x^2+x*y-x*z+x*w-x*t+2*x*u-x*r+y*z+y*t+y*u-y*r+2*z*w+z*t-z*v-w^2+w*t+w*u+w*v+t*v+2*u^2-u*r-v^2,2*x^2-2*x*y+x*w+2*x*u+x*v+x*r-2*y^2-y*z-y*t+y*u+y*v-2*z*t+z*u-w^2+w*u-t^2-t*v-t*r+u^2-u*v+2*u*r+v^2+v*r-r^2-3*s*a+s*b-a^2,x*y+x*z+2*x*w-x*t+2*y*w-y*t+y*v+2*y*r+z^2-z*w+3*z*t-z*r+w^2-2*w*t-w*v-w*r+2*t^2-2*t*u-3*u^2+u*r-v^2-2*v*r-2*s*a+s*b+a*b-b^2];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 13.78.3.a.1
//   Coordinate number 0:
map_0_coord_0 := 1*(-s+a-2*b);
//   Coordinate number 1:
map_0_coord_1 := 1*(-2*s+a+2*b);
//   Coordinate number 2:
map_0_coord_2 := 1*(2*s+a-b);
// Codomain equation:
map_0_codomain := [x^2*y^2+x*y^3-x^3*z+2*x*y^2*z+y^3*z+2*x*y*z^2+2*x*z^3-y*z^3];
