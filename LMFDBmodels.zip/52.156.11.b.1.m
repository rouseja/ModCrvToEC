
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 52.156.11.b.1

// Other names and/or labels
// Cummins-Pauli label: 26A11
// Rouse-Sutherland-Zureick-Brown label: 52.156.11.2

// Group data
level := 52;
// Elements that, together with Gamma(level), generate the group
gens := [[3, 48, 19, 23], [14, 43, 21, 25], [19, 41, 40, 39]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 156;

// Curve data
conductor := [[2, 32], [13, 21]];
bad_primes := [2, 13];
// Genus
g := 11;
// Rank
r := 6
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 6
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["13.78.3.a.1", "52.2.0.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r,s,a,b> := PolynomialRing(Rationals(), 11);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x*s+x*b+y*s-2*y*a-z*s-z*b-w*b-u*s+v*a+v*b+r*a,x*s+x*a+y*s-y*a-y*b-z*s+z*a+z*b+w*s-w*a-2*u*s+v*b-r*b,x*b+z*s+z*a+z*b-w*a+w*b+t*s-t*b-u*s-v*s+2*v*b+r*s-r*a,x*s+x*a-y*s+z*s-2*z*b-2*w*a+t*s-t*b+u*a+u*b-v*a+v*b+r*b,x*a-x*b-y*a-2*y*b-z*a+z*b-w*s-2*w*a+2*w*b+u*s+u*a-u*b-v*a+r*a,2*x*b+y*s-2*y*a+y*b+2*z*s-z*a-w*s+2*w*b+t*b+u*a+v*a+r*s+r*a,x*s-2*y*s-z*s+z*b-2*w*a+3*w*b+t*s+t*a-v*s-r*a+r*b,2*x*s+x*a-x*b-y*s-y*a+z*s-z*b-w*s+w*a+2*w*b+t*s+u*a+u*b+v*a-v*b+r*a+r*b,y*s-y*a-y*b+z*s+z*a-w*s+2*w*a+w*b-t*s+u*a-v*a+v*b+r*a,x*b-y*a-y*b+z*s-w*s+w*a+w*b+t*s+t*a+t*b-3*u*b-v*s+2*v*a+r*s-r*a+r*b,x*s+x*b-y*s+y*b+w*s-w*a-w*b+2*t*a-t*b+2*u*a+v*s-v*a-r*s,3*x*s+x*a+y*s+y*a+w*s+w*a-2*t*s+t*a-2*u*s+u*a+u*b+v*s+v*a+v*b-r*s,2*y*z+y*w-y*u-y*v-z^2-z*w-w^2+u*r,x*y+x*z-x*r-y*z-y*w+y*v+2*z^2-z*r-w^2+w*u+u^2,x*z-x*w-x*t+x*u-x*v-y^2+y*z+y*r+2*z*t-w^2+w*t+t^2-2*t*v-t*r+u*r,x*y-2*x*z+x*u-x*v+x*r-y*z-y*w-2*y*t+y*v+z*t+w*t+t^2-t*v-u^2-u*v-u*r,x*y-x*z+x*w-y*z+y*w+y*v+z^2-2*z*w+z*t-z*r+w*v-t*u-t*r-u*r,x*y+x*z+x*t-x*v-x*r+2*y*w+2*y*t-y*u+z^2+w*u-t*u+t*v-t*r+2*u*v+u*r-v^2+v*r,x^2-x*y-2*x*w-x*t-x*r-y^2-y*z+y*t+y*u-z^2+z*w-z*t+z*r+w^2+w*t+t*u-v^2+r^2,x^2+x*y-x*t+x*u-2*x*v-x*r-2*y*z-y*t+y*u+y*v+z*t-z*v-w^2+w*t+w*u-t*v-u^2+u*v-v^2+r^2,x^2-x*z-x*w-x*t-x*u+x*v-x*r-y*z-z^2-z*v+z*r-w*t-w*v-t^2-t*v+v^2-v*r,x^2-x*y-x*z-x*w-2*x*t+x*v+y*z+y*w+y*u-2*y*v-z*w-z*v-w*t-w*u-t^2-t*u-v*r,2*x*y+x*w+x*u-x*v-x*r+y*w-y*u+y*r+z^2+z*w+z*t-z*v-w^2-w*u-t*u-t*r+u*r,x*y+x*u-x*v-y*w-y*t-2*y*u-y*v-z*t+z*v-w^2+w*t+2*w*u-w*r+t^2+u*r-v^2+v*r,x^2-x*w-x*r-y^2-y*z+y*t-y*v+z^2-z*w-z*t-w^2-w*t-w*v-t^2-t*u+t*v+u^2,x*y+x*z+x*t-x*u-x*r+y^2+y*t-y*u-2*z^2-z*t+w^2-w*t-w*v-w*r-t^2+t*v+u*v+u*r,x*z+x*w-y*z-y*w+y*u+y*v-3*z*w-z*v-z*r-u*r,y^2-y*t-y*r-z^2+z*w-z*t-z*u+z*r+w^2-w*v+t*r-u^2+u*v,x^2-x*y-x*z-x*t+x*v+y*z-y*w-y*t-y*v-y*r-z*u-z*v+w*t+t*u-t*v+t*r-v*r,2*x*y-x*z-x*w+x*t-x*r-y*u+2*y*v+z^2+z*w-2*z*t-z*v-w*t+w*u+t^2+t*u-u*v,x^2-x*z-x*t-x*u-x*r-y^2+2*y*t+y*u-y*r+z^2+z*w+z*t+z*v+w*t+w*u-w*v+w*r+t^2-t*u+t*r-u^2+2*u*r-s*a+s*b-a*b,x*z-x*w+2*x*u-x*r-y^2-y*w+y*u+y*v-z^2+z*w-z*t-z*v-z*r-2*w^2+2*w*t+w*u+w*r-t*v-t*r-u^2+v^2-2*v*r+r^2+s*b-a^2+a*b,x*z-x*w-x*u-x*v+2*x*r+y*w+y*t-y*v+y*r+2*z*w+z*u+z*v-2*z*r+2*w^2-w*u-2*w*v+2*w*r+t^2-t*v-u^2-u*v+2*u*r-r^2-2*s*a-a^2+a*b,x*w-x*t+3*x*u-3*x*r-y^2-y*z+y*u+z*t+z*u-z*v+2*w^2+2*w*u-w*v+t*v+2*u^2+u*v-v^2+r^2-s^2+2*s*a-a*b,x*y+x*w-3*x*v+x*r+y*z+y*w-y*t+2*y*u+y*v+y*r+z^2-z*w-z*u-z*r+w^2+4*w*u-w*v+2*w*r-2*t^2-t*r+u^2-u*v-v^2-v*r+2*r^2-s^2-s*a+s*b+a^2,x^2+x*w-3*x*t-x*u-x*r+y^2+2*y*z+y*t+y*u-y*v+4*y*r-z^2+2*z*t-z*u-3*z*r-w^2-w*t-2*w*v+2*w*r-t^2-t*u-t*v-t*r+u*v-u*r+2*v*r-2*r^2-2*s*b-a*b+b^2];

// Singular plane model
model_1 := [49353408*x^8*y^12-82599888384*x^6*y^14+117395055024*x^4*y^16-5115357520*x^2*y^18+4212529216*y^20-3232648224*x^8*y^11*z+925762263504*x^6*y^13*z-1502859510256*x^4*y^15*z-163005034816*x^2*y^17*z-7993576640*y^19*z+66319327464*x^8*y^10*z^2-2536828805108*x^6*y^12*z^2+6079685261000*x^4*y^14*z^2+1913781269348*x^2*y^16*z^2-105499229968*y^18*z^2-151210045324*x^8*y^9*z^3-9105999210984*x^6*y^11*z^3+5321894073444*x^4*y^13*z^3-5606816560592*x^2*y^15*z^3+179431325808*y^17*z^3-1774157024809*x^8*y^8*z^4+68583953630777*x^6*y^10*z^4-119444872546623*x^4*y^12*z^4-15712915459813*x^2*y^14*z^4+2195158074132*y^16*z^4+3702870130336*x^8*y^7*z^5-63156343146247*x^6*y^9*z^5+286263944256160*x^4*y^11*z^5+126880733032287*x^2*y^13*z^5-8128724055384*y^15*z^5+18728886289009*x^8*y^6*z^6-578918375067110*x^6*y^8*z^6+573399318667032*x^4*y^10*z^6-119421651164829*x^2*y^12*z^6-7005796577604*y^14*z^6-29572329587060*x^8*y^5*z^7+2014320498248019*x^6*y^7*z^7-4388471080071754*x^4*y^9*z^7-1067237114824257*x^2*y^11*z^7+77621753678684*y^13*z^7-20990015047092*x^8*y^4*z^8-1796824356783300*x^6*y^6*z^8+8440518163835316*x^4*y^8*z^8+4197853678851820*x^2*y^10*z^8-1767959091119*y^12*z^8+52235706805373*x^8*y^3*z^9-2202982233513867*x^6*y^5*z^9-1597512908688554*x^4*y^7*z^9-6659250495409109*x^2*y^9*z^9-943901890456486*y^11*z^9-24700937123109*x^8*y^2*z^10+5718827359473397*x^6*y^4*z^10-17957193108929828*x^4*y^6*z^10+5023770468455492*x^2*y^8*z^10+3271479609736221*y^10*z^10+848690829025*x^8*y*z^11-4392306802752544*x^6*y^3*z^11+27630186317414109*x^4*y^5*z^11-2075712459596984*x^2*y^7*z^11-5563429554670442*y^9*z^11+1155558838447*x^8*z^12+1253516362495566*x^6*y^2*z^12-15808811366685116*x^4*y^4*z^12+1450694964208295*x^2*y^6*z^12+5140028656929582*y^8*z^12+38883294105643*x^6*y*z^13+2623004413936322*x^4*y^3*z^13-941722202440643*x^2*y^5*z^13-2171288119697860*y^7*z^13-58006780106574*x^6*z^14+607949460885013*x^4*y^2*z^14+56878311701679*x^2*y^4*z^14-50502583872577*y^6*z^14-151114424453577*x^4*y*z^15+86175793338869*x^2*y^3*z^15+322718545197346*y^5*z^15-11788322623376*x^4*z^16+12064407499066*x^2*y^2*z^16-42589833300836*y^4*z^16-6329106874259*x^2*y*z^17-19607550894290*y^3*z^17-1385049404466*x^2*z^18+1790601398568*y^2*z^18+680051347024*y*z^19+38022270049*z^20];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 13.78.3.a.1
//   Coordinate number 0:
map_0_coord_0 := 1*(-s+a-2*b);
//   Coordinate number 1:
map_0_coord_1 := 1*(-2*s+a+2*b);
//   Coordinate number 2:
map_0_coord_2 := 1*(2*s+a-b);
// Codomain equation:
map_0_codomain := [x^2*y^2+x*y^3-x^3*z+2*x*y^2*z+y^3*z+2*x*y*z^2+2*x*z^3-y*z^3];

// Map from the canonical model to the plane model of modular curve with label 52.156.11.b.1
//   Coordinate number 0:
map_1_coord_0 := 1*(r);
//   Coordinate number 1:
map_1_coord_1 := 1*(a);
//   Coordinate number 2:
map_1_coord_2 := 1*(b);
// Codomain equation:
map_1_codomain := [49353408*x^8*y^12-82599888384*x^6*y^14+117395055024*x^4*y^16-5115357520*x^2*y^18+4212529216*y^20-3232648224*x^8*y^11*z+925762263504*x^6*y^13*z-1502859510256*x^4*y^15*z-163005034816*x^2*y^17*z-7993576640*y^19*z+66319327464*x^8*y^10*z^2-2536828805108*x^6*y^12*z^2+6079685261000*x^4*y^14*z^2+1913781269348*x^2*y^16*z^2-105499229968*y^18*z^2-151210045324*x^8*y^9*z^3-9105999210984*x^6*y^11*z^3+5321894073444*x^4*y^13*z^3-5606816560592*x^2*y^15*z^3+179431325808*y^17*z^3-1774157024809*x^8*y^8*z^4+68583953630777*x^6*y^10*z^4-119444872546623*x^4*y^12*z^4-15712915459813*x^2*y^14*z^4+2195158074132*y^16*z^4+3702870130336*x^8*y^7*z^5-63156343146247*x^6*y^9*z^5+286263944256160*x^4*y^11*z^5+126880733032287*x^2*y^13*z^5-8128724055384*y^15*z^5+18728886289009*x^8*y^6*z^6-578918375067110*x^6*y^8*z^6+573399318667032*x^4*y^10*z^6-119421651164829*x^2*y^12*z^6-7005796577604*y^14*z^6-29572329587060*x^8*y^5*z^7+2014320498248019*x^6*y^7*z^7-4388471080071754*x^4*y^9*z^7-1067237114824257*x^2*y^11*z^7+77621753678684*y^13*z^7-20990015047092*x^8*y^4*z^8-1796824356783300*x^6*y^6*z^8+8440518163835316*x^4*y^8*z^8+4197853678851820*x^2*y^10*z^8-1767959091119*y^12*z^8+52235706805373*x^8*y^3*z^9-2202982233513867*x^6*y^5*z^9-1597512908688554*x^4*y^7*z^9-6659250495409109*x^2*y^9*z^9-943901890456486*y^11*z^9-24700937123109*x^8*y^2*z^10+5718827359473397*x^6*y^4*z^10-17957193108929828*x^4*y^6*z^10+5023770468455492*x^2*y^8*z^10+3271479609736221*y^10*z^10+848690829025*x^8*y*z^11-4392306802752544*x^6*y^3*z^11+27630186317414109*x^4*y^5*z^11-2075712459596984*x^2*y^7*z^11-5563429554670442*y^9*z^11+1155558838447*x^8*z^12+1253516362495566*x^6*y^2*z^12-15808811366685116*x^4*y^4*z^12+1450694964208295*x^2*y^6*z^12+5140028656929582*y^8*z^12+38883294105643*x^6*y*z^13+2623004413936322*x^4*y^3*z^13-941722202440643*x^2*y^5*z^13-2171288119697860*y^7*z^13-58006780106574*x^6*z^14+607949460885013*x^4*y^2*z^14+56878311701679*x^2*y^4*z^14-50502583872577*y^6*z^14-151114424453577*x^4*y*z^15+86175793338869*x^2*y^3*z^15+322718545197346*y^5*z^15-11788322623376*x^4*z^16+12064407499066*x^2*y^2*z^16-42589833300836*y^4*z^16-6329106874259*x^2*y*z^17-19607550894290*y^3*z^17-1385049404466*x^2*z^18+1790601398568*y^2*z^18+680051347024*y*z^19+38022270049*z^20];
