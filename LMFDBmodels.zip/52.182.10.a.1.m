
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 52.182.10.a.1

// Other names and/or labels
// Cummins-Pauli label: 26A10
// Rouse-Sutherland-Zureick-Brown label: 52.182.10.1

// Group data
level := 52;
// Elements that, together with Gamma(level), generate the group
gens := [[1, 51, 30, 25], [8, 15, 37, 5], [41, 37, 6, 9]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 182;

// Curve data
conductor := [[2, 28], [13, 19]];
bad_primes := [2, 13];
// Genus
g := 10;
// Rank
r := 3
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 7
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['4.2.0.a.1', '13.91.3.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["4.2.0.a.1", "13.91.3.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r,s,a> := PolynomialRing(Rationals(), 10);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [w*u-w*v+w*r-t*r-t*a+u^2+v*a+r^2,2*x^2-2*x*z+z^2+w*t-w*u-w*r-w*s+t*v-2*v*r-v*a-r*s+r*a+s^2-a^2,x^2+y*z+w*t-2*w*u+w*v+w*s-2*t*u+3*v*r-r^2+2*r*s-r*a+s*a,x^2+x*y-y^2-y*z-w^2+w*t-3*w*u-w*v+w*r-w*s+w*a+t^2-t*u-u*s+u*a-v^2-v*s+2*r*s-r*a,x^2-x*y-2*x*z+w*r-t^2+t*u-2*u*s+u*a+v^2+v*s-2*v*a+r*s+r*a+s^2,w^2+w*u-w*s+t*u+t*v-u*r-2*u*s+u*a+v^2-3*v*r-v*a+r^2+r*a+s*a-a^2,x^2+x*y-y^2-y*z+w*t-w*u-w*r+t^2-2*t*u-t*s+t*a+u^2-u*r+u*s-u*a+r*s-r*a,x^2+y*z-w*u+w*v-w*s-2*t*u+t*v-t*r-t*s+u^2+u*v-u*r-u*a+v*s+r^2+s*a-a^2,x^2+x*y-y^2-y*z-2*w*u+w*r-t*u+t*v-t*s+u*v-2*u*r-v^2+r^2+r*s+s^2-s*a,x*y-x*z+y^2-w*t+w*u+w*r-t^2+t*u+t*r-t*s+t*a+u*s-u*a+v*s-v*a-r*s+r*a,w*t-w*u-w*v+t*u-t*v+t*r-u^2+u*s-v^2+2*v*r-v*s+2*v*a-r^2-2*r*a-s^2,x^2+x*y+x*z-y*z-z^2-2*w*u+2*w*r-w*a-t*v+t*r-t*s+t*a+u*v+u*r-v^2+v*r+v*s-r^2+r*s-2*r*a-s*a,x^2-x*z-y^2+y*z+z^2-w*u+w*v-w*r+w*a-3*t*u+t*v-t*s-u*r+u*s+v^2-v*r-v*s+r^2+r*s+s^2+s*a-a^2,x^2-x*y-2*x*z+w^2+w*u-w*a+2*u*v-u*r+u*s-2*u*a-r*s+r*a+s^2-s*a,x^2-2*x*y-z^2-w*t-w*u+2*w*r-t^2-t*u+u^2+u*r-2*u*s+2*u*a+v*r+v*a+r*s-2*r*a-s^2,x^2-x*y-2*x*z+w*u-w*v+w*s-t^2+t*u-t*v+t*r+t*s-2*u*r-u*s+v^2+r^2-r*s+r*a-s*a+a^2,x*y+2*x*z+y*z+w*t-w*u+w*r-w*a+t*v+t*s-t*a+u^2-u*a-v^2+v*a+r*s-r*a,x*z+y^2-z^2+w^2-w*t+w*u+w*v+w*s-w*a-t^2+2*t*u+t*v+t*s+t*a-u^2-u*v+u*r-u*s-v*r-r*s-s^2,x*s-x*a+y*w-y*a-z*r-z*s,x*w+x*u-x*s+y*u+y*v-y*r-y*a,x*t-x*u-x*s-y*w+y*t-y*u-y*v-y*s-z*w-z*t,x*t+x*v-2*x*r-y*u+y*v-y*r-y*a-z*r-z*s,x*u-x*v-x*r+x*s-x*a+y*w+y*t-y*u-y*v+y*r+z*t-z*u-z*v+z*r,x*t-x*u-2*x*v+x*r+y*w-y*t+2*y*u+y*v+y*s+z*u+z*v,x*w+x*u+x*s-2*x*a-y*v+y*r-y*s-z*w-z*t-z*v+z*r-z*s+z*a,x*w+x*u+x*s+y*t-y*u+y*v-y*r+y*s+z*v-z*r+z*s-z*a,2*x*u-x*v+x*s-y*t+y*r-y*s+z*t-z*u-z*v-z*s,x*w-x*u-x*v+x*r-x*s-x*a+y*w+y*t-y*u+y*v-y*a-z*w-z*u+z*v];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 13.91.3.a.1
//   Coordinate number 0:
map_0_coord_0 := 1*(-x-y);
//   Coordinate number 1:
map_0_coord_1 := 1*(-y);
//   Coordinate number 2:
map_0_coord_2 := 1*(y+z);
// Codomain equation:
map_0_codomain := [5*x^4-7*x^3*y+3*x^2*y^2+2*x*y^3+8*x^3*z-7*x^2*y*z-2*x*y^2*z+5*y^3*z+4*x^2*z^2-5*x*y*z^2+y^2*z^2-3*x*z^3+2*y*z^3];
