
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 52.182.10.b.1

// Other names and/or labels
// Cummins-Pauli label: 26A10
// Rouse-Sutherland-Zureick-Brown label: 52.182.10.2

// Group data
level := 52;
// Elements that, together with Gamma(level), generate the group
gens := [[36, 5, 5, 36], [47, 28, 17, 31]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 182;

// Curve data
conductor := [[2, 28], [13, 19]];
bad_primes := [2, 13];
// Genus
g := 10;
// Rank
r := 6
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 7
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["13.91.3.a.1", "52.2.0.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r,s,a> := PolynomialRing(Rationals(), 10);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x*y-x*w-y*z+y*u+y*a-z*t-w*r-w*s-t*u-t*s,z^2-z*s-w^2-w*t-t^2-v*r-r*s+r*a,x*v+x*s-x*a+y*w-y*t-z^2+z*r+w^2,x*u-x*s-2*y*w-y*t+z^2+z*a+t^2-u*r+v*r+r*s-r*a,x*z-y^2+y*w+2*y*t+z^2+z*u+z*v,x*z+2*y^2+2*y*w-y*t-z*u-z*v+z*s-z*a,x*v+x*s-x*a+2*y^2-y*t+2*z^2-z*u-z*s+z*a+w^2,x^2-x*z-x*u+2*x*v+2*x*r+x*s+z^2+z*s+u^2-2*u*v-2*v*s+v*a+r^2-r*s+r*a-s^2,x*z-x*u-2*x*r-x*a-3*z^2-2*z*u-u*v-u*a-v*s+r^2+s*a-a^2,x^2+x*z-2*x*v+x*s-y*w-2*y*t-z^2-w*t+u^2+u*s+r^2+r*s+s*a-a^2,2*x^2-x*z+x*u-y^2+z^2+z*u+z*r-w*t+u^2-u*v+u*a+v*r-v*a+r^2+r*s,x^2+x*u-x*r+y^2-y*t-z*u-z*s+2*z*a+w^2-w*t+u^2-u*s+u*a-v*s+v*a,x*z-x*u+x*v-y*w+y*t+z^2-z*u-z*v+z*r+2*z*s-w^2-u*v-u*r-u*a-v*s+r^2+r*s-2*r*a+s*a-a^2,x^2+x*u+2*x*v-x*s-y*t-z^2-z*u+z*v+z*s-z*a-w^2+t^2+v*r,x^2-x*z+x*v-x*r+x*s-x*a-y^2-y*w+2*z^2+z*v+z*r-z*a+w^2+w*t-u*v+2*u*s-u*a-v*r-v*s+v*a-r*s+r*a-s^2+s*a,3*x^2+x*z+x*v-x*r+x*s+x*a-y^2-y*w+z*u-z*v+z*r-z*s-t^2+u^2+u*s-v*r+s*a-a^2,x^2+x*z+x*v-x*s+x*a-y*w-z^2+z*u+z*v+z*r-2*z*s+2*z*a-2*w*t+u*r+v*r,x^2-x*z+x*v+x*r-x*s+2*x*a-y^2+y*t+z^2+z*u+2*z*r+2*z*s-w^2+w*t-u*v-u*r-u*s+u*a-v*a-s*a+a^2,x^2+x*z+x*u-x*v-2*x*r-x*a+y^2+z^2+z*v+z*r-z*s+z*a+2*w^2-w*t-t^2+u^2-2*u*v-v^2-v*r+v*s-2*r^2-r*a,x*y+x*w-2*x*t-y*u+y*v-3*y*r+z*w-2*z*t+w*a+t*r,2*x*w+3*x*t-y*u+y*v+2*y*r-z*w+z*t-w*r+w*a+t*u-t*r+t*a,x*y-x*w-y*z+y*u-3*y*v-y*s+y*a-w*v+w*r+w*a,x*y-x*w-2*y*z+y*u+2*y*r+y*a+z*w+2*z*t+w*v+w*r-t*u,x*y+x*w+x*t+y*z-y*u+2*y*v+y*a-z*w-2*z*t-w*u+w*r+w*s+w*a+t*u+t*r+t*s,x*y+3*y*z+y*u-2*y*s+2*y*a+2*z*w-2*z*t-w*v-w*r-w*s+w*a+t*u,x*y+x*t-2*y*z-y*u+y*v+y*r-2*z*w+z*t-2*w*v+w*r+w*s-t*v+2*t*s-t*a,x*y-x*w-2*x*t+2*y*s-y*a-z*t+w*u+w*r-t*s+t*a,x*y-x*t+2*y*z+y*u-y*s-y*a-z*w+2*w*u-w*a+t*u+t*s-t*a];

// Singular plane model
model_1 := [6210750*x^6*y^12+187877820*x^4*y^14+1749619560*x^2*y^16+5303917584*y^18+36651875*x^6*y^11*z+168073568*x^4*y^13*z-6313438300*x^2*y^15*z-40039086528*y^17*z+22593610*x^6*y^10*z^2-1576573115*x^4*y^12*z^2+1082856294*x^2*y^14*z^2+133878685672*y^16*z^2-127227763*x^6*y^9*z^3+423477834*x^4*y^11*z^3+30005927081*x^2*y^13*z^3-255131934296*y^15*z^3-47982649*x^6*y^8*z^4+5413263674*x^4*y^10*z^4-65476293779*x^2*y^12*z^4+295364456993*y^14*z^4+369864781*x^6*y^7*z^5-9563268234*x^4*y^9*z^5+60533246748*x^2*y^11*z^5-199922827938*y^13*z^5-445409809*x^6*y^6*z^6+7205448172*x^4*y^8*z^6-18904418416*x^2*y^10*z^6+61312306263*y^12*z^6+263508856*x^6*y^5*z^7-2631578599*x^4*y^7*z^7-12338332903*x^2*y^9*z^7+5474365546*y^11*z^7-81677193*x^6*y^4*z^8+457213614*x^4*y^6*z^8+15203067282*x^2*y^8*z^8-2310375977*y^10*z^8+10614045*x^6*y^3*z^9-184779023*x^4*y^5*z^9-7631633217*x^2*y^7*z^9-8477113034*y^9*z^9+162409*x^6*y^2*z^10+170861873*x^4*y^4*z^10+2778816131*x^2*y^6*z^10+5475495376*y^8*z^10-135876*x^6*y*z^11-69506489*x^4*y^3*z^11-828232327*x^2*y^5*z^11-711933014*y^7*z^11+6084*x^6*z^12+10403640*x^4*y^2*z^12+118012869*x^2*y^4*z^12-240169553*y^6*z^12-10452*x^4*y*z^13+22221121*x^2*y^3*z^13-23912348*y^5*z^13-22932*x^4*z^14-10345192*x^2*y^2*z^14+67196586*y^4*z^14+1191684*x^2*y*z^15-20424084*y^3*z^15-42796*x^2*z^16+2752961*y^2*z^16-179384*y*z^17+4624*z^18];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 13.91.3.a.1
//   Coordinate number 0:
map_0_coord_0 := 1*(-y-w);
//   Coordinate number 1:
map_0_coord_1 := 1*(-w);
//   Coordinate number 2:
map_0_coord_2 := 1*(w+t);
// Codomain equation:
map_0_codomain := [5*x^4-7*x^3*y+3*x^2*y^2+2*x*y^3+8*x^3*z-7*x^2*y*z-2*x*y^2*z+5*y^3*z+4*x^2*z^2-5*x*y*z^2+y^2*z^2-3*x*z^3+2*y*z^3];

// Map from the canonical model to the plane model of modular curve with label 52.182.10.b.1
//   Coordinate number 0:
map_1_coord_0 := 1*(a);
//   Coordinate number 1:
map_1_coord_1 := 1*(y);
//   Coordinate number 2:
map_1_coord_2 := 1*(t);
// Codomain equation:
map_1_codomain := [6210750*x^6*y^12+187877820*x^4*y^14+1749619560*x^2*y^16+5303917584*y^18+36651875*x^6*y^11*z+168073568*x^4*y^13*z-6313438300*x^2*y^15*z-40039086528*y^17*z+22593610*x^6*y^10*z^2-1576573115*x^4*y^12*z^2+1082856294*x^2*y^14*z^2+133878685672*y^16*z^2-127227763*x^6*y^9*z^3+423477834*x^4*y^11*z^3+30005927081*x^2*y^13*z^3-255131934296*y^15*z^3-47982649*x^6*y^8*z^4+5413263674*x^4*y^10*z^4-65476293779*x^2*y^12*z^4+295364456993*y^14*z^4+369864781*x^6*y^7*z^5-9563268234*x^4*y^9*z^5+60533246748*x^2*y^11*z^5-199922827938*y^13*z^5-445409809*x^6*y^6*z^6+7205448172*x^4*y^8*z^6-18904418416*x^2*y^10*z^6+61312306263*y^12*z^6+263508856*x^6*y^5*z^7-2631578599*x^4*y^7*z^7-12338332903*x^2*y^9*z^7+5474365546*y^11*z^7-81677193*x^6*y^4*z^8+457213614*x^4*y^6*z^8+15203067282*x^2*y^8*z^8-2310375977*y^10*z^8+10614045*x^6*y^3*z^9-184779023*x^4*y^5*z^9-7631633217*x^2*y^7*z^9-8477113034*y^9*z^9+162409*x^6*y^2*z^10+170861873*x^4*y^4*z^10+2778816131*x^2*y^6*z^10+5475495376*y^8*z^10-135876*x^6*y*z^11-69506489*x^4*y^3*z^11-828232327*x^2*y^5*z^11-711933014*y^7*z^11+6084*x^6*z^12+10403640*x^4*y^2*z^12+118012869*x^2*y^4*z^12-240169553*y^6*z^12-10452*x^4*y*z^13+22221121*x^2*y^3*z^13-23912348*y^5*z^13-22932*x^4*z^14-10345192*x^2*y^2*z^14+67196586*y^4*z^14+1191684*x^2*y*z^15-20424084*y^3*z^15-42796*x^2*z^16+2752961*y^2*z^16-179384*y*z^17+4624*z^18];
