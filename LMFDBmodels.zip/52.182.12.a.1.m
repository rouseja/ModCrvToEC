
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 52.182.12.a.1

// Other names and/or labels
// Cummins-Pauli label: 26A12
// Rouse-Sutherland-Zureick-Brown label: 52.182.12.1

// Group data
level := 52;
// Elements that, together with Gamma(level), generate the group
gens := [[0, 41, 7, 13], [1, 9, 27, 32], [11, 29, 0, 41], [43, 51, 50, 35]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 182;

// Curve data
conductor := [[2, 36], [13, 23]];
bad_primes := [2, 13];
// Genus
g := 12;
// Rank
r := 3
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 7
;// Number of rational cusps
Nrat_cusps := 1
;// CM discriminants
CM_discs := [-4];
// Modular curve is a fiber product of the following curvesfactors := ['4.2.0.a.1', '13.91.3.b.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["4.2.0.a.1", "13.91.3.b.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r,s,a,b,c> := PolynomialRing(Rationals(), 12);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x*a+x*b-x*c-z*b-z*c-w*a+u*a-v*a-v*b-r*a-2*r*c,x*a-x*b-x*c+y*a-y*b+y*c+z*b-z*c-w*b-w*c+u*a+u*c-v*c-r*b-r*c,x*a-x*b+x*c-2*y*c-2*z*a+w*b+2*w*c-u*a+u*b+v*a+v*c+r*a+r*c+s*b,x*b-z*c+w*a-w*b-3*w*c-t*c+u*a-u*b-v*c-r*c-s*b,2*y*a+y*c+2*z*a-z*b-z*c+t*b-r*a-r*b-s*b+s*c,x*c-y*a+z*a+t*a-t*b+2*u*a+2*u*c-v*a+v*b-v*c-r*c,x*a+2*x*b+x*c+y*a-2*y*b-3*y*c+w*a-w*b+u*b+u*c-v*b-r*a+r*b-s*a+s*b-s*c,x*a+x*b-2*y*b+y*c+z*b-z*c-w*b+2*w*c-t*a-t*b+u*a+u*b+2*u*c-v*b-v*c+r*b+2*s*b+s*c,x*a-x*b+x*c-y*a-z*a+2*z*c-3*w*a+w*c+u*a-u*b-v*a-r*a-r*c-s*a-s*b-s*c,x*a-2*y*a-3*w*a+w*c+t*b-v*b-r*a+2*s*a+s*c,x*b+y*a+2*w*a+w*c+2*t*b+t*c-2*u*a+u*b+u*c+2*v*a-v*b+2*s*a,2*x*a-x*b+x*c+2*y*a-y*b+z*a+z*b+z*c+w*a+w*c+t*a-t*b+u*a-u*b-u*c+v*b+v*c-r*a+r*c-s*a-s*b,y*a+y*b+z*a-z*b+z*c+w*b-w*c-t*b-t*c+u*b-v*a-v*b-v*c-r*b-2*r*c-s*a+s*b-s*c,x*a+x*c+2*y*a+y*b+2*y*c-w*a-t*a+t*c-u*a-u*b+u*c+v*a+v*b-r*a-s*b,2*x^2+x*z+2*x*w+x*t-x*u+x*v+x*r+y^2+y*z+y*w-y*t-y*u-2*z*w+z*t+w*r+w*s+2*t*u-t*v-t*s-u^2+u*v-u*r-2*u*s+v*r+2*v*s+2*r*s+s^2+a*b-a*c+b*c,x^2+2*x*y-2*x*w-2*x*t-x*v+x*s-3*y^2-5*y*z-3*y*w-y*t-y*v+y*r-y*s+4*z^2-2*z*w+2*z*t-w*r-w*s-2*t*u+t*v+t*s+u^2-u*v+u*r+u*s+v*s-r^2+r*s-3*s^2+a^2-b^2-b*c,x^2+x*y-2*x*z+x*w-x*t+x*u+4*x*r+2*x*s-y^2-2*y*z-2*y*w-2*y*t-y*u+y*r+3*y*s+3*z^2-z*w-z*t-w*r-w*s-2*t*u+t*v-u*v+2*u*r-v*s-r^2-2*r*s-s^2,x^2+x*y+2*x*z-2*x*w-2*x*u-x*v-x*r+2*x*s-y*z-y*w-y*u+2*y*v+y*r-2*y*s+z^2-z*w+2*z*t-w*v+w*r-t^2+2*t*u-2*t*v+t*s+u^2-u*v-2*u*r+2*v*r+2*v*s+3*r*s+a^2-a*c+2*b*c,x^2+x*y+2*x*z-x*w+x*t-x*u+x*v-x*r+2*y^2+3*y*z+3*y*w+y*t-y*v-2*y*s-z^2+2*z*w-z*t+w*v+t^2+t*u-u*v-2*u*r+v^2+3*v*r+v*s+2*r*s+s^2,3*x^2+3*x*y-x*z+3*x*w-x*t+x*u-x*v+x*r+2*x*s-y^2-2*y*w-2*y*t-y*u+2*y*s+z^2-3*z*w+3*z*t-w*v-w*s-t^2-t*v+t*r+t*s+u^2-u*v+v*s-r^2-s^2+a*b-a*c+b*c,x^2+x*t-x*v-x*r+2*y^2+3*y*z+2*y*w-y*t+y*u+y*v-2*y*r+3*y*s-z^2-z*w+z*t-w*v+2*t*u-t*v+t*r+t*s+u*v-u*s-v^2-2*v*r-v*s+r*s+s^2-a^2+b^2+b*c,x^2+2*x*y+x*z+x*w+2*x*t+x*u-2*x*r+2*y*z-2*y*t+2*y*u-y*r-2*z^2+z*w-2*z*t-w*r+t^2+t*v+t*s-u^2+u*v-u*r+u*s-v^2+v*r-2*v*s+r^2+a*b+2*a*c-b^2-b*c,x^2-2*x*y-x*z+2*x*w-x*t+4*x*r+x*s+y^2-y*z+y*w-2*y*t+y*v+2*y*r+2*y*s-z^2-z*t+2*w*r+2*w*s-2*t^2+t*u-t*v-2*t*r-t*s-u^2+u*v-u*s+v*s+2*r^2+s^2,x^2-2*x*w-x*t-x*u-x*v-y^2+y*z-2*y*w-y*u-y*v+3*y*r-y*s+2*z*w-2*z*t+w*r+w*s-2*t^2-t*u-t*r-u^2+u*v-u*r+u*s+v*r-v*s-2*r*s+s^2+a*b-a*c+b*c,3*x*y+2*x*z+x*w-2*x*t-x*u-y^2-2*y*z-y*w+y*t-y*v+y*r-y*s+3*z^2+2*z*t+w*v+w*r+2*w*s-t^2-t*u-t*r-t*s-u^2+2*u*v-u*r-u*s+v*r+3*v*s+2*r*s+a^2+a*b-a*c-b^2,2*x^2-2*x*z+x*w+x*t-x*u-x*v+x*r+y^2+3*y*z+y*w+y*u+y*v-2*z^2+3*z*w+w*r-2*t^2+t*s-u^2+2*u*v-u*r-u*s-v^2+r^2+s^2,x^2+x*y+3*x*z+x*w-x*t+x*r+x*s+5*y*z+y*w+y*t-y*r+y*s-z^2+2*z*w+z*t+w*r+2*w*s-t^2+2*t*u-2*t*v-t*r+t*s+u^2-u*v-u*r+u*s+v^2+v*r+v*s+r^2+3*r*s+2*s^2,x*z-x*t+2*x*u-x*v-2*x*r-3*x*s+y^2-y*z+y*w+y*t-y*v-2*y*s-3*z^2-z*w+3*z*t+w*v-t*u-t*r-t*s+v^2+2*v*s-r*s-s^2,x*y+2*x*z-x*w-x*t+x*u-x*r-3*x*s-2*y^2+2*y*z+y*w+y*t+3*y*u-2*y*v-y*r-z^2-z*t+w*v+t^2-t*u+t*v-t*r+2*t*s-u*v+u*r+2*u*s+v^2-v*s+r^2-s^2-a*b+a*c-b*c,x^2+x*y+x*z-x*t-2*x*u-2*x*r+x*s-y^2-2*y*z-2*y*w-y*u-y*v+2*y*r-2*y*s-3*z*w+3*z*t-2*w*v+2*w*r-w*s-t^2-t*v+t*r+u^2+u*v-u*r-v^2-v*r-r^2+r*s-s^2+a*b-a*c+b*c,3*x*z-3*x*w+x*t-x*v-x*r-x*s-2*y*z+y*t+y*v-y*r-2*y*s+2*z^2-2*z*w+z*t+w*t-2*w*v+t^2+t*s+u*r-v^2+2*r*s-s^2+a^2-a*b+b*c,x^2-x*y+x*t-x*r+x*s-y^2-y*t+2*y*v-2*y*s-2*z^2+z*w-z*t+w*t-w*v+w*s+3*t*u-t*v+t*r+t*s+u^2-u*r+u*s-v^2+v*s+r^2+r*s+a^2-a*b+a*c-b^2-2*b*c,x^2+x*y-x*z+2*x*w+x*t+2*x*u+x*r-x*s+y^2+4*y*z+y*t-2*y*u-y*v-y*r+2*y*s-z^2+2*z*w-w*t-w*u+3*w*v-w*r-t*u+t*v-t*r-t*s+v^2-v*s-r^2-2*r*s+s^2-a^2+a*b-b*c,x^2+2*x*z-x*w-2*x*t-x*u-x*r-y*z+y*u-y*v+y*r-y*s-z^2-z*w+3*z*t-w^2+w*t+w*r+t*u-t*v-t*s+u*v-u*r-u*s+2*v*s+2*r*s,x^2-5*x*w-2*x*v-3*x*r+x*s-3*y*z-y*w-y*t-y*u+y*r-2*y*s+z^2-z*w+z*t-z*s-w*t-w*r+t*s+u^2-u*v+2*u*s-r^2+r*s-s^2,x^2-x*y+x*z+x*w+x*r-x*s+3*y*z+y*w-y*t+y*u-y*r+y*s-z^2+z*w+z*s-w*t+w*r+2*w*s-t^2+t*u-t*v-u^2+u*v-u*s+v*s+r^2+r*s+s^2,2*x^2+2*x*y-2*x*z-x*t-x*v+x*r+x*s-y^2-y*z-2*y*w-2*y*u-y*v+3*y*r+z^2+2*z*t+w^2+w*u-w*v-w*s-t^2-2*t*u+u^2-u*v+v*r-2*r^2-2*r*s-s^2+a*b-a*c+b*c,x^2-x*y-2*x*w-x*t-x*v-x*r-x*s-3*y^2+y*z-2*y*w+y*u+y*r-y*s-z^2-z*w+z*t-z*r+w*u+w*v-t^2+2*t*s+u^2-u*v+2*u*s+v^2-s^2,2*x*y+3*x*z+x*w+x*v+x*r+x*s+y^2+3*y*z+y*t-2*y*u-y*v-y*r+y*s+z*w-z*t-z*v+w*t-w*v-w*r+w*s+t^2+t*u-t*v-t*s+v*r-r^2+2*s^2,x^2+3*x*y+x*w-2*x*t+x*r-x*s-y^2-y*z-y*w-y*t+y*u-2*y*v+y*r+y*s+3*z^2-2*z*w+z*t-z*u+z*v+w*u-2*t*u+t*v-u^2+u*v+u*r-u*s+v*s-r^2-s^2+a*b-a*c+b*c,2*x*w+x*t-3*x*r-x*s+2*y^2+3*y*z+2*y*w+2*y*t-2*y*v-2*y*s-2*z^2+z*w-z*u+w*t+w*r-t^2+t*r-2*t*s-u^2+2*u*v-2*u*r-u*s+2*s^2-a^2+2*a*b-a*c,3*x*y-x*v-x*r-x*s-y*w-y*t-y*u+y*r+y*s+2*z^2+z*w+z*r+w*v-w*r-t*u+t*v+t*r-u^2+u*v-u*s+v*s-2*r^2-2*r*s+a*b-a*c+b*c,x*z+x*u-x*r-y^2-y*z-y*w-y*t-2*y*v-y*r-2*z*t+z*r+z*s-w*v-w*r+w*s+t*v+t*s+u^2+u*v+u*r+2*u*s-v^2-3*v*r-2*v*s-s^2+a*c-b^2-3*b*c,3*x*y-2*x*w-2*x*t-x*u-x*r+x*s-y^2-y*z-2*y*w-y*t-y*u+2*y*s+3*z^2-z*w-w*t-w*u-w*r+w*s-t^2+t*u+t*v-t*r+u^2+2*u*s-v^2-v*r+2*r*s+s^2+a*b+2*a*c+c^2,x^2+x*y+x*z-x*v-3*x*r+y^2+5*y*z+y*w+y*t-y*r-y*s+z^2+z*w+z*t-z*u-z*v+2*z*r-w^2+w*t+w*u-w*v+t*u-t*v+t*s-2*u*r-u*s+2*v*r+2*v*s+2*r*s+s^2+a^2+a*b+b^2+b*c];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 13.91.3.b.1
//   Coordinate number 0:
map_0_coord_0 := 1*(a-2*b+c);
//   Coordinate number 1:
map_0_coord_1 := 1*(-a+b+2*c);
//   Coordinate number 2:
map_0_coord_2 := 1*(-a-2*b-2*c);
// Codomain equation:
map_0_codomain := [x^3*y-2*x*y^3-2*x*y^2*z-y^3*z+x^2*z^2-2*x*y*z^2-x*z^3+y*z^3];
