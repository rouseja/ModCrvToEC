
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 52.182.9.a.1

// Other names and/or labels
// Cummins-Pauli label: 26C9
// Rouse-Sutherland-Zureick-Brown label: 52.182.9.2

// Group data
level := 52;
// Elements that, together with Gamma(level), generate the group
gens := [[5, 28, 4, 21], [31, 25, 26, 21], [36, 43, 51, 5]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 182;

// Curve data
conductor := [[2, 24], [13, 18]];
bad_primes := [2, 13];
// Genus
g := 9;
// Rank
r := 5
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 7
;// Number of rational cusps
Nrat_cusps := 1
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["13.91.3.b.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r,s> := PolynomialRing(Rationals(), 9);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x^2+x*y-x*r-x*s+z*t-t^2,x*y+2*x*z-2*y^2+y*r+y*s+z*t,x*w+y*w+z*u-z*v-2*w*s-t*u-u*r+u*s-v*r,x*y-x*z+x*r-x*s+y*t-y*r-y*s+z^2-z*t-w^2-t*s-u*v+v^2,x^2-x*y-x*z-x*r-y^2+y*z+y*r+z^2-z*t-w^2-t*r-u*v+v^2,x*u+2*x*v+y*w-z*w-z*u+w*t-2*w*s+t*u-t*v-u*r+u*s-v*r,x*w+x*u-y*w+y*u-y*v+2*z*w-2*z*u+z*v-w*t+2*t*u-u*r+u*s,x*w+x*v-y*u-2*y*v+z*w-2*z*u-z*v+w*r-w*s+t*u-v*r+v*s,x*z-x*r+y*r-2*z*r+w*u+w*v+t*r-u*v,x*v+y*w-2*y*u+3*y*v-z*w-t*u-t*v-u*r+u*s+v*r-v*s,2*x*v-2*y*w+y*v+z*w-z*u-z*v+w*r+w*s+t*u-t*v+v*r,2*x*w+x*v-2*z*w-z*v+2*w*t-w*s+t*v-2*u*s+v*s,2*x*w-x*u-y*u-y*v-z*w-z*u+z*v+2*w*t-w*s+u*r+u*s-2*v*r,x*y-x*z+x*t+x*s+y^2-y*t-y*r+z^2-z*t+w^2+t*r+t*s+u*v-v^2,x*t+x*s-y*z+2*z*t-z*r+z*s+w*v-t^2+t*r+2*u*v-v^2,x^2-2*x*y-x*z-x*t+x*r-y^2+y*t+y*s-z^2+z*t-2*w*u+w*v+t*s+u*v-v^2,x^2-x*y-2*x*z-x*r-x*s-2*y*z+2*y*t+y*r+y*s-z^2+w^2-w*v+t*s-u*v,x^2-x*z-x*r+x*s+y*t+2*y*s-2*z*s+w^2-w*v-u*v-r^2+r*s,x^2+x*z+x*r+y*z-y*s-z^2+z*s+2*w*u-t^2-u^2+2*u*v-v^2+r^2-r*s,2*x^2+x*y-x*z-x*r+x*s-y*z+2*y*t-z*r+z*s+w^2-w*u+t*r-t*s+v^2-r^2+r*s,2*x^2-x*r+x*s+y*z+y*r-2*y*s-z*r-z*s-w*u-w*v+t*s+u*v-r^2+s^2];

// Singular plane model
model_1 := [17689*x^15+915772*x^13*y^2-211081*x^11*y^4-8788*x^9*y^6+28196*x^14*z+833339*x^12*y^2*z-879476*x^10*y^4*z+52728*x^8*y^6*z-75746*x^13*z^2-4950452*x^11*y^2*z^2+682422*x^9*y^4*z^2+8788*x^7*y^6*z^2-102973*x^12*z^3-3920696*x^10*y^2*z^3+2761291*x^8*y^4*z^3-228488*x^6*y^6*z^3+67210*x^11*z^4+7945171*x^9*y^2*z^4+367406*x^7*y^4*z^4-316368*x^5*y^6*z^4-3627*x^10*z^5+5392504*x^8*y^2*z^5-2721069*x^6*y^4*z^5-202124*x^4*y^6*z^5-47125*x^9*z^6-6095206*x^7*y^2*z^6-2767713*x^5*y^4*z^6-79092*x^3*y^6*z^6+186277*x^8*z^7-3568370*x^6*y^2*z^7-1654679*x^4*y^4*z^7-17576*x^2*y^6*z^7+100880*x^7*z^8+2440490*x^5*y^2*z^8-683943*x^3*y^4*z^8-2197*x*y^6*z^8-64727*x^6*z^9+1742585*x^4*y^2*z^9-158184*x^2*y^4*z^9+9724*x^5*z^10+214123*x^3*y^2*z^10-20449*x*y^4*z^10-13559*x^4*z^11-715*x^2*y^2*z^11-74932*x^3*z^12-208*x*y^2*z^12-32375*x^2*z^13+3328*y^2*z^13+2784*x*z^14+2304*z^15];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 13.91.3.b.1
//   Coordinate number 0:
map_0_coord_0 := 1*(-w+u+2*v);
//   Coordinate number 1:
map_0_coord_1 := 1*(w+2*u-v);
//   Coordinate number 2:
map_0_coord_2 := 1*(w-2*u+2*v);
// Codomain equation:
map_0_codomain := [x^3*y-2*x*y^3-2*x*y^2*z-y^3*z+x^2*z^2-2*x*y*z^2-x*z^3+y*z^3];

// Map from the canonical model to the plane model of modular curve with label 52.182.9.a.1
//   Coordinate number 0:
map_1_coord_0 := 1*(y);
//   Coordinate number 1:
map_1_coord_1 := 1*(v);
//   Coordinate number 2:
map_1_coord_2 := 1*(z);
// Codomain equation:
map_1_codomain := [17689*x^15+915772*x^13*y^2-211081*x^11*y^4-8788*x^9*y^6+28196*x^14*z+833339*x^12*y^2*z-879476*x^10*y^4*z+52728*x^8*y^6*z-75746*x^13*z^2-4950452*x^11*y^2*z^2+682422*x^9*y^4*z^2+8788*x^7*y^6*z^2-102973*x^12*z^3-3920696*x^10*y^2*z^3+2761291*x^8*y^4*z^3-228488*x^6*y^6*z^3+67210*x^11*z^4+7945171*x^9*y^2*z^4+367406*x^7*y^4*z^4-316368*x^5*y^6*z^4-3627*x^10*z^5+5392504*x^8*y^2*z^5-2721069*x^6*y^4*z^5-202124*x^4*y^6*z^5-47125*x^9*z^6-6095206*x^7*y^2*z^6-2767713*x^5*y^4*z^6-79092*x^3*y^6*z^6+186277*x^8*z^7-3568370*x^6*y^2*z^7-1654679*x^4*y^4*z^7-17576*x^2*y^6*z^7+100880*x^7*z^8+2440490*x^5*y^2*z^8-683943*x^3*y^4*z^8-2197*x*y^6*z^8-64727*x^6*z^9+1742585*x^4*y^2*z^9-158184*x^2*y^4*z^9+9724*x^5*z^10+214123*x^3*y^2*z^10-20449*x*y^4*z^10-13559*x^4*z^11-715*x^2*y^2*z^11-74932*x^3*z^12-208*x*y^2*z^12-32375*x^2*z^13+3328*y^2*z^13+2784*x*z^14+2304*z^15];
