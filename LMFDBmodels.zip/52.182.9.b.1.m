
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 52.182.9.b.1

// Other names and/or labels
// Cummins-Pauli label: 26C9
// Rouse-Sutherland-Zureick-Brown label: 52.182.9.1

// Group data
level := 52;
// Elements that, together with Gamma(level), generate the group
gens := [[3, 45, 18, 15], [29, 2, 45, 33], [47, 46, 34, 5]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 182;

// Curve data
conductor := [[2, 24], [13, 17]];
bad_primes := [2, 13];
// Genus
g := 9;
// Rank
r := 8
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 7
;// Number of rational cusps
Nrat_cusps := 1
;// CM discriminants
CM_discs := [-4, -12];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["13.91.3.b.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r,s> := PolynomialRing(Rationals(), 9);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [2*x^2-2*x*t+2*x*u+3*x*v-2*x*r+y^2+y*w-3*w^2-t*u+t*s-u*v,4*x*v-2*x*r+2*x*s+t*r+t*s+u*r+u*s+v^2+v*r+v*s-r^2,x*u+x*v-3*x*r+t*u-t*v-t*r-u^2+v^2+3*v*r,2*x^2+x*t-2*x*u-3*x*v+2*x*s-2*y^2+2*y*z+3*y*w+z*w+2*w^2-t^2+t*u-t*s+u*v+2*v*r-v*s-r^2,4*x^2+x*t-3*x*v+2*x*r+x*s-3*y^2-y*z+y*w+z^2-2*z*w+w^2-v^2-2*v*r,4*x^2+x*t+x*u+2*x*r-2*x*s+t^2-t*v-t*r-u^2-u*v-u*r-r*s,2*x*u-2*x*v-2*x*r-t*v+t*r-u*v+u*r-u*s+v*s+r*s,4*x^2+2*x*u-t^2-2*t*u+t*v-t*r-2*u*r+u*s+v*r-v*s-r*s,x*t+x*v-3*x*r+2*x*s+y^2+y*w-3*w^2-t^2+2*t*v-t*r-u*v+u*r+2*v*r-v*s,x*t+2*x*v+x*r-x*s-y*z+4*y*w-z^2+z*w-w^2-t*u+t*v+t*r+t*s-u*r+u*s+v*r-v*s-r*s,2*x^2+x*t-2*x*u+x*v+x*r-x*s+y^2-3*y*z-z^2+2*t*r+t*s+u*v-u*r+u*s-v*s+r^2-r*s-s^2,2*x*y-2*x*z-x*w+y*t-y*u-y*v+y*r-y*s+z*u+z*s+w*t-w*v-w*r,2*x^2+x*u-2*x*v+2*x*r-x*s-y^2-4*y*z+2*y*w+z^2+3*z*w+w^2+t^2+t*u-2*t*v-t*r-t*s-u^2+v*r,2*x^2-x*t+x*v+3*x*r-x*s+3*y^2-3*y*z+2*y*w+z^2-3*z*w-t*r-u*v+u*r-r*s,2*x*y+2*x*z-x*w-2*y*t+2*y*r+2*z*u-z*s+w*u-w*v-2*w*r,2*x*y-2*x*z+3*x*w-y*t-y*u-2*y*v-2*y*r+z*t-z*u+z*s+w*t+w*u+2*w*r,2*x*y+4*x*z-2*x*w+y*t+y*u-y*s-z*t-z*u-2*z*s-2*w*t-2*w*u+w*s,x*y-2*x*z+y*u-y*r-2*z*t-2*z*u-z*v+2*z*r-z*s-w*t-w*u-w*r+w*s,y*u-2*y*r-z*u+3*z*v-z*r-2*w*u+w*v+3*w*r,2*x*y-x*w-y*u-2*y*v-2*y*r-y*s+z*t-3*z*u-z*v+z*s+2*w*u-w*v-w*s,x*y-y*t+y*v-3*y*r+y*s+2*z*t-z*u-2*z*v+z*s-w*t+w*v+2*w*r-w*s];

// Singular plane model
model_1 := [-1028196*x^8*y^8+52437996*x^8*y^7*z-785084768*x^8*y^6*z^2+2943382416*x^8*y^5*z^3-2663598860*x^8*y^4*z^4-191358700*x^8*y^3*z^5+1197619852*x^8*y^2*z^6-500959940*x^8*y*z^7+62834200*x^8*z^8-3737097*x^6*y^10+100040395*x^6*y^9*z+356414916*x^6*y^8*z^2-19089381480*x^6*y^7*z^3+82730515413*x^6*y^6*z^4-76435552375*x^6*y^5*z^5-22912242769*x^6*y^4*z^6+44362735755*x^6*y^3*z^7-7255781442*x^6*y^2*z^8-3481823176*x^6*y*z^9+817240060*x^6*z^10-3880916*x^4*y^12+103206948*x^4*y^11*z-1161774783*x^4*y^10*z^2+29685711731*x^4*y^9*z^3-249582144994*x^4*y^8*z^4+774651376057*x^4*y^7*z^5-749327029919*x^4*y^6*z^6-255707387247*x^4*y^5*z^7+435503096600*x^4*y^4*z^8-38449529352*x^4*y^3*z^9-35062974349*x^4*y^2*z^10+4738559228*x^4*y*z^11+149373016*x^4*z^12-3842280*x^2*y^14+207160044*x^2*y^13*z-3724143150*x^2*y^12*z^2+28592774197*x^2*y^11*z^3-90471812054*x^2*y^10*z^4+74776837486*x^2*y^9*z^5+63001069417*x^2*y^8*z^6+103042761120*x^2*y^7*z^7-63388429078*x^2*y^6*z^8-287019963958*x^2*y^5*z^9+159713810815*x^2*y^4*z^10-14193332842*x^2*y^3*z^11-4685289583*x^2*y^2*z^12+348609157*x^2*y*z^13+70588830*x^2*z^14+633616*y^16-28617792*y^15*z+515786088*y^14*z^2-4686020280*y^13*z^3+22291048273*y^12*z^4-52952590002*y^11*z^5+62849075471*y^10*z^6-71182965646*y^9*z^7+106126870915*y^8*z^8-53699866584*y^7*z^9+57809148514*y^6*z^10-32437490072*y^5*z^11+13870049011*y^4*z^12-4391688022*y^3*z^13+931534447*y^2*z^14-145979202*y*z^15+12341169*z^16];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 13.91.3.b.1
//   Coordinate number 0:
map_0_coord_0 := 1*(-y+z+2*w);
//   Coordinate number 1:
map_0_coord_1 := 1*(y+2*z-w);
//   Coordinate number 2:
map_0_coord_2 := 1*(y-2*z+2*w);
// Codomain equation:
map_0_codomain := [x^3*y-2*x*y^3-2*x*y^2*z-y^3*z+x^2*z^2-2*x*y*z^2-x*z^3+y*z^3];

// Map from the canonical model to the plane model of modular curve with label 52.182.9.b.1
//   Coordinate number 0:
map_1_coord_0 := 1*(x);
//   Coordinate number 1:
map_1_coord_1 := 1*(y);
//   Coordinate number 2:
map_1_coord_2 := 1*(z);
// Codomain equation:
map_1_codomain := [-1028196*x^8*y^8+52437996*x^8*y^7*z-785084768*x^8*y^6*z^2+2943382416*x^8*y^5*z^3-2663598860*x^8*y^4*z^4-191358700*x^8*y^3*z^5+1197619852*x^8*y^2*z^6-500959940*x^8*y*z^7+62834200*x^8*z^8-3737097*x^6*y^10+100040395*x^6*y^9*z+356414916*x^6*y^8*z^2-19089381480*x^6*y^7*z^3+82730515413*x^6*y^6*z^4-76435552375*x^6*y^5*z^5-22912242769*x^6*y^4*z^6+44362735755*x^6*y^3*z^7-7255781442*x^6*y^2*z^8-3481823176*x^6*y*z^9+817240060*x^6*z^10-3880916*x^4*y^12+103206948*x^4*y^11*z-1161774783*x^4*y^10*z^2+29685711731*x^4*y^9*z^3-249582144994*x^4*y^8*z^4+774651376057*x^4*y^7*z^5-749327029919*x^4*y^6*z^6-255707387247*x^4*y^5*z^7+435503096600*x^4*y^4*z^8-38449529352*x^4*y^3*z^9-35062974349*x^4*y^2*z^10+4738559228*x^4*y*z^11+149373016*x^4*z^12-3842280*x^2*y^14+207160044*x^2*y^13*z-3724143150*x^2*y^12*z^2+28592774197*x^2*y^11*z^3-90471812054*x^2*y^10*z^4+74776837486*x^2*y^9*z^5+63001069417*x^2*y^8*z^6+103042761120*x^2*y^7*z^7-63388429078*x^2*y^6*z^8-287019963958*x^2*y^5*z^9+159713810815*x^2*y^4*z^10-14193332842*x^2*y^3*z^11-4685289583*x^2*y^2*z^12+348609157*x^2*y*z^13+70588830*x^2*z^14+633616*y^16-28617792*y^15*z+515786088*y^14*z^2-4686020280*y^13*z^3+22291048273*y^12*z^4-52952590002*y^11*z^5+62849075471*y^10*z^6-71182965646*y^9*z^7+106126870915*y^8*z^8-53699866584*y^7*z^9+57809148514*y^6*z^10-32437490072*y^5*z^11+13870049011*y^4*z^12-4391688022*y^3*z^13+931534447*y^2*z^14-145979202*y*z^15+12341169*z^16];
