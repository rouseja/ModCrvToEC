
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 52.2184.159.e.1


// Group data
level := 52;
// Elements that, together with Gamma(level), generate the group
gens := [[4, 41, 15, 9], [32, 5, 41, 16], [51, 27, 21, 14]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 2184;

// Curve data
conductor := [[2, 523], [13, 309]];
bad_primes := [2, 13];
// Genus
g := 159;
// Rank
r := 81
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 42
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["52.546.24.b.1", "52.728.53.d.1", "52.1092.77.q.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
