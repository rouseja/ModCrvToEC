
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 52.28.1.a.1

// Other names and/or labels
// Cummins-Pauli label: 26A1
// Rouse-Sutherland-Zureick-Brown label: 52.28.1.1

// Group data
level := 52;
// Elements that, together with Gamma(level), generate the group
gens := [[13, 31, 34, 5], [21, 49, 20, 43], [32, 51, 49, 19], [36, 29, 5, 24]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 28;

// Curve data
conductor := [[2, 4], [13, 1]];
bad_primes := [2, 13];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 2
;// Number of rational cusps
Nrat_cusps := 2
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['4.2.0.a.1', '13.14.0.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["4.2.0.a.1", "13.14.0.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3-y^2*z+x*z^2+10*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := -1*(x^2*y^8+4*x^2*y^6*z^2-158*x^2*y^4*z^4+466*x^2*y^2*z^6+x^2*z^8+2*x*y^8*z-18*x*y^6*z^3-160*x*y^4*z^5+1361*x*y^2*z^7-1730*x*z^9+9*y^8*z^2-140*y^6*z^4+443*y^4*z^6+934*y^2*z^8-3451*z^10);
//   Coordinate number 1:
map_0_coord_1 := 1*(z^9*(x+2*z));
