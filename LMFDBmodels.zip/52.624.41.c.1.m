
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 52.624.41.c.1


// Group data
level := 52;
// Elements that, together with Gamma(level), generate the group
gens := [[1, 28, 1, 47], [21, 51, 32, 11], [33, 29, 23, 6]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 624;

// Curve data
conductor := [[2, 107], [13, 82]];
bad_primes := [2, 13];
// Genus
g := 41;
// Rank
r := 32
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 12
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["52.156.8.d.1", "52.312.21.m.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
