
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 52.728.53.b.1


// Group data
level := 52;
// Elements that, together with Gamma(level), generate the group
gens := [[1, 8, 17, 51], [9, 7, 21, 36], [22, 27, 41, 17]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 728;

// Curve data
conductor := [[2, 176], [13, 100]];
bad_primes := [2, 13];
// Genus
g := 53;
// Rank
r := 36
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 14
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["52.182.8.a.1", "52.364.24.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
