
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 54.108.6.a.1

// Other names and/or labels
// Cummins-Pauli label: 54B6
// Rouse-Sutherland-Zureick-Brown label: 54.108.6.1

// Group data
level := 54;
// Elements that, together with Gamma(level), generate the group
gens := [[25, 32, 36, 53], [47, 6, 0, 19], [53, 41, 36, 13]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 108;

// Curve data
conductor := [[2, 2], [3, 24]];
bad_primes := [2, 3];
// Genus
g := 6;
// Rank
r := 1
;// Exact gonality known
gamma := 3;

// Modular data
// Number of cusps
Ncusps := 8
;// Number of rational cusps
Nrat_cusps := 4
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['2.3.0.a.1', '27.36.2.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["18.36.0.a.1", "27.36.2.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u> := PolynomialRing(Rationals(), 6);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x*z-x*t-y*u,x*t+y*t-x*u,z*t-t^2+t*u-u^2,z*w-w*t+x*u-w*u,x^2-x*w+y*w,x*t-2*w*t+w*u,x^3+x^2*w+2*x*w^2+y*w^2+z*t^2-z*u^2,x^3+y^2*w-x*w^2-2*y*w^2+z^2*t+z^2*u-z*t*u-z*u^2,x^2*y-x*y^2+z^3+x^2*w+2*x*y*w+y^2*w-x*w^2-2*y*w^2-2*z^2*t+z*t*u+t^2*u-z*u^2-t*u^2+u^3];

// Singular plane model
model_1 := [x^6+14*x^3*y^3-x^5*z-15*x^2*y^3*z+6*x*y^3*z^2+x^3*z^3-y^3*z^3-x^2*z^4];

// Maps from this modular curve, if computed

// j-invariant map from the canonical model
//   Coordinate number 0:
map_0_coord_0 := -1*(3800639510752*x*w^11-6389241207888*x*w^8*u^3+9731642883101*x*w^5*u^6+14263118229988*x*w^2*u^9+3818962*y^12-237902056*y^9*z^3+1192178820*y^9*z^2*u-2277130352*y^9*z*u^2+1880912530*y^9*u^3+3182909660*y^6*z^3*u^3-9520083678*y^6*z^2*u^4-11266215730*y^6*z*u^5+3286998498*y^6*u^6-93516175816*y^3*z^3*u^6-9226062020*y^3*z^2*u^7+92902091940*y^3*z*u^8+115764476366*y^3*u^9-3803014717152*y*w^11-8712566644656*y*w^8*u^3-10642944780701*y*w^5*u^6-8558573861708*y*w^2*u^9+765141077372*z^3*u^9-528742102252*z^2*u^10-4015885864522*z*u^11-221078592*w^12+1083940368*w^9*u^3+5125449919191*w^6*u^6-2315693392752*w^3*u^9-214276510*t^12-1473200680*t^11*u+967742944*t^10*u^2-52099028380*t^9*u^3+317144013611*t^8*u^4-1127345292326*t^7*u^5+2319115584514*t^6*u^6-3916790637764*t^5*u^7+4671510095364*t^4*u^8-1058186569086*t^3*u^9+224838028217*t^2*u^10+1339203902408*t*u^11+1031202475026*u^12);
//   Coordinate number 1:
map_0_coord_1 := 1*(34002080*x*w^8*u^3+127532921*x*w^5*u^6+8133204*x*w^2*u^9+102715760*y*w^8*u^3-10221593*y*w^5*u^6-4441116*y*w^2*u^9-47814837*w^6*u^6-17840448*w^3*u^9+246568*t^12-4673816*t^11*u+27970866*t^10*u^2-85576848*t^9*u^3+153041759*t^8*u^4-154987618*t^7*u^5+43907530*t^6*u^6+110317192*t^5*u^7-182209456*t^4*u^8+134172062*t^3*u^9-47398383*t^2*u^10+749028*t*u^11+4441116*u^12);

// Map from the canonical model to the plane model of modular curve with label 54.108.6.a.1
//   Coordinate number 0:
map_1_coord_0 := 1*(t);
//   Coordinate number 1:
map_1_coord_1 := 1*(w);
//   Coordinate number 2:
map_1_coord_2 := 1*(u);
// Codomain equation:
map_1_codomain := [x^6+14*x^3*y^3-x^5*z-15*x^2*y^3*z+6*x*y^3*z^2+x^3*z^3-y^3*z^3-x^2*z^4];
