
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 54.216.13.bc.1

// Other names and/or labels
// Cummins-Pauli label: 54N13
// Rouse-Sutherland-Zureick-Brown label: 54.216.13.7

// Group data
level := 54;
// Elements that, together with Gamma(level), generate the group
gens := [[5, 13, 30, 49], [26, 23, 3, 35], [49, 2, 51, 5], [49, 17, 3, 4]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 216;

// Curve data
conductor := [[2, 8], [3, 63]];
bad_primes := [2, 3];
// Genus
g := 13;
// Rank
r := 5
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 6
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-3];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["18.72.2.f.1", "54.72.3.d.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r,s,a,b,c,d> := PolynomialRing(Rationals(), 13);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x*c-z*b,y*c-z*a,x*w+x*t+x*c-y*w-v*a,x*w+x*r-x*c+y*w+v*a+v*b,z*w-z*t-z*s-u*c+v*c,z*t-z*r+z*s-t*d,x*w-x*t-x*s-u*b+v*b,x*w+x*c+y*t-z*a+u*b,x*c+z*v-z*a+z*b-v*d,2*z*w+z*t+z*r+v*c,v*r-v*s-r*b-s*b-a*c+b*c,x^2-x*y+y^2-u*s-v*r,z*t-z*s+w*d+t*d+u*c,x*c-y*c+z*u-z*a-u*d,x*w-x*s-y*w-y*t+z*a-u*a+v*a,x*r+y*w-y*t-z*a+z*b-u*a+u*b-a^2-a*d+b^2,z*c+u*r-v*r-v*s+r*a+s*b-c*d,z*w-z*r-w*d+s*d-a*c-b*c,t*a+t*b-u*r+u*s+v*r-v*s,w*u+t*v+t*a-u*r-u*c+v*r,w*b+t*a+u*s-v*r-v*s,w*b-t*a+t*b+u*r-v*r-v*s,w*a+t*b+u*r+u*s-v*s,x*a-y*b,y*w-y*t-y*s-u*a+v*a,w*a-t*a-u*s-v*r-s*a+s*b-a*c,w*a+w*b+t*a+t*b+r*a+b*c,w*u-w*v+t*u+t*b+v*r-v*c,x*w+x*t+x*c+y*w+y*t+y*r,z*t-z*s-t*d-r*d-s*d+2*a*c-b*c,z*u+z*v-z*a+2*u*v+u*b-v^2+v*a,x*c+z*u-z*v-u^2-u*b+v^2-v*d,x^2-x*y-y^2+z*s+z*c-w*a+t*u+t*v-t*a-v*c,w*u-w*b-2*t*v-v*s+v*c,x^2+x*y-y^2-z*r-z*c-w*v+t*v+2*v*s-v*c,2*x*y-z*w+z*t-z*r+z*c+w*u+w*v-w*b+u*r-u*s,x*z+y*z+w^2-w*s-t^2+t*c,w*r-w*s+2*t*r+t*s,x*s-y*w+y*t-y*r+y*c-v*b+a^2-2*a*b+b*d,x*r-y*w+y*t+3*z^2+z*a-u^2+u*v-u*b-v^2-v*a+v*b,x*r-2*x*s+x*c-y*s-2*z^2+u^2-u*v+v^2+a*b+b^2-b*d-d^2,2*x*u-x*v+x*b+w*c+2*t*c+r^2+r*s+s^2+s*c-c^2,2*x*z-x*d-2*y*z+w^2-w*s-t^2-2*t*c+r*c-s*c,x*u+x*a-x*b-x*d-y*z+w*t-w*r+w*c-t^2-t*r-t*c-r^2+r*c-s*c+c^2,2*x*z-y*z-2*w*t-w*r-w*c-t^2-t*r,x*z-x*u-x*a+x*b-x*d+w*s-t*r-t*c+r^2+r*s+r*c,x*z-x*v+x*b-x*d-w*r-w*s+w*c-t*r+r^2+r*s+r*c+s^2-c^2,x*v+x*a-x*b+y*b-w*c-t*r+t*s-r^2-r*s-r*c-s*c+c^2,x*u+x*a-x*d-y*z-y*a+y*b-w^2-w*r+t^2-t*r,x*w+x*t-x*s-y*t-y*r-z^2+z*d,x*u-x*v+y*v-w^2-w*t-w*s-t^2+t*r,x*v-x*b+y*z-y*d-w*r-w*c+t*s-r^2+r*s-s*c+c^2,x*z-x*u+x*a-x*d-y*z+y*u+y*d-w*s-w*c+t*r-t*c+r^2-c^2,x*u-y*u+y*v+w^2+w*t+w*s+t^2-t*r,2*x*z+x*u-x*v-y*z-y*v+w*t-t^2+t*r];

// Singular plane model
model_1 := [2*x^6*y^9+6*x^3*y^12+9*y^15-3*x^6*y^8*z-72*x^3*y^11*z-81*y^14*z-15*x^6*y^7*z^2+108*x^3*y^10*z^2+351*y^13*z^2+24*x^6*y^6*z^3+618*x^3*y^9*z^3-1008*y^12*z^3+30*x^6*y^5*z^4-1566*x^3*y^8*z^4+2106*y^11*z^4-57*x^6*y^4*z^5-432*x^3*y^7*z^5-3375*y^10*z^5-3*x^6*y^3*z^6+3978*x^3*y^6*z^6+4221*y^9*z^6+33*x^6*y^2*z^7-3240*x^3*y^5*z^7-4131*y^8*z^7-15*x^6*y*z^8-54*x^3*y^4*z^8+3078*y^7*z^8+2*x^6*z^9+942*x^3*y^3*z^9-1611*y^6*z^9-288*x^3*y^2*z^10+405*y^5*z^10+189*y^4*z^11+6*x^3*z^12-279*y^3*z^12+162*y^2*z^13-54*y*z^14+9*z^15];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 54.72.3.d.1
//   Coordinate number 0:
map_0_coord_0 := 1*(3*c);
//   Coordinate number 1:
map_0_coord_1 := 1*(3*z);
//   Coordinate number 2:
map_0_coord_2 := 1*(-z+d);
// Codomain equation:
map_0_codomain := [x^3*y+x^3*z+3*y^3*z+3*y^2*z^2+3*y*z^3];

// Map from the canonical model to the plane model of modular curve with label 54.216.13.bc.1
//   Coordinate number 0:
map_1_coord_0 := 1*(c);
//   Coordinate number 1:
map_1_coord_1 := 1*(1/3*a);
//   Coordinate number 2:
map_1_coord_2 := 1*(1/3*b);
// Codomain equation:
map_1_codomain := [2*x^6*y^9+6*x^3*y^12+9*y^15-3*x^6*y^8*z-72*x^3*y^11*z-81*y^14*z-15*x^6*y^7*z^2+108*x^3*y^10*z^2+351*y^13*z^2+24*x^6*y^6*z^3+618*x^3*y^9*z^3-1008*y^12*z^3+30*x^6*y^5*z^4-1566*x^3*y^8*z^4+2106*y^11*z^4-57*x^6*y^4*z^5-432*x^3*y^7*z^5-3375*y^10*z^5-3*x^6*y^3*z^6+3978*x^3*y^6*z^6+4221*y^9*z^6+33*x^6*y^2*z^7-3240*x^3*y^5*z^7-4131*y^8*z^7-15*x^6*y*z^8-54*x^3*y^4*z^8+3078*y^7*z^8+2*x^6*z^9+942*x^3*y^3*z^9-1611*y^6*z^9-288*x^3*y^2*z^10+405*y^5*z^10+189*y^4*z^11+6*x^3*z^12-279*y^3*z^12+162*y^2*z^13-54*y*z^14+9*z^15];
