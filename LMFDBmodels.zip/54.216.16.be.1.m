
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 54.216.16.be.1

// Other names and/or labels
// Cummins-Pauli label: 54C16
// Rouse-Sutherland-Zureick-Brown label: 54.216.16.10

// Group data
level := 54;
// Elements that, together with Gamma(level), generate the group
gens := [[20, 49, 21, 16], [31, 47, 21, 22], [35, 5, 39, 26], [47, 2, 12, 29]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 216;

// Curve data
conductor := [[2, 18], [3, 78]];
bad_primes := [2, 3];
// Genus
g := 16;
// Rank
r := 6
;// Exact gonality known
gamma := 6;

// Modular data
// Number of cusps
Ncusps := 6
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-3];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["18.72.2.f.1", "27.108.7.f.1", "54.72.6.b.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
