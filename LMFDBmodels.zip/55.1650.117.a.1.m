
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 55.1650.117.a.1


// Group data
level := 55;
// Elements that, together with Gamma(level), generate the group
gens := [[8, 20, 9, 47], [29, 36, 2, 36], [47, 53, 50, 46]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 1650;

// Curve data
conductor := [[5, 212], [11, 222]];
bad_primes := [5, 11];
// Genus
g := 117;
// Rank
r := 72
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 30
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["55.825.57.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
