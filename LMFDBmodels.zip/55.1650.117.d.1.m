
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 55.1650.117.d.1


// Group data
level := 55;
// Elements that, together with Gamma(level), generate the group
gens := [[19, 10, 25, 24], [37, 50, 31, 18], [51, 54, 25, 23]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 1650;

// Curve data
conductor := [[5, 187], [11, 234]];
bad_primes := [5, 11];
// Genus
g := 117;
// Rank
r := 90
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 30
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-4, -16];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["55.825.57.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
