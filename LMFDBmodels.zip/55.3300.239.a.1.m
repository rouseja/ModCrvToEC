
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 55.3300.239.a.1


// Group data
level := 55;
// Elements that, together with Gamma(level), generate the group
gens := [[17, 0, 38, 38], [17, 19, 36, 53], [46, 36, 19, 10]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 3300;

// Curve data
conductor := [[5, 432], [11, 462]];
bad_primes := [5, 11];
// Genus
g := 239;
// Rank
r := 145
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 60
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-3];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["55.1100.76.d.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
