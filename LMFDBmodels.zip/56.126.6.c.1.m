
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 56.126.6.c.1

// Other names and/or labels
// Cummins-Pauli label: 28I6
// Rouse-Sutherland-Zureick-Brown label: 56.126.6.2

// Group data
level := 56;
// Elements that, together with Gamma(level), generate the group
gens := [[9, 4, 18, 21], [9, 4, 30, 47], [17, 18, 18, 43], [31, 41, 6, 7], [41, 27, 12, 1]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 126;

// Curve data
conductor := [[2, 26], [7, 12]];
bad_primes := [2, 7];
// Genus
g := 6;
// Rank
r := 0
;// Exact gonality known
gamma := 4;

// Modular data
// Number of cusps
Ncusps := 6
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['7.21.0.a.1', '8.6.0.e.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["8.6.0.e.1", "14.63.2.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u> := PolynomialRing(Rationals(), 6);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x*z-y*z-x*w-y*w+2*x*t-y*u,x*z+y*z+x*w+y*t+x*u-3*y*u,2*x^2+2*x*y-4*y^2-z*w-w^2-z*t+w*t-t*u,2*x^2+4*x*y+z^2+2*z*t+t^2-z*u+w*u-2*t*u,4*x^2-6*x*y+z^2+2*z*w+w^2+w*u-t*u,2*x^2+4*x*y-z^2-z*w-w^2-z*t+w*t-t^2-4*w*u+4*t*u-u^2];

// Singular plane model
model_1 := [2*x^10-56*x^9*y+512*x^8*y^2+20*x^8*z^2-1676*x^7*y^3-256*x^7*y*z^2+1736*x^6*y^4+973*x^6*y^2*z^2+2*x^6*z^4+224*x^5*y^5-1246*x^5*y^3*z^2-32*x^5*y*z^4-126*x^4*y^6+14*x^4*y^4*z^2+148*x^4*y^2*z^4-248*x^3*y^7+231*x^3*y^5*z^2-156*x^3*y^3*z^4+203*x^2*y^6*z^2+18*x^2*y^4*z^4+16*x*y^9-23*x*y^7*z^2+20*x*y^5*z^4+8*y^10-8*y^8*z^2+2*y^6*z^4];

// Maps from this modular curve, if computed

// j-invariant map from the canonical model
//   Coordinate number 0:
map_0_coord_0 := 2^6*(38483424*z*w*t^11-210335832*z*w*t^10*u-760438800*z*w*t^9*u^2+1496914776*z*w*t^8*u^3+10512330660*z*w*t^7*u^4+11798133172*z*w*t^6*u^5-32865369768*z*w*t^5*u^6-116717265770*z*w*t^4*u^7-190294929972*z*w*t^3*u^8-203073771110*z*w*t^2*u^9+719915907375*z*w*t*u^10+1142824318279*z*w*u^11-61641216*z*t^12+221872392*z*t^11*u+488462616*z*t^10*u^2-527465304*z*t^9*u^3-3857909868*z*t^8*u^4-3974181320*z*t^7*u^5+8653280244*z*t^6*u^6+17125605854*z*t^5*u^7-50332531046*z*t^4*u^8-62559985306*z*t^3*u^9+289526905843*z*t^2*u^10-45489104038*z*t*u^11+98684763387*z*u^12-381024*w^2*t^11-134173368*w^2*t^10*u+211150800*w^2*t^9*u^2+1847532456*w^2*t^8*u^3+1702851372*w^2*t^7*u^4-8360627940*w^2*t^6*u^5-30544910872*w^2*t^5*u^6-25587399866*w^2*t^4*u^7+45843715820*w^2*t^3*u^8+57226153054*w^2*t^2*u^9+257491270561*w^2*t*u^10+649996130693*w^2*u^11+5673024*w*t^12+170815176*w*t^11*u-1257791544*w*t^10*u^2-774475992*w*t^9*u^3+9957576852*w*t^8*u^4+15590224672*w*t^7*u^5-21180397588*w*t^6*u^6-86848684930*w*t^5*u^7-159775300090*w*t^4*u^8-79715929370*w*t^3*u^9+1025327840075*w*t^2*u^10+91400829156*w*t*u^11-1219975892163*w*u^12-28449792*t^13-89921664*t^12*u+1659168576*t^11*u^2-200076696*t^10*u^3-13929043752*t^9*u^4-14206447816*t^8*u^5+49592311644*t^7*u^6+114333666468*t^6*u^7+47550312152*t^5*u^8+64038995678*t^4*u^9-1160232423826*t^3*u^10-554359841854*t^2*u^11+2056119419249*t*u^12-364210257355*u^13);
//   Coordinate number 1:
map_0_coord_1 := 1*(1425312*z*w*t^11-7790216*z*w*t^10*u-12058492*z*w*t^9*u^2+16027648*z*w*t^8*u^3+73883335*z*w*t^7*u^4+146746033*z*w*t^6*u^5+127160243*z*w*t^5*u^6+88819003*z*w*t^4*u^7+145601757*z*w*t^3*u^8+179894127*z*w*t^2*u^9+97739761*z*w*t*u^10+18841529*z*w*u^11-2283008*z*t^12+8217496*z*t^11*u-4353340*z*t^10*u^2+2679476*z*t^9*u^3+3098369*z*t^8*u^4+8471488*z*t^7*u^5+31447122*z*t^6*u^6+75703810*z*t^5*u^7+125085786*z*t^4*u^8+103268284*z*t^3*u^9+43119258*z*t^2*u^10+8289134*z*t*u^11+606277*z*u^12-14112*w^2*t^11-4969384*w^2*t^10*u+9577932*w^2*t^9*u^2+12589472*w^2*t^8*u^3+32786357*w^2*t^7*u^4+16532943*w^2*t^6*u^5-42779891*w^2*t^5*u^6-120648731*w^2*t^4*u^7-113097985*w^2*t^3*u^8-39130007*w^2*t^2*u^9+1834119*w^2*t*u^10+2694951*w^2*u^11+210112*w*t^12+6326488*w*t^11*u-47478044*w*t^10*u^2+63083100*w*t^9*u^3+3843533*w*t^8*u^4+114459638*w*t^7*u^5-10274712*w*t^6*u^6+14502992*w*t^5*u^7+83074404*w*t^4*u^8-11961418*w*t^3*u^9-158054484*w*t^2*u^10-117757584*w*t*u^11-25541593*w*u^12-1053696*t^13-3330432*t^12*u+54247688*t^11*u^2-95460896*t^10*u^3+4723482*t^9*u^4-131238316*t^8*u^5+113783571*t^7*u^6+148965831*t^6*u^7+66760995*t^5*u^8+115183901*t^4*u^9+224053193*t^3*u^10+121219497*t^2*u^11+4564203*t*u^12-6979021*u^13);

// Map from the canonical model to the plane model of modular curve with label 56.126.6.c.1
//   Coordinate number 0:
map_1_coord_0 := 1*(x);
//   Coordinate number 1:
map_1_coord_1 := 1*(y);
//   Coordinate number 2:
map_1_coord_2 := 1*(z);
// Codomain equation:
map_1_codomain := [2*x^10-56*x^9*y+512*x^8*y^2+20*x^8*z^2-1676*x^7*y^3-256*x^7*y*z^2+1736*x^6*y^4+973*x^6*y^2*z^2+2*x^6*z^4+224*x^5*y^5-1246*x^5*y^3*z^2-32*x^5*y*z^4-126*x^4*y^6+14*x^4*y^4*z^2+148*x^4*y^2*z^4-248*x^3*y^7+231*x^3*y^5*z^2-156*x^3*y^3*z^4+203*x^2*y^6*z^2+18*x^2*y^4*z^4+16*x*y^9-23*x*y^7*z^2+20*x*y^5*z^4+8*y^10-8*y^8*z^2+2*y^6*z^4];
