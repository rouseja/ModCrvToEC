
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 56.126.8.a.1

// Other names and/or labels
// Cummins-Pauli label: 28A8
// Rouse-Sutherland-Zureick-Brown label: 56.126.8.2

// Group data
level := 56;
// Elements that, together with Gamma(level), generate the group
gens := [[9, 23, 18, 19], [19, 28, 22, 37], [21, 3, 4, 7], [53, 50, 36, 35], [53, 52, 52, 27]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 126;

// Curve data
conductor := [[2, 38], [7, 16]];
bad_primes := [2, 7];
// Genus
g := 8;
// Rank
r := 0
;// Exact gonality known
gamma := 4;

// Modular data
// Number of cusps
Ncusps := 6
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["14.63.2.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r> := PolynomialRing(Rationals(), 8);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [w*t+w*u-u*r-r^2,w^2-w*u-z*v-w*v-v^2+z*r-u*r+v*r-r^2,z^2+z*w+w*t+w*u+z*v+z*r+t*r+u*r+v*r,z^2+z*w-z*u+z*v+t*v+u*v+v*r,z*w+t*u+v^2+t*r+u*r-v*r+r^2,z*w+w*r-v*r+r^2,t^2+z*v-v^2+z*r+w*r+v*r,w^2+z*t+w*t-w*u-t*u+t*v-v^2-w*r-r^2,x*z-y*z+x*w-x*t-x*v+y*v+x*r-2*y*r,2*y*z+x*w+y*w+y*t+x*v+x*r,y*z-x*w+y*w-x*t+2*y*t-y*v-y*r,x*z+y*w-y*t-x*u-2*y*u+2*x*v-y*v-x*r,6*x^2+10*x*y-4*y^2-z*w-w^2+w*u-w*v+2*t*v+2*u*v-v^2+w*r+t*r+u*r+v*r+r^2,2*x^2+8*x*y+8*y^2+z*t-w*t-t^2+z*u+2*w*u-t*u+z*v-w*v+t*v-u*v+2*v^2+2*z*r+w*r-t*r+u*r,18*x^2-12*x*y+2*y^2+z^2+2*z*w+w^2-3*z*t-w*t-2*z*u-w*u+t*u+2*u^2+2*z*v+2*w*v-2*t*v-3*u*v-v^2+t*r-v*r-r^2];

// Singular plane model
model_1 := [8*x^14-64*x^13*y-32*x^12*y^2+40*x^12*z^2+1144*x^11*y^3-760*x^11*y*z^2-576*x^10*y^4+5644*x^10*y^2*z^2+2*x^10*z^4-8032*x^9*y^5-21976*x^9*y^3*z^2-44*x^9*y*z^4+3330*x^8*y^6+50431*x^8*y^4*z^2+374*x^8*y^2*z^4+24160*x^7*y^7-71394*x^7*y^5*z^2-1636*x^7*y^3*z^4-1192*x^6*y^8+61614*x^6*y^6*z^2+4270*x^6*y^4*z^4-14624*x^5*y^9-33639*x^5*y^7*z^2-6804*x^5*y^5*z^4+6376*x^4*y^10+13453*x^4*y^8*z^2+6300*x^4*y^6*z^4-4288*x^3*y^11-8333*x^3*y^9*z^2-2600*x^3*y^7*z^4+1856*x^2*y^12+4236*x^2*y^10*z^2-158*x^2*y^8*z^4-256*x*y^13+160*x*y^11*z^2+272*x*y^9*z^4+128*y^14-128*y^12*z^2+32*y^10*z^4];

// Maps from this modular curve, if computed

// j-invariant map from the canonical model
//   Coordinate number 0:
map_0_coord_0 := 1*(77035840*z*v^9-417412448*z*v^8*r+1026478448*z*v^7*r^2-1403432824*z*v^6*r^3+1186824676*z*v^5*r^4+725138*z*v^4*r^5+402620455*z*v^3*r^6+261427647*z*v^2*r^7-600875838*z*v*r^8+1580538122*z*r^9+4125316320*w*u*r^8+90112000*w*v^9-451992384*w*v^8*r+1152331488*w*v^7*r^2-1744432784*w*v^6*r^3+1812740184*w*v^5*r^4-1299040556*w*v^4*r^5+308373878*w*v^3*r^6+1246448533*w*v^2*r^7-2380308701*w*v*r^8-1253423338*w*r^9-10272256*t*v^9+6163968*t*v^8*r-44563168*t*v^7*r^2+248667648*t*v^6*r^3-613238616*t*v^5*r^4+265546080*t*v^4*r^5+332514468*t*v^3*r^6-1821142558*t*v^2*r^7+2185058568*t*v*r^8+1967848266*t*r^9-110592*u^8*r^2+635904*u^7*v*r^2+3939840*u^7*r^3-13858560*u^6*v*r^3-33428736*u^6*r^4+113945792*u^5*v*r^4+188411360*u^5*r^5-348701440*u^4*v*r^5+216197696*u^4*r^6-90138172*u^3*v*r^6+1020858902*u^3*r^7-1508105833*u^2*v*r^7-7182822388*u^2*r^8-38944256*u*v^9+228133696*u*v^8*r-833194944*u*v^7*r^2+1618228976*u*v^6*r^3-2221505552*u*v^5*r^4+1049079268*u*v^4*r^5+189446786*u*v^3*r^6-4496418229*u*v^2*r^7+2899341550*u*v*r^8-2097598230*u*r^9+65536000*v^10-292187520*v^9*r+619116288*v^8*r^2-956282112*v^7*r^3+1056970016*v^6*r^4-83206288*v^5*r^5-84094240*v^4*r^6+1093983965*v^3*r^7+1520218126*v^2*r^8+2923514085*v*r^9-1228512064*r^10);
//   Coordinate number 1:
map_0_coord_1 := 1*(8232*z*v^9-68560*z*v^8*r+256548*z*v^7*r^2-536155*z*v^6*r^3+643746*z*v^5*r^4-486865*z*v^4*r^5+283382*z*v^3*r^6+468071*z*v^2*r^7-343389*z*v*r^8-289522*z*r^9+914110*w*u*r^8+11264*w*v^9-98024*w*v^8*r+374304*w*v^7*r^2-781162*w*v^6*r^3+1068911*w*v^5*r^4-834503*w*v^4*r^5+412985*w*v^3*r^6+85483*w*v^2*r^7-1465204*w*v*r^8+1298394*w*r^9-3520*t*v^9+28960*t*v^8*r-114066*t*v^7*r^2+246794*t*v^6*r^3-413367*t*v^5*r^4+344748*t*v^4*r^5-317631*t*v^3*r^6-211592*t*v^2*r^7+1755376*t*v*r^8-1392502*t*r^9-64*u^8*r^2+368*u^7*v*r^2-72*u^7*r^3+1976*u^6*v*r^3+2476*u^6*r^4+10638*u^5*v*r^4+10342*u^5*r^5+24685*u^4*v*r^5-78310*u^4*r^6+288559*u^3*v*r^6+23562*u^3*r^7-649254*u^2*v*r^7-505386*u^2*r^8-7104*u*v^9+60872*u*v^8*r-257410*u*v^7*r^2+582946*u*v^6*r^3-1031646*u*v^5*r^4+915188*u*v^4*r^5-921890*u*v^3*r^6-433410*u*v^2*r^7+2859262*u*v*r^8-3492370*u*r^9+8192*v^10-69424*v^9*r+254296*v^8*r^2-544584*v^7*r^3+647692*v^6*r^4-582872*v^5*r^5+400462*v^4*r^6+649715*v^3*r^7-426139*v^2*r^8+628850*v*r^9-1100460*r^10);

// Map from the canonical model to the plane model of modular curve with label 56.126.8.a.1
//   Coordinate number 0:
map_1_coord_0 := 1*(x);
//   Coordinate number 1:
map_1_coord_1 := 1*(y);
//   Coordinate number 2:
map_1_coord_2 := 1*(w);
// Codomain equation:
map_1_codomain := [8*x^14-64*x^13*y-32*x^12*y^2+40*x^12*z^2+1144*x^11*y^3-760*x^11*y*z^2-576*x^10*y^4+5644*x^10*y^2*z^2+2*x^10*z^4-8032*x^9*y^5-21976*x^9*y^3*z^2-44*x^9*y*z^4+3330*x^8*y^6+50431*x^8*y^4*z^2+374*x^8*y^2*z^4+24160*x^7*y^7-71394*x^7*y^5*z^2-1636*x^7*y^3*z^4-1192*x^6*y^8+61614*x^6*y^6*z^2+4270*x^6*y^4*z^4-14624*x^5*y^9-33639*x^5*y^7*z^2-6804*x^5*y^5*z^4+6376*x^4*y^10+13453*x^4*y^8*z^2+6300*x^4*y^6*z^4-4288*x^3*y^11-8333*x^3*y^9*z^2-2600*x^3*y^7*z^4+1856*x^2*y^12+4236*x^2*y^10*z^2-158*x^2*y^8*z^4-256*x*y^13+160*x*y^11*z^2+272*x*y^9*z^4+128*y^14-128*y^12*z^2+32*y^10*z^4];
