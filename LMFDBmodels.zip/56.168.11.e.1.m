
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 56.168.11.e.1

// Other names and/or labels
// Cummins-Pauli label: 28B11
// Rouse-Sutherland-Zureick-Brown label: 56.168.11.6

// Group data
level := 56;
// Elements that, together with Gamma(level), generate the group
gens := [[13, 11, 7, 50], [13, 27, 55, 38], [13, 50, 10, 15], [21, 1, 6, 7]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 168;

// Curve data
conductor := [[2, 58], [7, 22]];
bad_primes := [2, 7];
// Genus
g := 11;
// Rank
r := 5
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 6
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["28.84.4.a.1", "56.42.1.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r,s,a,b> := PolynomialRing(Rationals(), 11);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [2*x*s+y*v+2*y*r-y*s+z*v-z*r+2*z*s+w*v+w*r-t*a+u*v-u*r-v*b-r*b+2*s*b,2*y*s-z*v+z*r-2*z*s+w*v+w*r+t*a+u*v+u*s+u*a-v*b-r*b-2*s*b,x*r-2*x*s+x*a+y*v-y*s+y*a+z*v-w*v+t*s-u*v-u*r+v*b+r*b+s*b+a*b,x*s+y*v-y*s-z*v-z*r+z*s-w*v-2*w*r+t*s-u*v+u*r+v*b-r*b+s*b,x*r+2*x*s+2*y*v+y*r-z*v+z*s+t*v-t*a+u*v+s*b,x*v+x*r+y*r+y*s+z*r-z*s-t*v+t*s-u*v-u*r-r*b-s*b+a*b,x*v-x*s+y*r+y*s-z*v+z*r-2*z*s-w*a+t*a-2*s*b+a*b,x*v+x*s+x*a+y*v+y*r+w*r-w*s-u*r+u*s+a*b,x*v+x*r+2*x*s-z*v+z*r-z*a,x*y+x*t-y*z+z*u,x*w-x*t-x*u-z*t,2*x*s-x*a+y*r+z*s-w*v+t*v+t*r-u*r-r*b+s*b,x*v-2*x*s-x*a-2*y*v-z*s-z*a+w*v+t*s+t*a-u*v-u*s-u*a+v*b+r*b-s*b,x*v-y*v-y*a-w*a-t*r+2*t*s-u*s-s*b,x*s-x*a-y*s+z*v+z*s+z*a+w*v+w*r+t*v-t*r-t*s-t*a+2*u*v+u*s-u*a-v*b,x*r+y*r+y*s-z*v-w*v-w*r-w*s-t*v+t*r-t*s-t*a-v*b,2*x*v+x*s+x*a-y*r-y*a+z*a-w*r+w*s+t*v+t*a+u*v+2*u*r+u*a-r*b,y*w-2*y*t-y*u-w*u-t^2+t*u+u^2,x*y-y^2+y*z-y*t-z*t+z*b-w*t-w*u+w*b+t*u+u^2-u*b+b^2,2*x*w+y*z-y*w+y*b+z*w+w^2-w*t+w*b+t^2-u^2+u*b,x^2-x*w-y*z-y*b-z*t+z*b-w*t-w*u-w*b+t*u+t*b+u^2,x*z+2*x*w+x*b+y*z-2*y*w+y*u+z*w-w^2+w*u+w*b-t*b,x^2+x*z-x*w+x*u+x*b-y^2-y*w-y*t-y*u-y*b+z*u+z*b-w*t+w*b+t*b+u^2,x^2-x*z+x*u-x*b-y^2+y*z-y*u-z^2-z*t+z*u-w^2-w*t+t^2+2*t*b+u^2,2*x^2-x*y+x*z+x*w+x*b+y^2+y*u+w*t-u^2+b^2,2*x*y-2*x*z-x*w+x*t-x*u+x*b-y^2+y*z+y*u-z^2-z*w+z*t+w*t+w*u-w*b-t*u+t*b-u^2+b^2,x^2-x*y+x*z-2*x*u-x*b-y*t-z^2-z*w+z*t+z*u+2*z*b+w*u+w*b-t^2-t*b-2*v*r+2*v*s-2*v*a-r^2+r*s-2*r*a+s*a-a^2,2*x^2-x*y-2*x*z+2*x*t+x*b-y*w-y*t-y*u-y*b-z*w+z*b+w^2-w*t+w*u+2*t^2-t*u-2*u^2+2*v^2-v*r+3*v*a-r^2+a^2-b^2,x*y-2*x*z+2*x*w-x*t+x*u+y^2+2*y*z+y*w+y*u-z^2+2*z*b+w^2-w*t+w*u-2*t*b-u^2-v*r+2*v*s-2*r^2+2*r*s-2*r*a-s^2+s*a+2*a^2,3*x*z-x*w-x*u-2*y*z+y*w+2*y*u+y*b+2*z^2+z*w-z*t-z*u-2*z*b-w^2+w*b+2*t*b+u^2-u*b-v*s-v*a-2*r*s-2*r*a-s^2-2*s*a-a^2+2*b^2,x*y-x*z+x*w+2*x*u+2*x*b+y*z-y*w-y*b-z*t+z*u+w*t-w*u+t^2-t*u-t*b-u*b-2*v^2-3*v*r+3*v*a-r^2+r*a+2*a^2,x*z+x*w+x*t-x*b-y^2-y*w+y*t-y*u+2*z*w+z*t-2*z*b+w*t-w*u-2*w*b+2*t*b-2*v*r+3*v*s-v*a+r*s+2*r*a-3*s*a-a^2,x*y+x*z+x*u+x*b+y^2+y*z+y*w+y*t+y*u-y*b+z*w+z*u+z*b-w^2+w*u-2*w*b-t^2+2*t*u-u^2+2*v^2-v*r-3*v*s-r^2-r*s-r*a-2*s^2-s*a+2*a^2+b^2,x*y-3*x*z+x*u+x*b+2*y*w-y*t-y*u-y*b+2*z^2-2*z*w-3*z*t-2*z*u-2*w*t+2*w*u+t^2-3*t*b-u^2-u*b+v*r-4*v*s-2*v*a-r^2-r*s-2*r*a-s^2-2*s*a+a^2,2*x*z-x*u-x*b-y^2+y*w+y*t+y*u+y*b-z*w+z*t+z*b+3*w^2+2*w*t+w*u+2*w*b+t*u+2*t*b+u^2+v^2+2*v*r-2*v*s+v*a-r^2+r*s+3*r*a-s^2+s*a-2*a^2+b^2,x^2-x*y+2*x*z-x*u-2*x*b+y*u-y*b-z^2+z*w+2*z*t+z*u+2*z*b+w*u-w*b-t^2-t*u+u^2-u*b+2*v*r-4*v*s+r*s-3*s^2-2*s*a-a^2];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 28.84.4.a.1
//   Coordinate number 0:
map_0_coord_0 := 1*(-v);
//   Coordinate number 1:
map_0_coord_1 := 1*(-r);
//   Coordinate number 2:
map_0_coord_2 := 1*(s);
//   Coordinate number 3:
map_0_coord_3 := 1*(a);
// Codomain equation:
map_0_codomain := [2*x^2+12*x*y+5*y^2+12*x*z+2*y*z-z^2-3*x*w-5*y*w-w^2,x^2*y+5*x*y^2+2*y^3-3*x^2*z-y^2*z-3*x*z^2-y*z^2+x^2*w+x*y*w-y^2*w+5*x*z*w+3*y*z*w-z^2*w-x*w^2-y*w^2];
