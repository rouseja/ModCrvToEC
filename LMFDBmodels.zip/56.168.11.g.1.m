
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 56.168.11.g.1

// Other names and/or labels
// Cummins-Pauli label: 28B11
// Rouse-Sutherland-Zureick-Brown label: 56.168.11.8

// Group data
level := 56;
// Elements that, together with Gamma(level), generate the group
gens := [[13, 5, 55, 50], [29, 2, 15, 55], [34, 39, 25, 53], [42, 1, 15, 10]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 168;

// Curve data
conductor := [[2, 58], [7, 20]];
bad_primes := [2, 7];
// Genus
g := 11;
// Rank
r := 8
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 6
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["28.84.4.a.1", "56.42.1.c.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r,s,a,b> := PolynomialRing(Rationals(), 11);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x*v+y*z-z^2-z*w+u*v,x*a-y*r-y*s+z*r-z*s+w*r+t*b+u*a+u*b-v*r,x*r+x*s-y*r-y*s-y*a-y*b+z*a+z*b+w*r+t*s-t*a+u*s+u*a+v*b,2*y*r-2*y*s+y*a+y*b-z*a-w*r+u*s-u*a-v*r+2*v*s-v*a-v*b,x*b-y*r-y*b-z*r+2*z*s-w*r+2*u*s-u*b+2*v*s-v*b,x*r-y*r-y*a+z*r+z*s-w*r+t*s-t*a+u*r+2*u*s-u*b-2*v*r+v*s,y*s-y*b-2*z*s+z*a+2*z*b+w*r-t*s+t*a+t*b-u*r+u*a+u*b-2*v*s,x*s-x*b-y*r+y*a+z*b+w*r-t*r+t*a+t*b-u*r+u*s+u*a-v*r-v*s-v*a,x*r+x*a+y*r-y*s-y*a-y*b-z*r-w*r+w*b+t*s-t*a+u*r+u*s+v*s-v*a,x*s-x*b+y*r-y*a-z*r+z*a+w*a-u*s+v*r-v*s-v*a+v*b,x*r+x*b-y*s-y*b-z*r-z*s+z*a+z*b-w*s+w*a+u*s+v*s-v*b,x*s-x*b-w*r+w*b+u*r+u*s-u*a-u*b-v*s-v*b,x*r+x*s-x*b-y*r+y*s-y*a-y*b+z*s-z*b+w*r-w*s+w*a+w*b+u*r-u*s-v*r-v*s+v*b,2*x*a-x*b-y*r+y*s+2*z*s-z*b+t*r+t*s+u*r+u*s-u*b,x*r-x*b-y*r+y*s-z*r+z*a+w*s-t*s+t*a+t*b+u*r-v*s,x*s-x*a+x*b-2*y*s-y*b+z*s-z*a-z*b-w*r+w*a+t*s-t*a-t*b+u*s-u*a-u*b-v*r+v*s+2*v*a,x*z-y*z+y*v+z^2+z*u+t*v-2*v^2,x^2-3*x*y+x*w+x*u+y^2-y*z-y*u+y*v-t*v-u*v-v^2,x^2-x*y-x*z-x*t+x*v-y^2+y*z+y*w-y*u+y*v+z*w+z*u-2*w*v+t*v-v^2,x^2-x*y+x*z-x*t+x*v+y^2-y*t-y*u-z^2+z*w+z*u-2*z*v-w*u-w*v-t^2-t*u-v^2,x^2+x*z-x*w+x*u-y^2+y*z-y*u+z*w-2*z*v-w*t-w*u+u^2+u*v+v^2,x*y+x*z-x*w-x*u-y*z-y*w+y*t-y*v+z^2+z*w-z*t-2*w*t-w*u+2*w*v+t*v+u*v-v^2,x^2-2*x*y+x*w-y^2-y*z-y*t+2*y*u-z*w-z*t+w^2+w*t-w*u-u^2,x^2-x*y-x*z-x*w-x*t-x*u-x*v+y*z+y*t+y*u+y*v-z^2-z*t-z*u+w^2-w*t-2*w*u-w*v+t*v-u^2+u*v+v^2,x*z+x*u-x*v-2*y*w+y*t+y*u+y*v+w^2+w*t+w*u-w*v+t^2+t*v+u*v+2*v^2,2*x*y-x*z-x*u-y^2+y*z-y*w-2*y*t-2*y*u+z*w+z*t+z*u-w*t-t^2+u^2,x*y+x*z+x*u+x*v-y^2+y*z-2*y*w+y*u+y*v-z*t+z*u+2*w*t-w*v-t^2-t*u-t*v-r^2+2*r*s-r*b-s*a,x^2-x*y+2*x*z+x*t-x*u+x*v+y^2-y*z-y*u+z*w+2*z*v-w*u+t*u-u^2-u*v+v^2-r*s+r*b+2*s*a-s*b-a^2-a*b+b^2,x^2-2*x*y+2*x*w+2*x*t+x*u-x*v+2*y*z+y*u+y*v+z*u+2*z*v-2*t^2-t*u+t*v+u*v+2*r*s-3*s*a+a^2+a*b,2*x^2+2*x*y-x*w+x*u+x*v+2*y^2-y*z+2*y*w-y*t-2*y*u+y*v-z^2+2*z*t-w*t-w*u+w*v+t^2+2*t*u+t*v+u*v+r*s-r*a+r*b+2*s^2-2*s*b+b^2,x^2+2*x*y-2*x*z-x*t+x*u-x*v-4*y^2+y*t-y*u-2*y*v-2*z^2+z*t+z*u+w^2+w*v+t*u+u*v-v^2-r^2+2*r*s-r*a-r*b-s^2+2*s*a+s*b-a^2-a*b,x^2+x*y-x*z+x*w-x*t+3*x*u-x*v+2*y^2+2*y*z+2*y*u+2*y*v+2*z^2-z*w-2*z*t-2*z*u+w*u-t*u-2*t*v+u^2-u*v-2*r*s+r*a-r*b+s^2+s*b,x^2-2*x*y-x*w+3*x*t+x*u+x*v-2*y*z-2*y*w+3*y*t+2*y*v+2*z*t+2*z*v-2*w^2-w*t-w*u-w*v-t^2-t*u+2*v^2+r*s+r*b+s^2-2*s*a-s*b,x*y+x*z-x*v-y^2+y*z+y*t+y*v+2*z^2-3*z*w+z*t-2*z*u-w^2-3*w*t+w*u-2*w*v-t*u-t*v+2*u^2-2*u*v+r^2-r*s+r*a+r*b-2*s*a+s*b+a^2+a*b-b^2,x*y-2*x*z-2*x*w+x*t+2*x*v+2*y^2-2*y*w-y*t-2*y*v+2*z^2+z*w-2*z*t-z*u-w^2+w*t-w*v+t^2+t*u+2*t*v-r*s+s^2-a*b,2*x^2+2*x*z+x*u-x*v+y^2-2*y*z+y*w-2*y*t+y*u+2*y*v-z^2-z*w+z*t+z*u+2*z*v-w^2-w*t-w*u+t^2-t*u-2*t*v-u^2-u*v+2*r*s-r*a+s*a];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 28.84.4.a.1
//   Coordinate number 0:
map_0_coord_0 := 1*(s);
//   Coordinate number 1:
map_0_coord_1 := 1*(-a);
//   Coordinate number 2:
map_0_coord_2 := 1*(r);
//   Coordinate number 3:
map_0_coord_3 := 1*(b);
// Codomain equation:
map_0_codomain := [2*x^2+12*x*y+5*y^2+12*x*z+2*y*z-z^2-3*x*w-5*y*w-w^2,x^2*y+5*x*y^2+2*y^3-3*x^2*z-y^2*z-3*x*z^2-y*z^2+x^2*w+x*y*w-y^2*w+5*x*z*w+3*y*z*w-z^2*w-x*w^2-y*w^2];
