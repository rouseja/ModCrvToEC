
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 56.168.12.b.1

// Other names and/or labels
// Cummins-Pauli label: 28A12
// Rouse-Sutherland-Zureick-Brown label: 56.168.12.2

// Group data
level := 56;
// Elements that, together with Gamma(level), generate the group
gens := [[17, 40, 39, 11], [25, 13, 41, 52], [29, 40, 19, 23], [53, 47, 35, 38]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 168;

// Curve data
conductor := [[2, 64], [7, 24]];
bad_primes := [2, 7];
// Genus
g := 12;
// Rank
r := 7
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 6
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['7.21.0.a.1', '8.8.0.b.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["8.8.0.b.1", "28.84.4.a.1", "56.42.3.b.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r,s,a,b,c> := PolynomialRing(Rationals(), 12);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x*b-z*r-w*r+w*b-t*r-t*b+u*r-u*a-u*b+u*c+v*r+r*s+s*a-s*b+s*c,x*r+x*b-y*r-y*b-z*r+2*t*b-2*u*r+u*b-v*r+r*s,x*r-x*b-x*c-y*r+y*b-z*r-w*r-w*a+t*r+t*b-u*r+u*a-u*b-v*r+2*v*b+2*r*s+s*b,x*r+x*a+3*x*b-y*b+w*r+2*w*a+w*b-t*r-t*b+2*u*r-u*a+u*c-v*r+v*a+v*b-v*c-r*s,x*r+x*a-x*b-y*a-y*b-2*z*a-w*r-w*a+2*w*b-u*r+u*b-u*c-2*v*a+v*c-2*s*b,x*r+x*a+3*x*b-x*c+y*a+y*b-y*c-z*r+w*r+w*a+u*r-u*a+u*b+u*c-v*r-v*a-v*b-v*c+r*s-s*a-s*b,x*r-x*a+x*b-y*r+2*z*a-2*w*r-w*a+w*b-t*r-t*b-t*c+u*r-v*r-v*a+v*b+s*a,x*r-x*b-y*a+z*r-2*w*r-t*r+t*a-2*t*b-t*c-u*c+v*r-v*a-2*v*b-r*s-s*b,x*a-y*a-z*r-w*a-w*b+w*c+t*r+t*b+2*u*a-u*c-v*r+v*b+r*s+s*b,x*r+x*a+x*b-x*c+y*r+z*r-z*c+w*r-w*b+w*c-u*c-v*a-v*b-r*s-s*a,x*a-x*c-y*r-y*a-y*b+y*c-2*z*a-z*c+w*a+w*b-w*c+t*c-u*r-u*a-u*b-v*r+v*a+v*b-v*c-r*s,x*r-x*b-y*b-z*a-z*b-w*r-w*a+2*t*b-u*r+2*u*a-u*c-v*a+v*c-s*a,x*r-2*x*b-y*r-y*a+y*b+z*r+z*c+w*c+u*r-u*b+u*c+v*a+v*b-v*c-s*c,x*r-2*x*b+y*r-z*a+z*b-w*r-w*a+2*t*r+t*a-t*b+u*a-u*c-v*r-2*v*a+r*s,2*x*r-y*r-y*a-y*b-w*a-w*b+w*c-2*t*r-t*a+t*b-t*c-u*r+u*a+u*b-2*u*c-v*r-v*a-v*b-r*s,x*r-x*b-x*c+y*r+y*a+y*b+y*c-z*r+w*r-w*b+w*c+t*r+3*t*b-u*r-u*a+u*c-v*r+v*a+r*s-s*a-s*c,x*r+x*a-2*x*b-x*c+y*b+y*c+z*a+z*b-w*r-w*a+2*t*b-2*u*r-u*a+u*c+v*r+v*c+r*s,x*r+x*a+2*x*b+x*c-y*r+z*a-z*b+w*a-w*b-w*c-u*r-u*a+u*b-v*r+2*v*a-v*c+s*b,2*x*t+y*w+z*t,x^2+x*y-x*z-2*x*w+x*t+x*v+3*x*s-y^2+y*w-2*y*v-y*s-2*z*u+w^2-w*u-w*s-t^2+t*v-t*s-u^2-2*u*v-v^2,x^2-x*y+x*z-2*x*w+x*u+2*x*s-y^2+2*y*z+y*w+y*u-y*v-y*s-z*t-w^2-3*w*v-w*s+2*t*v+t*s-u*v-v^2,2*x^2+x*y-x*w-x*t+x*u-x*v-x*s-y^2-y*z+z*u-z*v-2*w^2-2*w*v+w*s+t^2+2*t*u-t*v+u^2+u*v,x*y-x*z+x*w-x*u+2*x*v-y*z+y*w+y*u+y*v-2*y*s-z*u-z*v+w*t+w*s+t^2+2*t*u-t*v+u^2-u*v-2*u*s+2*v*s+s^2,x^2-x*y+4*x*w+x*t-x*u+x*v-2*x*s-y*z-2*y*w+y*u+y*s+2*z*t+z*u+z*v+w^2+w*v-w*s-t*u-t*v-2*u^2+2*u*v+2*u*s-v*s,x^2-x*y+2*x*z-x*w+2*x*v+2*x*s+y*w+y*t-2*y*v-z*u+z*v+z*s-w^2-w*t-w*v-w*s-t*u-t*v-u^2+u*v+u*s-3*v*s-s^2,3*x^2-3*x*y+2*x*z-2*y*z-y*w-y*u-y*v+y*s+z*t+z*u+z*v+z*s-2*w^2-w*t-2*w*v-u^2+v^2,x^2+x*t+2*x*u+x*v+2*x*s-y^2+y*z+y*w-y*s-z*t-z*u+z*v+w^2+w*u-2*w*s-t*u-t*v-u^2+u*v+2*u*s-2*v*s-s^2,x^2+x*y-x*z-x*t-x*u+x*v+2*x*s-y^2+y*u-2*y*s-z*w-z*t-z*u+z*s+w^2+w*t+w*u-w*s+t^2+t*u-2*t*v,3*x^2-2*x*y+x*t+x*v+y*w+z*w+3*z*u-z*s-2*w^2-2*w*v+w*s+t^2-t*v+u^2+u*s+v^2-s^2,x*y-x*z+2*x*w-2*x*u-x*s-y*z+y*t-y*u+y*v+y*s-z*w+z*u+w^2+w*t+2*w*u+w*v+w*s-t*s+2*u^2-3*u*s+2*v*s,2*x*y+x*w-x*t+3*x*v-x*s-y^2-2*y*z+y*t-y*v+2*z*t-2*z*v+w*u-w*v-w*s+t*u-t*v-t*s+u*v-u*s-v^2+s^2,x*y+x*w+x*t+x*u+x*v+x*s-y^2+2*y*z+y*w+y*t-y*v-z*t+2*z*v+w*u-w*v-w*s+u^2-u*v-v*s-s^2,3*x*w-y*w+y*t-2*z*w,x^2+x*z+x*u-2*x*v-2*x*s-y*z-y*w+y*u-y*v-z*w+2*z*t+z*u-2*z*v+w^2-2*w*u+w*v-w*s+t*u-t*v+u*s+s^2,x^2-x*t+x*v-x*s+y*t-y*u-y*v+y*s-2*z^2+z*t+z*s-w*t+w*u+w*v-w*s-2*t*v+u^2+v^2-2*v*s,2*x*y-x*z+x*w+x*s+y^2-y*z-y*w+2*y*t+y*u+2*y*v+y*s-z*t-z*u-z*v+2*w^2-2*w*t+2*w*u-2*w*s-t*u+t*v+t*s+u*v-v^2-v*s+r*a+a^2,x*w-x*t+x*u-x*v-2*x*s-y^2+y*w+y*u-2*y*v-z*t+2*z*v-w^2-w*t+w*u+w*s+t^2+t*u-2*t*v-2*t*s+u^2+2*u*v-2*u*s-v^2-2*r*a-r*b-s^2-a^2,2*x*z-x*w+y^2-2*y*u+2*y*v+y*s+z*t+z*u-z*v+z*s-w^2-w*t-w*u-2*w*v+w*s-t^2-2*t*u+t*v-t*s-2*u*s-r*b-a*b,3*x^2-x*z+2*x*w-x*u-x*s-y^2-2*y*z-y*w-y*t+2*y*u+2*y*s+2*z*t+2*z*u-w*t+2*w*u-t*u+t*v+t*s+2*u^2+2*v^2+2*r*a+r*b-s^2+a^2+a*c,x^2+2*x*y+x*w+x*t+x*u+x*v-x*s+y*z-2*y*w-y*t+2*y*u-2*y*s-z*w+z*t-2*z*u-z*v-z*s+2*w^2-w*t+2*t^2+2*t*u-2*t*v+u*v-v^2+v*s+r^2+2*r*a+2*r*b+r*c+s^2+a^2+a*c,x^2+x*y+x*w-x*t-3*x*u+x*v-x*s-y^2-2*y*z+y*t-y*u+y*v+z*w+z*u+z*s-3*w^2-w*t+w*u+2*w*v+w*s-t^2-t*u+2*u^2+2*u*v+u*s+2*v^2-v*s-r^2+3*r*b-s^2+a*b-b^2+b*c,x*y-x*w-2*x*v+x*s+y^2+y*z-2*y*w-y*t-y*u-y*v+2*z*w+2*z*u-2*z*v-z*s-w^2-w*t-w*v-t^2+t*v-3*t*s+4*u^2-u*s-2*v^2+v*s+r*b-s^2-b^2+b*c,x^2-2*x*y+x*w-x*t-x*v-x*s-y*z+y*w+y*u-y*v-z*w-z*u-w^2+w*t-3*w*v-w*s-2*t*v-3*t*s+u^2-3*v^2-v*s+r^2+r*a+r*c+a*c,2*x^2+3*x*z-3*x*w+x*t-x*u+x*v+x*s+y^2+y*z+y*t-y*u+y*v+y*s-z*t-z*s+w^2-w*t+3*w*u-w*s-t^2+t*v+t*s+3*u^2-u*v+2*u*s+2*v^2-v*s-r^2-r*a-r*c-s^2-a*c+b*c,x*y+x*z-x*w+x*t-x*v+y*z-y*w-y*v-y*s+2*z^2-z*u-z*v-z*s+w*t-2*w*v-w*s+t^2+t*v+4*u^2-2*u*v-u*s-2*v^2+2*v*s+r^2-2*r*a-2*r*b+r*c+s^2-a^2-a*c+c^2];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 28.84.4.a.1
//   Coordinate number 0:
map_0_coord_0 := 1*(-r);
//   Coordinate number 1:
map_0_coord_1 := 1*(-a);
//   Coordinate number 2:
map_0_coord_2 := 1*(-b);
//   Coordinate number 3:
map_0_coord_3 := 1*(c);
// Codomain equation:
map_0_codomain := [2*x^2+12*x*y+5*y^2+12*x*z+2*y*z-z^2-3*x*w-5*y*w-w^2,x^2*y+5*x*y^2+2*y^3-3*x^2*z-y^2*z-3*x*z^2-y*z^2+x^2*w+x*y*w-y^2*w+5*x*z*w+3*y*z*w-z^2*w-x*w^2-y*w^2];
