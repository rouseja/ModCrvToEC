
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 56.168.12.c.1

// Other names and/or labels
// Cummins-Pauli label: 28A12
// Rouse-Sutherland-Zureick-Brown label: 56.168.12.4

// Group data
level := 56;
// Elements that, together with Gamma(level), generate the group
gens := [[12, 1, 21, 16], [17, 49, 42, 31], [30, 45, 31, 39], [47, 0, 35, 33]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 168;

// Curve data
conductor := [[2, 64], [7, 24]];
bad_primes := [2, 7];
// Genus
g := 12;
// Rank
r := 9
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 6
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["28.84.4.a.1", "56.8.0.a.1", "56.42.3.c.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r,s,a,b,c> := PolynomialRing(Rationals(), 12);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x*z+x*w+y*z,z*r+z*s-z*c-t*r-u*r-u*s-v*r+v*a,z*r+2*z*s+w*s-t*a-u*s-u*a-v*s-v*a+v*c,z*r-z*s-z*a-z*c-w*c+u*r+u*s+u*a+v*a,z*s+z*a-w*a+t*a-u*r+v*s-v*c,x*c+y*r-y*a-y*c+z*r-w*r-t*a-u*s-u*a-v*r-v*s,2*x*r+x*s+x*a-y*s+y*a+y*c,x*s+x*a+y*s+y*a-y*c-z*r-z*s+z*a+t*r+t*a-u*s-v*r,2*x*r-x*s-x*a+x*c+y*r+y*s-z*s+z*c+w*c-u*r+u*s-u*a+v*r-v*c,x*r+x*a+y*s+y*a+z*r-z*c-2*t*r+t*a+u*r-v*s-r*b+a*b,x*r-x*a-w*s+2*t*r+u*r-u*s-u*a-v*s+v*c-s*b-a*b+b*c,x*r+x*s+z*r-z*c-w*s-w*a+t*r-u*r-2*u*s+v*r+v*s+v*a-v*c-s*b-a*b,z*s+z*c+w*r+w*s-t*r-t*a-t*c-u*r-2*u*a+v*s,x*r-x*a-y*s-y*a+y*c+z*r-z*a-z*c+t*s-u*s+u*a+u*c+v*r-v*s-s*b-a*b,x*s-x*a-x*c+y*s-y*a-w*r+w*s+w*a+2*t*r-u*s-v*s-s*b-a*b,x*r+x*s-y*r-y*s-z*s-w*a-u*s-u*a+u*c+v*r-v*a+v*c-r*b+s*b-b*c,x*r+x*a+x*c+y*s+y*a-y*c+z*a+w*a-t*a+u*r-u*a-u*c-v*s-v*a-v*c-r*b-s*b,z*s+w*r+w*s+w*c-2*t*r-u*r+u*s+u*a-2*v*s-v*a,z*r-z*s-z*a+z*c-w*a-2*u*r+u*s-u*a-u*c+2*v*a,y*u-y*v-w^2-w*u-u*v+v^2,x*w+x*t-z*u-z*b+w*v-2*t*v,x*z+y*w+y*u+y*v+z*w+z*u+z*b+w*u+w*v-u*v-v^2,y*w+y*u+y*v+z*t+z*b+w*u-t^2+t*b+u^2+u*v+u*b+v*b,x*u+x*v+y*w+y*u+y*v-z*v+z*b+w*t+w*v-t*u+t*b+u^2+v^2,x^2-x*v-y^2-y*v-y*b-w^2-w*t+w*u+v*b,y*w+y*t+z*u-z*v+z*b+w*u+w*v+w*b-t*v,x*w+x*u+x*v-z*t-w*t+w*u-w*v-w*b-t^2+t*b+u^2+u*b-v^2+v*b,x*u-x*v+z*w+z*v+w*t-w*u-w*v+t*u-u^2-u*v+u*b-v*b,x*z-x*w+x*t+y*w-2*y*t,x*z-x*t-x*u-x*v+y*t-y*u+y*v+z^2+z*t+z*b-w*t+w*u+t*v-t*b-u*v-u*b-v^2+v*b,x*w+x*t+y*w+y*u-y*v-z*w+z*t+z*u+w*t-t^2+t*b+u^2-u*v+u*b-v*b,x^2-x*y-x*u-x*v+x*b-y^2-y*u-z*w+z*t+w^2-w*u-t^2+u^2+u*v,x*w-x*u-x*v+y*t-y*u-y*v-z*t+w^2-2*w*t-w*v-t^2+t*v+u^2-u*v,x*y-x*z+x*t+x*u-y^2-y*t-y*v-y*b-z*w-z*t-z*b+w*u-t^2+2*t*u+t*v+t*b-u^2+u*b+v^2+b^2,x^2+x*v-y^2+y*w+y*v-y*b+z*w-z*u+z*v+z*b-w*t-w*v-2*t*u+t*b-2*u^2-2*u*v+u*b+2*v^2,x^2-x*y-x*z-x*w+x*u+x*v-x*b+y^2+y*z+y*w+y*u+z^2+z*u-z*v+z*b+w^2+w*u-t^2+t*b+u^2-u*v+u*b-v*b-2*r*s+s^2+2*s*a-s*c+a^2-a*c,2*x*t+x*u+x*v-2*x*b+y*w-y*t+2*y*u+2*y*v-z*u+w^2-w*t+w*v+w*b+t*u+t*v-t*b-u^2+u*v+2*r*s-3*s*a-a^2+a*c,2*x*y+x*z-x*w-x*t+y*z-y*w-y*t-z^2+z*w+z*t-z*v-z*b+w^2+2*w*t+w*u-w*b+2*t*u-t*v+t*b+2*u^2+u*b-v*b+r*s+s^2-s*a-s*c-a^2+c^2,x^2+2*x*z-2*x*w-2*x*t+x*u+y^2-y*v-y*b-z^2-z*u+z*v-w*t-w*b-t^2-2*t*v+t*b+u^2+u*b-v^2+r^2+2*r*s+r*a-r*c+s^2+s*a-a*c,x*y+x*z-x*v-x*b-y*z+y*b-2*z^2-z*w+z*t-2*z*u-w*u+2*w*v-t^2+t*b+u^2+2*u*v+u*b-v^2-2*v*b+r*s-r*c-2*s*a-a^2,x^2-x*y-x*u+x*v-x*b-y^2+y*t+2*y*u+y*v-z*w-2*z*u+3*w^2+w*u-w*v-t*v-t*b-u*b+2*v^2+v*b-r*a+r*c-s*a,x^2-x*y-x*z-x*w-x*b+y^2+y*z-y*w-y*t+y*u+z^2-2*z*t+z*u+z*v+z*b+w^2-2*w*t+w*u+w*v-t^2-2*t*u-t*v+t*b-u^2-u*v+u*b-v*b+2*r*s+r*a-s*a+s*c+a*c,2*x*y+2*x*z+2*x*u-x*b-y^2-y*z-y*w-y*u-2*y*b-z^2-2*z*w+z*u+z*v+2*w^2-2*w*v+w*b+t^2-t*u-t*b+2*r*s+s^2+s*a-b^2,x*z+x*w+x*t-x*u-x*v-2*y*z-y*t-z^2-2*z*w-z*t+3*z*v-3*w^2+2*w*t-w*v+2*w*b+2*t^2+t*u+t*v+t*b+u^2+u*v+2*r*s+r*a-r*c+2*s*a+a^2-a*c,x^2+x*y-x*z+x*w-2*x*b+y*w+y*t+3*y*u-y*v+z^2-z*w-z*t+2*z*u-z*v+2*z*b+w^2-w*u+w*v-3*w*b+t*v-2*t*b-2*u^2+u*v-v^2+2*v*b+r^2-2*r*s-3*r*a-r*c+s^2-s*c+a^2+a*c+b^2];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 28.84.4.a.1
//   Coordinate number 0:
map_0_coord_0 := 1*(-s);
//   Coordinate number 1:
map_0_coord_1 := 1*(-a);
//   Coordinate number 2:
map_0_coord_2 := 1*(r);
//   Coordinate number 3:
map_0_coord_3 := 1*(-c);
// Codomain equation:
map_0_codomain := [2*x^2+12*x*y+5*y^2+12*x*z+2*y*z-z^2-3*x*w-5*y*w-w^2,x^2*y+5*x*y^2+2*y^3-3*x^2*z-y^2*z-3*x*z^2-y*z^2+x^2*w+x*y*w-y^2*w+5*x*z*w+3*y*z*w-z^2*w-x*w^2-y*w^2];
