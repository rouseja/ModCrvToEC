
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 56.168.8.a.1

// Other names and/or labels
// Cummins-Pauli label: 28B8
// Rouse-Sutherland-Zureick-Brown label: 56.168.8.3

// Group data
level := 56;
// Elements that, together with Gamma(level), generate the group
gens := [[15, 1, 23, 20], [16, 9, 9, 36], [28, 23, 47, 0], [43, 30, 22, 13]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 168;

// Curve data
conductor := [[2, 40], [7, 15]];
bad_primes := [2, 7];
// Genus
g := 8;
// Rank
r := 6
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 6
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["28.84.4.a.1", "56.42.1.e.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r> := PolynomialRing(Rationals(), 8);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x*w+x*u+x*r+y*w+y*t+2*y*u,2*x*t+y*t+y*u+z*w+2*z*t-z*u-z*r-w*v-u*v,2*x*v+3*y*v+2*w*t-w*u+t^2-t*r+v^2,2*x*w-2*x*u+2*x*r-2*y*t-2*y*u+y*r+z*w-z*t+z*r-v*r,2*x*w-2*x*r-2*y*t-y*r+3*z*w+z*t+z*r-t*v+u*v-2*v*r,x*w+x*u-x*r+y*w+2*y*t-y*u-3*z*w-2*z*t+z*u-z*r+2*v*r,x*w+2*x*t-x*u+x*r+y*w+y*t-2*z*w-2*z*u+2*z*r+w*v-u*v+v*r,4*x*z-3*x*v+2*y^2+2*y*z+y*v+2*z^2+w^2-w*t+w*u-t^2+u*r+r^2,4*x^2-2*x*y+2*y^2+2*w^2-t^2+2*t*u-u^2-v^2+2*r^2,x*v-2*y^2+4*y*z+3*y*v-2*z^2+2*z*v-w^2-t^2+t*u-t*r-u^2+2*u*r-v^2-r^2,4*x^2-2*y^2+y*v-w^2-2*w*t+w*u-t^2+2*t*u-t*r-u^2+2*u*r-v^2-r^2,2*x*y-2*x*z-x*v-2*y^2-2*y*v+2*z^2-3*z*v-2*w^2-w*t-2*w*u+t^2-t*u+u^2-2*u*r+v^2-r^2,2*x^2+2*x*y+x*v+2*y^2+3*y*v+w^2-w*t+3*w*u-w*r-t^2+2*t*u-2*t*r+r^2,2*x^2+2*x*y+2*x*z+2*x*v-y*v-2*z^2+3*z*v+2*w*t-w*u+w*r+t^2-t*u+2*t*r-u^2+2*u*r-v^2-r^2,2*x^2+2*x*y-3*x*v+2*y^2+4*y*v-w^2-2*w*t-5*w*u+2*w*r-t^2-t*u-2*u^2+4*u*r-2*v^2];

// Singular plane model
model_1 := [7056*x^12*y^2+163464*x^11*y^3-896*x^11*y*z^2+1550017*x^10*y^4+11200*x^10*y^2*z^2+256*x^10*z^4+7993566*x^9*y^5+200200*x^9*y^3*z^2+2272*x^9*y*z^4+25355883*x^8*y^6+1583064*x^8*y^4*z^2+61984*x^8*y^2*z^4+896*x^8*z^6+52707046*x^7*y^7+7492128*x^7*y^5*z^2+443558*x^7*y^3*z^4+4032*x^7*y*z^6+74081385*x^6*y^8+21785400*x^6*y^6*z^2+1582714*x^6*y^4*z^4+27832*x^6*y^2*z^6+784*x^6*z^8+71101254*x^5*y^9+39592392*x^5*y^7*z^2+3782982*x^5*y^5*z^4+172480*x^5*y^3*z^6+5096*x^5*y*z^8+46238458*x^4*y^10+45281320*x^4*y^8*z^2+6773032*x^4*y^6*z^4+506856*x^4*y^4*z^6+12985*x^4*y^2*z^8+19854702*x^3*y^11+32184320*x^3*y^9*z^2+8492280*x^3*y^7*z^4+733040*x^3*y^5*z^6+16856*x^3*y^3*z^8+5349624*x^2*y^12+13651624*x^2*y^10*z^2+6419706*x^2*y^8*z^4+528416*x^2*y^6*z^6+12152*x^2*y^4*z^8+814968*x*y^13+3141936*x*y^11*z^2+2439096*x*y^9*z^4+176960*x*y^7*z^6+4704*x*y^5*z^8+53361*y^14+300608*y^12*z^2+352136*y^10*z^4+21728*y^8*z^6+784*y^6*z^8];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 28.84.4.a.1
//   Coordinate number 0:
map_0_coord_0 := 1*(-w);
//   Coordinate number 1:
map_0_coord_1 := 1*(-t);
//   Coordinate number 2:
map_0_coord_2 := 1*(u);
//   Coordinate number 3:
map_0_coord_3 := 1*(-w-u+r);
// Codomain equation:
map_0_codomain := [2*x^2+12*x*y+5*y^2+12*x*z+2*y*z-z^2-3*x*w-5*y*w-w^2,x^2*y+5*x*y^2+2*y^3-3*x^2*z-y^2*z-3*x*z^2-y*z^2+x^2*w+x*y*w-y^2*w+5*x*z*w+3*y*z*w-z^2*w-x*w^2-y*w^2];

// Map from the canonical model to the plane model of modular curve with label 56.168.8.a.1
//   Coordinate number 0:
map_1_coord_0 := 1*(x);
//   Coordinate number 1:
map_1_coord_1 := 1*(y);
//   Coordinate number 2:
map_1_coord_2 := 1*(w);
// Codomain equation:
map_1_codomain := [7056*x^12*y^2+163464*x^11*y^3-896*x^11*y*z^2+1550017*x^10*y^4+11200*x^10*y^2*z^2+256*x^10*z^4+7993566*x^9*y^5+200200*x^9*y^3*z^2+2272*x^9*y*z^4+25355883*x^8*y^6+1583064*x^8*y^4*z^2+61984*x^8*y^2*z^4+896*x^8*z^6+52707046*x^7*y^7+7492128*x^7*y^5*z^2+443558*x^7*y^3*z^4+4032*x^7*y*z^6+74081385*x^6*y^8+21785400*x^6*y^6*z^2+1582714*x^6*y^4*z^4+27832*x^6*y^2*z^6+784*x^6*z^8+71101254*x^5*y^9+39592392*x^5*y^7*z^2+3782982*x^5*y^5*z^4+172480*x^5*y^3*z^6+5096*x^5*y*z^8+46238458*x^4*y^10+45281320*x^4*y^8*z^2+6773032*x^4*y^6*z^4+506856*x^4*y^4*z^6+12985*x^4*y^2*z^8+19854702*x^3*y^11+32184320*x^3*y^9*z^2+8492280*x^3*y^7*z^4+733040*x^3*y^5*z^6+16856*x^3*y^3*z^8+5349624*x^2*y^12+13651624*x^2*y^10*z^2+6419706*x^2*y^8*z^4+528416*x^2*y^6*z^6+12152*x^2*y^4*z^8+814968*x*y^13+3141936*x*y^11*z^2+2439096*x*y^9*z^4+176960*x*y^7*z^6+4704*x*y^5*z^8+53361*y^14+300608*y^12*z^2+352136*y^10*z^4+21728*y^8*z^6+784*y^6*z^8];
