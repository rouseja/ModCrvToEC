
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 56.168.8.d.1

// Other names and/or labels
// Cummins-Pauli label: 28B8
// Rouse-Sutherland-Zureick-Brown label: 56.168.8.2

// Group data
level := 56;
// Elements that, together with Gamma(level), generate the group
gens := [[29, 18, 27, 27], [50, 33, 19, 23], [52, 25, 25, 8], [55, 28, 39, 1]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 168;

// Curve data
conductor := [[2, 40], [7, 16]];
bad_primes := [2, 7];
// Genus
g := 8;
// Rank
r := 5
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 6
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["28.84.4.a.1", "56.42.1.h.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r> := PolynomialRing(Rationals(), 8);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x*t+x*u-y*u+z*t+2*z*u+w*t,x*v-x*r-2*y*t-y*u-2*y*v+z*u-z*v-z*r-w*v,2*x*t+x*v+2*y*u+y*v-2*z*t-2*z*u+2*w*t+w*u+w*v-w*r,3*x*t+x*u+y*v+y*r+z*t-z*u+z*v+z*r-3*w*t-w*u,x*t+x*u-3*x*v-2*y*u+2*y*v+z*t-z*u+z*v-w*t-w*v+2*w*r,2*x*t+x*v-2*x*r+y*v-2*z*u+2*z*v+w*u-3*w*v,3*x^2-3*x*y-2*x*z+2*x*w+2*y^2+y*z-4*y*w-z^2+z*w+w^2-2*t*u-2*u*v-u*r,x^2-2*x*y+x*z+x*w+3*y^2-3*y*z-2*z^2+3*z*w-w^2+2*t^2+t*r-2*u*v,2*x^2+3*x*y+4*x*z-x*w-4*y^2+y*w+z^2+2*w^2-2*t^2-2*t*u-t*r,x^2+4*x*y-x*z+x*w+y^2-y*z-2*z*w+w^2-2*t*u-2*t*v-4*u*v-u*r-v*r,3*x*z-x*w+3*y^2+2*y*z+y*w+4*z^2-2*z*w+2*t*v-t*r+2*v^2-v*r+r^2,3*x^2-2*x*y-x*z-2*y^2-4*y*z+3*y*w-2*z^2+2*z*w+3*w^2-2*t*u+u*r,2*x^2-x*y-2*y^2-y*z-6*y*w-2*z^2-4*z*w+w^2-2*t*v+t*r-2*u*r-2*v^2+v*r-r^2,2*x^2-2*x*y-2*x*z+3*y^2+y*z+y*w-2*z*w+3*w^2+2*t^2+4*t*u+t*r+2*u^2+u*r,x^2+6*x*y-x*z-3*y^2-3*y*z-2*y*w-z*w+3*w^2+2*t^2+2*t*v-2*t*r+2*u*v-u*r+2*v^2-v*r];

// Singular plane model
model_1 := [5175625*x^14-82491500*x^13*y+618754850*x^12*y^2+54514250*x^12*z^2-2875665940*x^11*y^3-748731900*x^11*y*z^2+9189301191*x^10*y^4+4541481140*x^10*y^2*z^2+152352400*x^10*z^4-21209397552*x^9*y^5-16107918428*x^9*y^3*z^2-1739511680*x^9*y*z^4+36187422572*x^8*y^6+37154822110*x^8*y^4*z^2+7882510124*x^8*y^2*z^4+46278320*x^8*z^6-45987376904*x^7*y^7-58637975032*x^7*y^5*z^2-18556731808*x^7*y^3*z^4-339751072*x^7*y*z^6+43359785959*x^6*y^8+64786806840*x^6*y^6*z^2+26152839472*x^6*y^4*z^4+953504128*x^6*y^2*z^6+3281616*x^6*z^8-29921333932*x^5*y^9-50356197528*x^5*y^7*z^2-23765970528*x^5*y^5*z^4-1447055968*x^5*y^3*z^6-8922816*x^5*y*z^8+14757522178*x^4*y^10+27276238150*x^4*y^8*z^2+14421557320*x^4*y^6*z^4+1339483296*x^4*y^4*z^6+9018368*x^4*y^2*z^8-74592*x^4*z^10-5010740196*x^3*y^11-10044215692*x^3*y^9*z^2-5881750368*x^3*y^7*z^4-785521504*x^3*y^5*z^6-3441728*x^3*y^3*z^8+166464*x^3*y*z^10+1101152745*x^2*y^12+2396087316*x^2*y^10*z^2+1572743776*x^2*y^8*z^4+286940032*x^2*y^6*z^6-391280*x^2*y^4*z^8-139072*x^2*y^2*z^10+384*x^2*z^12-139592376*x*y^13-335711628*x*y^11*z^2-253945632*x*y^9*z^4-59856288*x*y^7*z^6+646784*x*y^5*z^8+49984*x*y^3*z^10-512*x*y*z^12+7683984*y^14+21287826*y^12*z^2+19141740*y^10*z^4+5460912*y^8*z^6-131808*y^6*z^8-6112*y^4*z^10+192*y^2*z^12];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 28.84.4.a.1
//   Coordinate number 0:
map_0_coord_0 := 1*(-x);
//   Coordinate number 1:
map_0_coord_1 := 1*(y);
//   Coordinate number 2:
map_0_coord_2 := 1*(z);
//   Coordinate number 3:
map_0_coord_3 := 1*(-x-z+w);
// Codomain equation:
map_0_codomain := [2*x^2+12*x*y+5*y^2+12*x*z+2*y*z-z^2-3*x*w-5*y*w-w^2,x^2*y+5*x*y^2+2*y^3-3*x^2*z-y^2*z-3*x*z^2-y*z^2+x^2*w+x*y*w-y^2*w+5*x*z*w+3*y*z*w-z^2*w-x*w^2-y*w^2];

// Map from the canonical model to the plane model of modular curve with label 56.168.8.d.1
//   Coordinate number 0:
map_1_coord_0 := 1*(x);
//   Coordinate number 1:
map_1_coord_1 := 1*(y);
//   Coordinate number 2:
map_1_coord_2 := 1*(t);
// Codomain equation:
map_1_codomain := [5175625*x^14-82491500*x^13*y+618754850*x^12*y^2+54514250*x^12*z^2-2875665940*x^11*y^3-748731900*x^11*y*z^2+9189301191*x^10*y^4+4541481140*x^10*y^2*z^2+152352400*x^10*z^4-21209397552*x^9*y^5-16107918428*x^9*y^3*z^2-1739511680*x^9*y*z^4+36187422572*x^8*y^6+37154822110*x^8*y^4*z^2+7882510124*x^8*y^2*z^4+46278320*x^8*z^6-45987376904*x^7*y^7-58637975032*x^7*y^5*z^2-18556731808*x^7*y^3*z^4-339751072*x^7*y*z^6+43359785959*x^6*y^8+64786806840*x^6*y^6*z^2+26152839472*x^6*y^4*z^4+953504128*x^6*y^2*z^6+3281616*x^6*z^8-29921333932*x^5*y^9-50356197528*x^5*y^7*z^2-23765970528*x^5*y^5*z^4-1447055968*x^5*y^3*z^6-8922816*x^5*y*z^8+14757522178*x^4*y^10+27276238150*x^4*y^8*z^2+14421557320*x^4*y^6*z^4+1339483296*x^4*y^4*z^6+9018368*x^4*y^2*z^8-74592*x^4*z^10-5010740196*x^3*y^11-10044215692*x^3*y^9*z^2-5881750368*x^3*y^7*z^4-785521504*x^3*y^5*z^6-3441728*x^3*y^3*z^8+166464*x^3*y*z^10+1101152745*x^2*y^12+2396087316*x^2*y^10*z^2+1572743776*x^2*y^8*z^4+286940032*x^2*y^6*z^6-391280*x^2*y^4*z^8-139072*x^2*y^2*z^10+384*x^2*z^12-139592376*x*y^13-335711628*x*y^11*z^2-253945632*x*y^9*z^4-59856288*x*y^7*z^6+646784*x*y^5*z^8+49984*x*y^3*z^10-512*x*y*z^12+7683984*y^14+21287826*y^12*z^2+19141740*y^10*z^4+5460912*y^8*z^6-131808*y^6*z^8-6112*y^4*z^10+192*y^2*z^12];
