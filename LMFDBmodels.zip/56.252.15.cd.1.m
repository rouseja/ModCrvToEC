
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 56.252.15.cd.1

// Other names and/or labels
// Cummins-Pauli label: 56F15
// Rouse-Sutherland-Zureick-Brown label: 56.252.15.48

// Group data
level := 56;
// Elements that, together with Gamma(level), generate the group
gens := [[7, 54, 2, 21], [25, 46, 18, 23], [29, 19, 26, 27], [31, 11, 54, 53], [37, 32, 32, 49], [53, 22, 46, 3]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 252;

// Curve data
conductor := [[2, 54], [7, 30]];
bad_primes := [2, 7];
// Genus
g := 15;
// Rank
r := 7
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 9
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["28.126.6.d.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
