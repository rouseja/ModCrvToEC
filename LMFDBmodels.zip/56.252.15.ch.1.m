
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 56.252.15.ch.1

// Other names and/or labels
// Cummins-Pauli label: 28F15
// Rouse-Sutherland-Zureick-Brown label: 56.252.15.2

// Group data
level := 56;
// Elements that, together with Gamma(level), generate the group
gens := [[1, 52, 42, 27], [5, 6, 34, 23], [19, 18, 4, 31], [37, 9, 2, 15], [37, 30, 2, 15], [55, 53, 46, 53]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 252;

// Curve data
conductor := [[2, 72], [7, 30]];
bad_primes := [2, 7];
// Genus
g := 15;
// Rank
r := 4
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 9
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-4];
// Modular curve is a fiber product of the following curvesfactors := ['7.21.0.a.1', '8.12.0.t.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["8.12.0.t.1", "28.126.6.d.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
