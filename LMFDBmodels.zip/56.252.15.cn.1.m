
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 56.252.15.cn.1

// Other names and/or labels
// Cummins-Pauli label: 28E15
// Rouse-Sutherland-Zureick-Brown label: 56.252.15.34

// Group data
level := 56;
// Elements that, together with Gamma(level), generate the group
gens := [[5, 31, 10, 7], [23, 35, 28, 37], [37, 0, 20, 33], [37, 47, 50, 19], [43, 22, 36, 39], [47, 14, 42, 33]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 252;

// Curve data
conductor := [[2, 72], [7, 30]];
bad_primes := [2, 7];
// Genus
g := 15;
// Rank
r := 4
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 9
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["28.126.6.d.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
