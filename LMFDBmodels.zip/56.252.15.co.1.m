
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 56.252.15.co.1

// Other names and/or labels
// Cummins-Pauli label: 56F15
// Rouse-Sutherland-Zureick-Brown label: 56.252.15.33

// Group data
level := 56;
// Elements that, together with Gamma(level), generate the group
gens := [[13, 17, 24, 43], [19, 1, 0, 37], [21, 16, 12, 21], [39, 3, 38, 41], [39, 14, 40, 3], [51, 34, 48, 27]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 252;

// Curve data
conductor := [[2, 39], [7, 27]];
bad_primes := [2, 7];
// Genus
g := 15;
// Rank
r := 5
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 9
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["28.126.6.d.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
