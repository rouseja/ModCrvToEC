
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 56.252.18.d.1

// Other names and/or labels
// Cummins-Pauli label: 56A18
// Rouse-Sutherland-Zureick-Brown label: 56.252.18.7

// Group data
level := 56;
// Elements that, together with Gamma(level), generate the group
gens := [[1, 23, 16, 7], [1, 36, 30, 27], [1, 54, 12, 37], [9, 10, 24, 33], [21, 33, 54, 43], [43, 39, 6, 13]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 252;

// Curve data
conductor := [[2, 78], [7, 36]];
bad_primes := [2, 7];
// Genus
g := 18;
// Rank
r := 10
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 6
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["28.126.6.d.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
