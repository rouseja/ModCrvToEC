
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 56.42.1.b.1

// Other names and/or labels
// Cummins-Pauli label: 7A1
// Rouse-Sutherland-Zureick-Brown label: 56.42.1.1

// Group data
level := 56;
// Elements that, together with Gamma(level), generate the group
gens := [[6, 27, 47, 8], [28, 31, 39, 35], [43, 51, 2, 21], [51, 53, 46, 7]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 42;

// Curve data
conductor := [[2, 6], [7, 2]];
bad_primes := [2, 7];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 6
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["7.21.0.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u> := PolynomialRing(Rationals(), 6);
// Isomorphic to P^1?
is_P1 := false;

// Embedded model
model_0 := [x*w-z*w-y*t,x*y-y*z-y*t-w*t-y*u,x*y-x*w-z*w+y*u+w*u,x^2-x*z-x*t-z*t+x*u-z*u+t*u,x^2-z^2-2*x*t-z*t-2*x*u+u^2,x^2-2*x*z+z^2-x*t+z*t-t^2-x*u+z*u,x^2+2*y^2+x*z+2*z^2+2*y*w+2*w^2-x*t+z*t-x*u+z*u+u^2,2*y*w-4*w^2+x*t-2*z*t-2*t^2-x*u-z*u-t*u-3*u^2,x^2-2*y^2-z^2+4*y*w-2*z*t-t^2+2*x*u+2*z*u-2*u^2];

// Singular plane model
model_1 := [x^6+22*x^4*y^2-6*x^5*z-36*x^3*y^2*z+11*x^4*z^2-18*x^2*y^2*z^2-2*x^3*z^3+24*x*y^2*z^3-11*x^2*z^4+16*y^2*z^4+4*x*z^5+4*z^6];

// Maps from this modular curve, if computed

// j-invariant map from the embedded model
//   Coordinate number 0:
map_0_coord_0 := 2^6*(1848428766*x*u^6+151531912*z*w^2*u^4-6926985*z*t^6-85471254*z*t^5*u-555106905*z*t^4*u^2-2398334446*z*t^3*u^3-7446417603*z*t^2*u^4-6524100830*z*t*u^5+1599424041*z*u^6-13176688*w^4*u^3+6682227902*w^2*u^5+2645865*t^7+32301801*t^6*u+209107341*t^5*u^2+908917795*t^4*u^3+2864499904*t^3*u^4+6406722733*t^2*u^5+2342117513*t*u^6+5047244080*u^7);
//   Coordinate number 1:
map_0_coord_1 := 1*(490685060*x*u^6+2744*z*w^6-130340*z*w^4*u^2+31689770*z*w^2*u^4-506063*z*t^6-8668792*z*t^5*u-74335153*z*t^4*u^2-391327366*z*t^3*u^3-1313570179*z*t^2*u^4-1232109408*z*t*u^5+198492149*z*u^6+10976*w^6*u-3825136*w^4*u^3+1212510488*w^2*u^5+193496*t^7+3288222*t^6*u+28078524*t^5*u^2+148692710*t^4*u^3+504131859*t^3*u^4+1176934754*t^2*u^5+490983961*t*u^6+887669422*u^7);

// Map from the embedded model to the plane model of modular curve with label 56.42.1.b.1
//   Coordinate number 0:
map_1_coord_0 := 1*(y);
//   Coordinate number 1:
map_1_coord_1 := 1*(1/2*u);
//   Coordinate number 2:
map_1_coord_2 := 1*(w);
// Codomain equation:
map_1_codomain := [x^6+22*x^4*y^2-6*x^5*z-36*x^3*y^2*z+11*x^4*z^2-18*x^2*y^2*z^2-2*x^3*z^3+24*x*y^2*z^3-11*x^2*z^4+16*y^2*z^4+4*x*z^5+4*z^6];
