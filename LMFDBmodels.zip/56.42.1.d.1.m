
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 56.42.1.d.1

// Other names and/or labels
// Cummins-Pauli label: 7A1
// Rouse-Sutherland-Zureick-Brown label: 56.42.1.5

// Group data
level := 56;
// Elements that, together with Gamma(level), generate the group
gens := [[3, 52, 55, 11], [11, 17, 31, 34], [43, 1, 1, 4], [53, 37, 3, 24]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 42;

// Curve data
conductor := [[2, 6], [7, 2]];
bad_primes := [2, 7];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 6
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["7.21.0.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u> := PolynomialRing(Rationals(), 6);
// Isomorphic to P^1?
is_P1 := false;

// Embedded model
model_0 := [x*z+y*z+z*t-x*u+y*u,x*z-y*z+z*w-z*t+x*u+w*u,z*w+z*t+2*x*u+y*u-t*u,2*x^2-x*y+y^2+2*x*w+y*t+w*t,2*x^2+3*x*y+y^2+x*w-y*w+2*x*t-y*t-t^2,2*x^2-x*y-y^2+x*w+y*w-w^2-4*x*t-2*w*t+t^2,2*x*y-2*y^2-x*w+3*y*w+w^2+2*x*t+4*y*t-w*t+4*t^2-2*u^2,2*x^2-3*x*y-3*y^2-3*x*w-2*y*w-w^2+2*x*t-3*y*t-w*t-2*z*u,2*x^2-x*y+4*y^2-2*z^2-2*x*w+2*y*w+w^2+2*x*t-2*y*t-w*t-t^2];

// Singular plane model
model_1 := [4*x^6-154*x^4*y^2+252*x^3*y^2*z-12*x^4*z^2+126*x^2*y^2*z^2-12*x^3*z^3-168*x*y^2*z^3+9*x^2*z^4-112*y^2*z^4+18*x*z^5+9*z^6];

// Maps from this modular curve, if computed

// j-invariant map from the embedded model
//   Coordinate number 0:
map_0_coord_0 := 2^3*(14644452751722584*x*t^6+26940612097142730*x*t^4*u^2+163775907887215512*x*t^2*u^4+5379113700031656*x*u^6+7399587839081256*y*t^6+12336919087637326*y*t^4*u^2+56282505343822576*y*t^2*u^4+595353318235208*y*u^6+163748804490656*z*t^5*u-3028015143139112*z*t^3*u^3-15622897269361584*z*t*u^5+3428081337693992*w^2*t^5+6406727688616017*w^2*t^3*u^2+28565969044896654*w^2*t*u^4+6890780275412040*w*t^6+12902822424342172*w*t^4*u^2+47277053687091984*w*t^2*u^4-1525157707572720*w*u^6+3420879696146864*t^7+6235246548681227*t^5*u^2+16555761549177956*t^3*u^4-29272114449438884*t*u^6);
//   Coordinate number 1:
map_0_coord_1 := 1*(11048861262215*x*t^6+281819779846794*x*t^4*u^2+590634104218508*x*t^2*u^4+40177931205464*x*u^6+3800033953170*y*t^6+102022451501334*y*t^4*u^2+203881830750052*y*t^2*u^4+4442407859448*y*u^6-431933168772*z*t^5*u-28277992573040*z*t^3*u^3-56103810976144*z*t*u^5+2073842582098*w^2*t^5+54221061497540*w^2*t^3*u^2+104211157640716*w^2*t*u^4+3787313930911*w*t^6+97924913579332*w*t^4*u^2+174460895221116*w*t^2*u^4-11402129428560*w*u^6+2821458499104*t^7+56820744800848*t^5*u^2+35556628766120*t^3*u^4-116820941439200*t*u^6);

// Map from the embedded model to the plane model of modular curve with label 56.42.1.d.1
//   Coordinate number 0:
map_1_coord_0 := 1*(z);
//   Coordinate number 1:
map_1_coord_1 := 1*(1/2*t);
//   Coordinate number 2:
map_1_coord_2 := 1*(u);
// Codomain equation:
map_1_codomain := [4*x^6-154*x^4*y^2+252*x^3*y^2*z-12*x^4*z^2+126*x^2*y^2*z^2-12*x^3*z^3-168*x*y^2*z^3+9*x^2*z^4-112*y^2*z^4+18*x*z^5+9*z^6];
