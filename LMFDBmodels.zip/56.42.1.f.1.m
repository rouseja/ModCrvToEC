
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 56.42.1.f.1

// Other names and/or labels
// Cummins-Pauli label: 14E1
// Rouse-Sutherland-Zureick-Brown label: 56.42.1.7

// Group data
level := 56;
// Elements that, together with Gamma(level), generate the group
gens := [[4, 29, 1, 49], [24, 33, 33, 18], [30, 15, 5, 33], [37, 45, 10, 25]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 42;

// Curve data
conductor := [[2, 6], [7, 2]];
bad_primes := [2, 7];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 3
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["7.21.0.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3+x^2*z-y^2*z-457*x*z^2+559*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := -2^3*(111132*x^2*y^12-243663314496*x^2*y^10*z^2+35670594796985344*x^2*y^8*z^4-1335629884411596849152*x^2*y^6*z^6+18784457140470023718223872*x^2*y^4*z^8-108716000134888456282565246976*x^2*y^2*z^10+219253820139258332477155784523776*x^2*z^12-23825466*x*y^12*z+15942474811200*x*y^10*z^3-1453716701073329280*x*y^8*z^5+41890210011090992087040*x*y^6*z^7-496349319044338677391810560*x*y^4*z^9+2550359843987936660735980732416*x*y^2*z^11-4703587019879359497398443350425600*x*z^13-216*y^14+2896211395*y^12*z^2-772255126940528*y^10*z^4+39839533934563080256*y^8*z^6-691765146390228206987264*y^6*z^8+4786912037716443389550415872*y^4*z^10-12227147483460837238843826438144*y^2*z^12+5456143716958537590651861386133504*z^14);
//   Coordinate number 1:
map_0_coord_1 := 1*(y^14);
