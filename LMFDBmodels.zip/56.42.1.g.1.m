
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 56.42.1.g.1

// Other names and/or labels
// Cummins-Pauli label: 14E1
// Rouse-Sutherland-Zureick-Brown label: 56.42.1.2

// Group data
level := 56;
// Elements that, together with Gamma(level), generate the group
gens := [[19, 55, 37, 2], [23, 32, 25, 35], [34, 47, 13, 50], [43, 22, 36, 11]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 42;

// Curve data
conductor := [[2, 6], [7, 2]];
bad_primes := [2, 7];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 3
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["7.21.0.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3+x^2*z-y^2*z-9*x*z^2-z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := -2^3*(15876*x^2*y^12-101484096*x^2*y^10*z^2+43313579008*x^2*y^8*z^4-4728307662848*x^2*y^6*z^6+193876034666496*x^2*y^4*z^8-3271333531877376*x^2*y^2*z^10+19234655339282432*x^2*z^12-477162*x*y^12*z+890570688*x*y^10*z^3-227420568704*x*y^8*z^5+18483384500224*x*y^6*z^7-621051549769728*x*y^4*z^9+9093802043375616*x*y^2*z^11-47956674460778496*x*z^13-216*y^14+8306137*y^12*z^2-6301327088*y^10*z^4+918747682496*y^8*z^6-44311431227392*y^6*z^8+815018661703680*y^4*z^10-4643348474691584*y^2*z^12-5503603624902656*z^14);
//   Coordinate number 1:
map_0_coord_1 := 1*(y^14);
