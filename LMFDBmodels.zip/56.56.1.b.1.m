
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 56.56.1.b.1

// Other names and/or labels
// Cummins-Pauli label: 7B1
// Rouse-Sutherland-Zureick-Brown label: 56.56.1.5

// Group data
level := 56;
// Elements that, together with Gamma(level), generate the group
gens := [[27, 27, 52, 29], [45, 0, 35, 3], [47, 4, 35, 23], [51, 9, 15, 54]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 56;

// Curve data
conductor := [[2, 6], [7, 2]];
bad_primes := [2, 7];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 8
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["7.28.0.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w> := PolynomialRing(Rationals(), 4);
// Isomorphic to P^1?
is_P1 := false;

// Embedded model
model_0 := [2*y^2+2*y*z-3*z^2+y*w+4*z*w-w^2,14*x^2+13*y^2+6*y*z+5*z^2-8*y*w-4*z*w];

// Singular plane model
model_1 := [399*x^4+700*x^2*y^2+252*y^4-98*x^3*z+28*x*y^2*z-63*x^2*z^2+4*y^2*z^2-14*x*z^3-z^4];

// Maps from this modular curve, if computed

// j-invariant map from the embedded model
//   Coordinate number 0:
map_0_coord_0 := 2^12*7^5*(43933498*y*z^13-432830671*y*z^12*w+1995389466*y*z^11*w^2-5696751858*y*z^10*w^3+11234247101*y*z^9*w^4-16158494016*y*z^8*w^5+17440889186*y*z^7*w^6-14307399897*y*z^6*w^7+8924547954*y*z^5*w^8-4183760462*y*z^4*w^9+1434234191*y*z^3*w^10-340969440*y*z^2*w^11+50489600*y*z*w^12-3528000*y*w^13+80085355*z^14-807072140*z^13*w+3817505965*z^12*w^2-11224859877*z^11*w^3+22907025876*z^10*w^4-34303671815*z^9*w^5+38856935663*z^8*w^6-33808427884*z^7*w^7+22697237661*z^6*w^8-11696243027*z^5*w^9+4552363150*z^4*w^10-1297066577*z^3*w^11+255548720*z^2*w^12-31124800*z*w^13+1764000*w^14);
//   Coordinate number 1:
map_0_coord_1 := 1*(930484999808*y*z^13-7980065786560*y*z^12*w+31604338874752*y*z^11*w^2-76542198454848*y*z^10*w^3+126495617496192*y*z^9*w^4-150657236458848*y*z^8*w^5+133054718929664*y*z^7*w^6-88234465213888*y*z^6*w^7+43939391626312*y*z^5*w^8-16229842548892*y*z^4*w^9+4322222427432*y*z^3*w^10-785921441004*y*z^2*w^11+87454166282*y*z*w^12-4497642837*y*w^13+1696155986112*z^14-14929503744512*z^13*w+60938044519968*z^12*w^2-152885172916672*z^11*w^3+263392995324480*z^10*w^4-329627392913504*z^9*w^5+309007707484224*z^8*w^6-220419996613376*z^7*w^7+120208911056220*z^6*w^8-49870549977136*z^5*w^9+15489733176302*z^4*w^10-3491839720236*z^3*w^11+539883719823*z^2*w^12-51223154536*z*w^13+2248821419*w^14);

// Map from the embedded model to the plane model of modular curve with label 56.56.1.b.1
//   Coordinate number 0:
map_1_coord_0 := 1*(y);
//   Coordinate number 1:
map_1_coord_1 := 1*(x);
//   Coordinate number 2:
map_1_coord_2 := 1*(w);
// Codomain equation:
map_1_codomain := [399*x^4+700*x^2*y^2+252*y^4-98*x^3*z+28*x*y^2*z-63*x^2*z^2+4*y^2*z^2-14*x*z^3-z^4];
