
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 56.56.1.d.1

// Other names and/or labels
// Cummins-Pauli label: 7B1
// Rouse-Sutherland-Zureick-Brown label: 56.56.1.1

// Group data
level := 56;
// Elements that, together with Gamma(level), generate the group
gens := [[13, 37, 16, 37], [31, 10, 52, 53], [36, 55, 41, 6], [38, 45, 45, 25]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 56;

// Curve data
conductor := [[2, 6], [7, 2]];
bad_primes := [2, 7];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 8
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["7.28.0.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w> := PolynomialRing(Rationals(), 4);
// Isomorphic to P^1?
is_P1 := false;

// Embedded model
model_0 := [2*x^2+y^2+2*y*z-2*z^2-3*y*w-4*z*w+w^2,2*x^2-y^2-6*y*z-3*z^2+2*z*w-w^2];

// Singular plane model
model_1 := [47*x^4+268*x^2*y^2-4*y^4-262*x^3*z-436*x*y^2*z+305*x^2*z^2+172*y^2*z^2-34*x*z^3-57*z^4];

// Maps from this modular curve, if computed

// j-invariant map from the embedded model
//   Coordinate number 0:
map_0_coord_0 := 2^4*7^3*(z^3*(5000000*y*z^10-6474800*y*z^9*w+1138560*y*z^8*w^2+4381248*y*z^7*w^3-2601616*y*z^6*w^4-532572*y*z^5*w^5+820280*y*z^4*w^6-256844*y*z^3*w^7+38652*y*z^2*w^8-4455*y*z*w^9+404*y*w^10+2062000*z^11-2943200*z^10*w+7668720*z^9*w^2-1325600*z^8*w^3-3745212*z^7*w^4+1470008*z^6*w^5+532630*z^5*w^6-728372*z^4*w^7+436173*z^3*w^8-157298*z^2*w^9+29610*z*w^10-2200*w^11));
//   Coordinate number 1:
map_0_coord_1 := 1*(941696*y*z^13-676032*y*z^12*w-503104*y*z^11*w^2-753536*y*z^10*w^3+2756096*y*z^9*w^4-2632672*y*z^8*w^5+1367744*y*z^7*w^6-505792*y*z^6*w^7+143304*y*z^5*w^8-11788*y*z^4*w^9-13804*y*z^3*w^10+6720*y*z^2*w^11-1274*y*z*w^12+91*y*w^13+3570624*z^14-2681728*z^13*w-4014304*z^12*w^2+3089184*z^11*w^3+3212384*z^10*w^4-4319840*z^9*w^5+1941408*z^8*w^6-799584*z^7*w^7+587468*z^6*w^8-285544*z^5*w^9+43582*z^4*w^10+16422*z^3*w^11-8477*z^2*w^12+1442*z*w^13-90*w^14);

// Map from the embedded model to the plane model of modular curve with label 56.56.1.d.1
//   Coordinate number 0:
map_1_coord_0 := 1*(y);
//   Coordinate number 1:
map_1_coord_1 := 1*(x);
//   Coordinate number 2:
map_1_coord_2 := 1*(w);
// Codomain equation:
map_1_codomain := [47*x^4+268*x^2*y^2-4*y^4-262*x^3*z-436*x*y^2*z+305*x^2*z^2+172*y^2*z^2-34*x*z^3-57*z^4];
