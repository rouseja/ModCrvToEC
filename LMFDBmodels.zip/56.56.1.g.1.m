
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 56.56.1.g.1

// Other names and/or labels
// Cummins-Pauli label: 14G1
// Rouse-Sutherland-Zureick-Brown label: 56.56.1.6

// Group data
level := 56;
// Elements that, together with Gamma(level), generate the group
gens := [[6, 51, 37, 9], [15, 25, 43, 34], [17, 3, 24, 11], [40, 47, 33, 9]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 56;

// Curve data
conductor := [[2, 6], [7, 2]];
bad_primes := [2, 7];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 4
;// Number of rational cusps
Nrat_cusps := 1
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["7.28.0.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3+x^2*z-y^2*z-9*x*z^2-z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := -1*((y^2+56*z^2)^3*(12544*x^2*y^6*z^5+6322176*x^2*y^4*z^7-x*y^12+112*x*y^10*z^2-9408*x*y^8*z^4+827904*x*y^6*z^6+7024640*x*y^4*z^8+157351936*x*y^2*z^10+9*y^12*z-1568*y^10*z^3+83008*y^8*z^5+241920*y^6*z^7+3110912*y^4*z^9+89915392*y^2*z^11+1258815488*z^13));
//   Coordinate number 1:
map_0_coord_1 := 2^7*(z^5*y^14);
