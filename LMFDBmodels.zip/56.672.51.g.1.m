
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 56.672.51.g.1


// Group data
level := 56;
// Elements that, together with Gamma(level), generate the group
gens := [[7, 29, 20, 49], [10, 53, 25, 22], [21, 32, 3, 35], [33, 1, 14, 23]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 672;

// Curve data
conductor := [[2, 270], [7, 102]];
bad_primes := [2, 7];
// Genus
g := 51;
// Rank
r := 34
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 12
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["28.168.12.d.1", "56.32.1.c.1", "56.336.21.jq.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
