
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 57.1368.97.d.1


// Group data
level := 57;
// Elements that, together with Gamma(level), generate the group
gens := [[5, 22, 48, 14], [25, 11, 33, 44], [49, 27, 33, 46]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 1368;

// Curve data
conductor := [[3, 129], [19, 189]];
bad_primes := [3, 19];
// Genus
g := 97;
// Rank
r := 56
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 36
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["57.342.20.b.1", "57.684.49.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
