
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 57.2052.154.a.1


// Group data
level := 57;
// Elements that, together with Gamma(level), generate the group
gens := [[4, 27, 51, 34], [5, 46, 36, 46], [29, 27, 36, 32], [38, 3, 15, 38]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 2052;

// Curve data
conductor := [[3, 194], [19, 308]];
bad_primes := [3, 19];
// Genus
g := 154;
// Rank
r := 75
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 36
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['3.12.0.a.1', '19.171.8.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["3.12.0.a.1", "57.684.49.a.1", "57.1026.72.b.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
