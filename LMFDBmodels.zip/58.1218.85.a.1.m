
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 58.1218.85.a.1


// Group data
level := 58;
// Elements that, together with Gamma(level), generate the group
gens := [[27, 22, 26, 31], [31, 33, 50, 9], [45, 37, 44, 13]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 1218;

// Curve data
conductor := [[2, 37], [29, 170]];
bad_primes := [2, 29];
// Genus
g := 85;
// Rank
r := 63
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 28
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-3, -8, -12];
// Modular curve is a fiber product of the following curvesfactors := ['2.3.0.a.1', '29.406.24.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["2.3.0.a.1", "29.406.24.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
