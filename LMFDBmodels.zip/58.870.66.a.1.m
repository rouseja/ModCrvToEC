
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 58.870.66.a.1


// Group data
level := 58;
// Elements that, together with Gamma(level), generate the group
gens := [[8, 53, 51, 21], [54, 19, 41, 19]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 870;

// Curve data
conductor := [[2, 80], [29, 127]];
bad_primes := [2, 29];
// Genus
g := 66;
// Rank
r := 30
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 15
;// Number of rational cusps
Nrat_cusps := 1
;// CM discriminants
CM_discs := [-4];
// Modular curve is a fiber product of the following curvesfactors := ['2.2.0.a.1', '29.435.26.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["2.2.0.a.1", "29.435.26.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
