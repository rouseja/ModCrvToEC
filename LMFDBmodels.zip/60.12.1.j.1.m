
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.12.1.j.1

// Other names and/or labels
// Cummins-Pauli label: 10A1
// Rouse-Sutherland-Zureick-Brown label: 60.12.1.5

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[11, 50, 44, 57], [37, 45, 46, 1], [44, 55, 15, 19], [47, 45, 9, 16]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 12;

// Curve data
conductor := [[2, 4], [3, 2], [5, 1]];
bad_primes := [2, 3, 5];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 2
;// Number of rational cusps
Nrat_cusps := 2
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['5.6.0.a.1', '12.2.0.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["5.6.0.a.1", "12.2.0.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3-y^2*z-327*x*z^2-3454*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := 1*(2118*x^2*y^2+19054835361*x^2*z^2+1532289*x*y^2*z+447919833366*x*z^3+y^4+403889034*y^2*z^2+3170537804349*z^4);
//   Coordinate number 1:
map_0_coord_1 := 3*(x^2*y^2-138996*x^2*z^2-110*x*y^2*z+2480949*x*z^3+5167*y^2*z^2+12693186*z^4);
