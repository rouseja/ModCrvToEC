
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.120.7.da.1

// Other names and/or labels
// Cummins-Pauli label: 30H7
// Rouse-Sutherland-Zureick-Brown label: 60.120.7.100

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[22, 57, 59, 38], [50, 13, 33, 44], [53, 23, 38, 37]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 120;

// Curve data
conductor := [[2, 16], [3, 14], [5, 12]];
bad_primes := [2, 3, 5];
// Genus
g := 7;
// Rank
r := 2
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 4
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["15.60.3.b.1", "60.40.1.q.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v> := PolynomialRing(Rationals(), 7);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [z*v+w*u,x*t+2*y*t+z*u+w*t,2*x*u-y*u+3*z^2-v^2,3*z*t-2*t*v+u^2,x^2+x*y-2*x*w+y*w-2*t^2,3*x*u+y*u-w*u-v^2,3*x*z+y*z-z*w+w*v,x^2+3*x*y-x*w+y^2-2*y*w-w^2+t^2,x*v+2*y*v+3*z*w-w*v,4*x*t-2*y*t-2*z*u-w*t-u*v];

// Singular plane model
model_1 := [25*x^4*y^4+225*x^6*z^2-125*x^3*y^3*z^2+90*x^2*y^2*z^4-20*x*y*z^6+z^8];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 15.60.3.b.1
//   Coordinate number 0:
map_0_coord_0 := 1*(-5*t);
//   Coordinate number 1:
map_0_coord_1 := 1*(5*z);
//   Coordinate number 2:
map_0_coord_2 := 1*(z+v);
// Codomain equation:
map_0_codomain := [5*x^3*y-y^4-10*x^3*z+5*y^3*z+15*y^2*z^2-25*y*z^3-25*z^4];

// Map from the canonical model to the plane model of modular curve with label 60.120.7.da.1
//   Coordinate number 0:
map_1_coord_0 := 1*(t);
//   Coordinate number 1:
map_1_coord_1 := 1*(v);
//   Coordinate number 2:
map_1_coord_2 := 1*(u);
// Codomain equation:
map_1_codomain := [25*x^4*y^4+225*x^6*z^2-125*x^3*y^3*z^2+90*x^2*y^2*z^4-20*x*y*z^6+z^8];
