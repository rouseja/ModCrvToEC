
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.120.8.ci.1

// Other names and/or labels
// Cummins-Pauli label: 60D8
// Rouse-Sutherland-Zureick-Brown label: 60.120.8.68

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[1, 29, 26, 11], [23, 40, 15, 13], [29, 35, 5, 52], [52, 55, 25, 39]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 120;

// Curve data
conductor := [[2, 19], [3, 9], [5, 16]];
bad_primes := [2, 3, 5];
// Genus
g := 8;
// Rank
r := 5
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 2
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["60.24.0.bg.1", "60.30.2.q.1", "60.60.4.cq.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r> := PolynomialRing(Rationals(), 8);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [2*x*z-2*y^2-z*w,2*y^2+2*y*t+w^2-w*u-2*t^2-u^2,2*x*y-2*x*w+2*x*u+y*w+y*v-y*r+z*w-t*v+t*r-u*v,2*x^2-x*w+2*x*t-2*x*v+2*y^2+y*z-2*y*t-y*v-y*r-w*t+w*v,2*x^2-x*w-2*x*t-2*x*u-2*x*v+2*y^2-y*z-2*y*t+y*v-y*r+2*z*t-w*t-w*u+w*r,2*x*y+2*y*z+2*y*t-2*y*v+z^2-2*z*t-z*v-z*r,x^2+x*z-2*x*v-y^2-2*y*w-y*t+y*u-z^2-z*v-w*t+t^2-2*t*u+v^2,2*x*t-2*x*u-y*v+y*r+z*w+z*u+w*t-w*v,2*x*y+4*x*w+2*x*t-2*y*z-y*w-2*z*w-z*u+w^2-w*t+2*w*v-w*r-t*v-t*r+2*u*v-u*r,x*z+x*w-2*x*r-5*y*z-2*y*u+2*y*r-2*z*t-w*v+2*t^2+u^2+3*u*v-2*u*r-v*r+r^2,x^2-2*x*y+2*x*z+2*x*w-x*v-x*r+y^2+y*w-y*t-y*u+2*z^2+2*z*w+z*t+z*u-z*v-z*r+t^2+2*t*u-t*v-t*r+u^2-u*v-u*r+v*r,2*x^2+2*x*y-x*z-2*x*t-x*v+x*r-2*y*z+y*w-2*y*t-2*y*u+y*v+3*y*r-z^2-z*t+z*v+2*z*r-w^2+2*w*t-2*w*v+w*r+t*v+t*r+u*v+u*r-v^2-v*r,2*x*y-x*z+3*x*w+2*x*t-4*x*r+3*y*z-y*w-2*y*r+z*w+2*z*t-3*w*t-t*v-t*r-u*v+u*r+v*r-r^2,9*x^2+2*x*y-x*z+2*x*w+5*x*v+3*x*r+y^2+y*w+y*t+2*y*u+y*v-y*r-z^2+z*t-2*z*u-z*r+2*w*t+w*u+2*w*v-w*r+3*t^2+2*t*u-t*v-t*r-u^2+u*r+v^2,3*x^2-2*x*y-6*x*z+3*x*w-5*y^2-y*z-y*w-y*t+2*y*r+4*z^2+3*z*u+2*w^2+w*t-w*u-w*r-3*t^2-2*t*u-t*v+t*r+u^2-2*u*v-2*u*r-3*v^2+3*v*r-r^2];

// Singular plane model
model_1 := [1099008*x^14-1195776*x^13*z+60480*x^12*y*z+807552*x^12*z^2-480960*x^11*y*z^2-11088*x^10*y^2*z^2-2141184*x^11*z^3+1006176*x^10*y*z^3+170736*x^9*y^2*z^3+30432*x^8*y^3*z^3+541760*x^10*z^4-753504*x^9*y*z^4-276608*x^8*y^2*z^4+14496*x^7*y^3*z^4-7588*x^6*y^4*z^4-605408*x^9*z^5+1673504*x^8*y*z^5-131336*x^7*y^2*z^5+18200*x^6*y^3*z^5-10764*x^5*y^4*z^5+1184*x^4*y^5*z^5+275296*x^8*z^6-775344*x^7*y*z^6-305416*x^6*y^2*z^6+67584*x^5*y^3*z^6-13667*x^4*y^4*z^6+3552*x^3*y^5*z^6-128*x^2*y^6*z^6+73136*x^7*z^7+1104112*x^6*y*z^7-45080*x^5*y^2*z^7+31292*x^4*y^3*z^7-25624*x^3*y^4*z^7+4024*x^2*y^5*z^7-384*x*y^6*z^7-211072*x^6*z^8-542752*x^5*y*z^8-74240*x^4*y^2*z^8+43388*x^3*y^3*z^8-24832*x^2*y^4*z^8+2304*x*y^5*z^8-352*y^6*z^8+47568*x^5*z^9+373544*x^4*y*z^9+51112*x^3*y^2*z^9+58400*x^2*y^3*z^9-3136*x*y^4*z^9+2112*y^5*z^9-83340*x^4*z^10-206424*x^3*y*z^10-61192*x^2*y^2*z^10+2560*x*y^3*z^10-3840*y^4*z^10+34000*x^3*z^11+61144*x^2*y*z^11-6864*x*y^2*z^11+1488*y^3*z^11+9672*x^2*z^12-8552*x*y*z^12+2016*y^2*z^12-1264*x*z^13+576*y*z^13+52*z^14];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 60.60.4.cq.1
//   Coordinate number 0:
map_0_coord_0 := 1*(-x);
//   Coordinate number 1:
map_0_coord_1 := 1*(y);
//   Coordinate number 2:
map_0_coord_2 := 1*(z);
//   Coordinate number 3:
map_0_coord_3 := 1*(w);
// Codomain equation:
map_0_codomain := [2*y^2+2*x*z+z*w,36*x^3+2*y^3-2*x*y*z-z^3-6*x^2*w-3*y*z*w+4*x*w^2];

// Map from the canonical model to the plane model of modular curve with label 60.120.8.ci.1
//   Coordinate number 0:
map_1_coord_0 := 1*(y);
//   Coordinate number 1:
map_1_coord_1 := 1*(2*r);
//   Coordinate number 2:
map_1_coord_2 := 1*(z);
// Codomain equation:
map_1_codomain := [1099008*x^14-1195776*x^13*z+60480*x^12*y*z+807552*x^12*z^2-480960*x^11*y*z^2-11088*x^10*y^2*z^2-2141184*x^11*z^3+1006176*x^10*y*z^3+170736*x^9*y^2*z^3+30432*x^8*y^3*z^3+541760*x^10*z^4-753504*x^9*y*z^4-276608*x^8*y^2*z^4+14496*x^7*y^3*z^4-7588*x^6*y^4*z^4-605408*x^9*z^5+1673504*x^8*y*z^5-131336*x^7*y^2*z^5+18200*x^6*y^3*z^5-10764*x^5*y^4*z^5+1184*x^4*y^5*z^5+275296*x^8*z^6-775344*x^7*y*z^6-305416*x^6*y^2*z^6+67584*x^5*y^3*z^6-13667*x^4*y^4*z^6+3552*x^3*y^5*z^6-128*x^2*y^6*z^6+73136*x^7*z^7+1104112*x^6*y*z^7-45080*x^5*y^2*z^7+31292*x^4*y^3*z^7-25624*x^3*y^4*z^7+4024*x^2*y^5*z^7-384*x*y^6*z^7-211072*x^6*z^8-542752*x^5*y*z^8-74240*x^4*y^2*z^8+43388*x^3*y^3*z^8-24832*x^2*y^4*z^8+2304*x*y^5*z^8-352*y^6*z^8+47568*x^5*z^9+373544*x^4*y*z^9+51112*x^3*y^2*z^9+58400*x^2*y^3*z^9-3136*x*y^4*z^9+2112*y^5*z^9-83340*x^4*z^10-206424*x^3*y*z^10-61192*x^2*y^2*z^10+2560*x*y^3*z^10-3840*y^4*z^10+34000*x^3*z^11+61144*x^2*y*z^11-6864*x*y^2*z^11+1488*y^3*z^11+9672*x^2*z^12-8552*x*y*z^12+2016*y^2*z^12-1264*x*z^13+576*y*z^13+52*z^14];
