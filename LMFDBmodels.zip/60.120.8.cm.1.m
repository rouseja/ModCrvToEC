
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.120.8.cm.1

// Other names and/or labels
// Cummins-Pauli label: 60D8
// Rouse-Sutherland-Zureick-Brown label: 60.120.8.17

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[4, 19, 41, 4], [15, 4, 8, 15], [40, 43, 19, 35], [55, 26, 22, 25]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 120;

// Curve data
conductor := [[2, 19], [3, 9], [5, 16]];
bad_primes := [2, 3, 5];
// Genus
g := 8;
// Rank
r := 5
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 2
;// Number of rational cusps
Nrat_cusps := 2
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['5.5.0.a.1', '12.24.0.o.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["12.24.0.o.1", "60.30.2.s.1", "60.60.4.cq.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r> := PolynomialRing(Rationals(), 8);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x*y+x*z-x*v-y*r-z*r-u*v,y*z-y*v+z^2+z*t-z*v+w*u,y*z+y*v+z^2-z*t+z*v-w*u-t*v,x*z+x*t-z*t-z*v+z*r-w*t,2*x*z-x*t+2*z*u+t*r,x*w+x*t-x*v+z*w+z*u+w^2-w*t+w*u+w*v-w*r+t*v+u*v+v^2-v*r,2*x*y+x*z+x*w-2*y*w-z*w+z*t+z*u+z*v-z*r+w^2+w*u+w*v-w*r+u*v,x*y-x*z-x*w-y*z-y*w+y*u+y*v-y*r+z^2-z*w-z*t+z*u+z*v-z*r+w^2-w*t-w*r-t*v+u*v,x*y-x*z-x*u+y*w+y*u-y*r+z*w-z*u-z*r-w*t+w*u+u^2+u*v-u*r,2*x*w-2*x*u-2*y^2+w*t+w*v-t*u-u*v,3*x^2-2*x*w-x*t+2*x*u-x*v-2*w*u+t*r+v*r-r^2,2*x*z-3*x*w+x*t-x*u-2*x*v-y*z-2*y*u-y*v+2*y*r+z^2+2*z*w-z*t+z*v-w*u-w*r-t*v+t*r+u*r,x*y+2*x*z+2*x*t+x*u+x*v-3*x*r-2*y*u+y*r+2*z^2+z*t+z*v-w*r-u*v+v^2-2*v*r+r^2,3*x^2-x*y-3*x*u-y*z+y*w-y*u+y*r+z^2+z*w-z*t+z*u+z*v+w*t+w*u-w*r+2*t*v-v*r+r^2,x*y-x*w-2*x*t+3*x*r+2*y^2+2*y*z-y*r-2*z*w-z*t-z*v+w*t+t*u+u*v-u*r-v*r+r^2];

// Singular plane model
model_1 := [4*x^14-48*x^13*z-20*x^12*y*z+10*x^11*y^2*z+x^8*y^5*z+200*x^12*z^2+110*x^11*y*z^2-20*x^10*y^2*z^2-40*x^9*y^3*z^2-10*x^8*y^4*z^2-10*x^7*y^5*z^2-362*x^11*z^3-160*x^10*y*z^3+110*x^9*y^2*z^3+200*x^8*y^3*z^3+110*x^7*y^4*z^3+32*x^6*y^5*z^3+820*x^10*z^4-380*x^9*y*z^4-640*x^8*y^2*z^4-640*x^7*y^3*z^4-160*x^6*y^4*z^4-64*x^5*y^5*z^4+64*x^9*z^5+820*x^8*y*z^5+1080*x^7*y^2*z^5+840*x^6*y^3*z^5+280*x^5*y^4*z^5+12*x^4*y^5*z^5-32*x^8*z^6-3200*x^7*y*z^6-2280*x^6*y^2*z^6-880*x^5*y^3*z^6-40*x^4*y^4*z^6-32*x^3*y^5*z^6+2496*x^7*z^7+2240*x^6*y*z^7+440*x^5*y^2*z^7-480*x^4*y^3*z^7-280*x^3*y^4*z^7-160*x^2*y^5*z^7-1584*x^6*z^8-80*x^5*y*z^8+400*x^4*y^2*z^8+480*x^3*y^3*z^8-80*x^2*y^4*z^8-96*x*y^5*z^8+704*x^5*z^9-320*x^4*y*z^9+160*x^2*y^3*z^9-16*y^5*z^9-224*x^4*z^10+32*x^3*z^11];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 60.60.4.cq.1
//   Coordinate number 0:
map_0_coord_0 := 1*(-x);
//   Coordinate number 1:
map_0_coord_1 := 1*(-y);
//   Coordinate number 2:
map_0_coord_2 := 1*(w-u);
//   Coordinate number 3:
map_0_coord_3 := 1*(-t-v);
// Codomain equation:
map_0_codomain := [2*y^2+2*x*z+z*w,36*x^3+2*y^3-2*x*y*z-z^3-6*x^2*w-3*y*z*w+4*x*w^2];

// Map from the canonical model to the plane model of modular curve with label 60.120.8.cm.1
//   Coordinate number 0:
map_1_coord_0 := 1*(z);
//   Coordinate number 1:
map_1_coord_1 := 1*(r);
//   Coordinate number 2:
map_1_coord_2 := 1*(1/2*t);
// Codomain equation:
map_1_codomain := [4*x^14-48*x^13*z-20*x^12*y*z+10*x^11*y^2*z+x^8*y^5*z+200*x^12*z^2+110*x^11*y*z^2-20*x^10*y^2*z^2-40*x^9*y^3*z^2-10*x^8*y^4*z^2-10*x^7*y^5*z^2-362*x^11*z^3-160*x^10*y*z^3+110*x^9*y^2*z^3+200*x^8*y^3*z^3+110*x^7*y^4*z^3+32*x^6*y^5*z^3+820*x^10*z^4-380*x^9*y*z^4-640*x^8*y^2*z^4-640*x^7*y^3*z^4-160*x^6*y^4*z^4-64*x^5*y^5*z^4+64*x^9*z^5+820*x^8*y*z^5+1080*x^7*y^2*z^5+840*x^6*y^3*z^5+280*x^5*y^4*z^5+12*x^4*y^5*z^5-32*x^8*z^6-3200*x^7*y*z^6-2280*x^6*y^2*z^6-880*x^5*y^3*z^6-40*x^4*y^4*z^6-32*x^3*y^5*z^6+2496*x^7*z^7+2240*x^6*y*z^7+440*x^5*y^2*z^7-480*x^4*y^3*z^7-280*x^3*y^4*z^7-160*x^2*y^5*z^7-1584*x^6*z^8-80*x^5*y*z^8+400*x^4*y^2*z^8+480*x^3*y^3*z^8-80*x^2*y^4*z^8-96*x*y^5*z^8+704*x^5*z^9-320*x^4*y*z^9+160*x^2*y^3*z^9-16*y^5*z^9-224*x^4*z^10+32*x^3*z^11];
