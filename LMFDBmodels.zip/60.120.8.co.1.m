
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.120.8.co.1

// Other names and/or labels
// Cummins-Pauli label: 60D8
// Rouse-Sutherland-Zureick-Brown label: 60.120.8.18

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[15, 2, 29, 45], [19, 4, 11, 49], [55, 22, 46, 5], [58, 53, 1, 19]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 120;

// Curve data
conductor := [[2, 19], [3, 14], [5, 16]];
bad_primes := [2, 3, 5];
// Genus
g := 8;
// Rank
r := 6
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 2
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['5.5.0.a.1', '12.24.0.q.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["12.24.0.q.1", "60.30.2.t.1", "60.60.4.cq.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r> := PolynomialRing(Rationals(), 8);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [2*x*z+2*y^2-z*w,2*y^2-2*y*u+w^2+w*t+t^2+2*u^2,2*x*y+x*w-x*t-x*u+y*w+z*w+w*v+t*v-u*v+u*r,x*y-2*x*u+2*x*v-y*z-y*w-2*y*u-y*v-y*r+w*u-w*v,x*z+2*y*u-2*y*v-z^2-z*w-2*z*u-z*v-z*r,y^2-2*y*w-y*t-y*u+z^2+z*v+w*u+2*t*u+u^2+v^2,x*y+2*x*w+x*t+x*u+y*v-y*r+z*w+z*t+w*u+t*v-u*v+u*r,2*x*y-2*x*w-x*t+2*x*u+2*y*z+2*y*v-w^2-t*v+t*r-2*u*v,x*y-x*z+x*w+2*x*t-2*x*u-2*x*v+y*z+y*w+y*v+y*r+z^2+z*w+z*v+z*r+w^2+w*t-w*u+w*r,2*x*y-2*x*z+2*x*w+x*t-x*u-x*v+y*w-z*w-z*t+z*u-z*v+w^2-w*v-t*v-t*r+u*v+u*r-v^2-v*r,x*y-2*x*w-x*t+x*u-2*x*v+3*x*r+y^2-2*y*z+y*t+y*u+y*v-y*r-z^2-z*r+2*w*v-2*w*r+t^2-2*t*u+t*v-t*r+u^2-u*v-u*r-v^2+v*r-r^2,x*z-2*x*w+2*x*t+2*x*v+3*x*r+2*y*t+2*y*r-z*t-2*z*u-w^2-w*t+2*w*v-2*w*r-t*r-2*u*r+v*r-r^2,x*y-x*z-3*x*w+3*x*t+x*u+2*x*v-3*x*r+y*v+y*r+z*t-2*z*u-w^2-w*t-w*u-w*v-w*r-t^2+t*v-t*r-2*u^2-u*v-u*r+v*r-r^2,9*x^2+4*x*z+3*x*w-2*y^2+2*z^2+z*w+2*z*v+w^2-w*v+w*r+3*v^2-2*v*r+r^2,3*x*y+3*x*z-x*w+x*t-2*x*v-3*y^2-2*y*z-y*w-y*u-y*v-y*r+2*z^2-z*w-z*t-2*z*u+2*z*v-2*z*r+w^2-2*w*t-w*u-3*w*v-w*r-t^2-2*t*u-t*v-3*t*r+3*u^2-2*u*r+3*v^2-2*v*r];

// Singular plane model
model_1 := [352512*x^14-393984*x^13*z-1728*x^12*y*z+819072*x^12*z^2-91584*x^11*y*z^2-29808*x^10*y^2*z^2-1260288*x^11*z^3+478944*x^10*y*z^3+4176*x^9*y^2*z^3-2208*x^8*y^3*z^3+1548864*x^10*z^4-176352*x^9*y*z^4+202944*x^8*y^2*z^4+39456*x^7*y^3*z^4+2900*x^6*y^4*z^4-1279776*x^9*z^5+991008*x^8*y*z^5+120104*x^7*y^2*z^5+63032*x^6*y^3*z^5+15900*x^5*y^4*z^5+1184*x^4*y^5*z^5+1758368*x^8*z^6-284144*x^7*y*z^6+378024*x^6*y^2*z^6+49152*x^5*y^3*z^6+21767*x^4*y^4*z^6+3552*x^3*y^5*z^6+128*x^2*y^6*z^6-912688*x^7*z^7+798960*x^6*y*z^7+41464*x^5*y^2*z^7+82956*x^4*y^3*z^7+13144*x^3*y^4*z^7+4024*x^2*y^5*z^7+384*x*y^6*z^7+915136*x^6*z^8-217888*x^5*y*z^8+164432*x^4*y^2*z^8+31948*x^3*y^3*z^8+14528*x^2*y^4*z^8+2304*x*y^5*z^8+352*y^6*z^8-451728*x^5*z^9+281320*x^4*y*z^9+6936*x^3*y^2*z^9+22432*x^2*y^3*z^9+7616*x*y^4*z^9+2112*y^5*z^9+265340*x^4*z^10-71448*x^3*y*z^10+23416*x^2*y^2*z^10+12032*x*y^3*z^10+6144*y^4*z^10-98576*x^3*z^11+35288*x^2*y*z^11+5520*x*y^2*z^11+10512*y^3*z^11+40408*x^2*z^12-10920*x*y*z^12+11808*y^2*z^12-12816*x*z^13+8640*y*z^13+3132*z^14];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 60.60.4.cq.1
//   Coordinate number 0:
map_0_coord_0 := 1*(x);
//   Coordinate number 1:
map_0_coord_1 := 1*(y);
//   Coordinate number 2:
map_0_coord_2 := 1*(z);
//   Coordinate number 3:
map_0_coord_3 := 1*(-w);
// Codomain equation:
map_0_codomain := [2*y^2+2*x*z+z*w,36*x^3+2*y^3-2*x*y*z-z^3-6*x^2*w-3*y*z*w+4*x*w^2];

// Map from the canonical model to the plane model of modular curve with label 60.120.8.co.1
//   Coordinate number 0:
map_1_coord_0 := 1*(y);
//   Coordinate number 1:
map_1_coord_1 := 1*(2*r);
//   Coordinate number 2:
map_1_coord_2 := 1*(z);
// Codomain equation:
map_1_codomain := [352512*x^14-393984*x^13*z-1728*x^12*y*z+819072*x^12*z^2-91584*x^11*y*z^2-29808*x^10*y^2*z^2-1260288*x^11*z^3+478944*x^10*y*z^3+4176*x^9*y^2*z^3-2208*x^8*y^3*z^3+1548864*x^10*z^4-176352*x^9*y*z^4+202944*x^8*y^2*z^4+39456*x^7*y^3*z^4+2900*x^6*y^4*z^4-1279776*x^9*z^5+991008*x^8*y*z^5+120104*x^7*y^2*z^5+63032*x^6*y^3*z^5+15900*x^5*y^4*z^5+1184*x^4*y^5*z^5+1758368*x^8*z^6-284144*x^7*y*z^6+378024*x^6*y^2*z^6+49152*x^5*y^3*z^6+21767*x^4*y^4*z^6+3552*x^3*y^5*z^6+128*x^2*y^6*z^6-912688*x^7*z^7+798960*x^6*y*z^7+41464*x^5*y^2*z^7+82956*x^4*y^3*z^7+13144*x^3*y^4*z^7+4024*x^2*y^5*z^7+384*x*y^6*z^7+915136*x^6*z^8-217888*x^5*y*z^8+164432*x^4*y^2*z^8+31948*x^3*y^3*z^8+14528*x^2*y^4*z^8+2304*x*y^5*z^8+352*y^6*z^8-451728*x^5*z^9+281320*x^4*y*z^9+6936*x^3*y^2*z^9+22432*x^2*y^3*z^9+7616*x*y^4*z^9+2112*y^5*z^9+265340*x^4*z^10-71448*x^3*y*z^10+23416*x^2*y^2*z^10+12032*x*y^3*z^10+6144*y^4*z^10-98576*x^3*z^11+35288*x^2*y*z^11+5520*x*y^2*z^11+10512*y^3*z^11+40408*x^2*z^12-10920*x*y*z^12+11808*y^2*z^12-12816*x*z^13+8640*y*z^13+3132*z^14];
