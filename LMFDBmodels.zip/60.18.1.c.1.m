
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.18.1.c.1

// Other names and/or labels
// Cummins-Pauli label: 12B1
// Rouse-Sutherland-Zureick-Brown label: 60.18.1.5

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[3, 50, 19, 51], [7, 8, 32, 35], [13, 0, 6, 7], [29, 52, 1, 19], [31, 10, 8, 43]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 18;

// Curve data
conductor := [[2, 2], [3, 2], [5, 2]];
bad_primes := [2, 3, 5];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 3
;// Number of rational cusps
Nrat_cusps := 1
;// CM discriminants
CM_discs := [-4];
// Modular curve is a fiber product of the following curvesfactors := ['3.3.0.a.1', '20.6.0.c.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["6.9.0.a.1", "20.6.0.c.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3-y^2*z+125*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := 2^6*((4*y^2-375*z^2)^3);
//   Coordinate number 1:
map_0_coord_1 := 5^6*(z^4*(y^2-125*z^2));
