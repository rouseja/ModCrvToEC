
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.18.1.e.1

// Other names and/or labels
// Cummins-Pauli label: 12B1
// Rouse-Sutherland-Zureick-Brown label: 60.18.1.8

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[5, 16, 38, 41], [13, 0, 24, 19], [27, 32, 56, 9], [39, 32, 53, 45], [59, 34, 13, 1]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 18;

// Curve data
conductor := [[2, 4], [3, 2], [5, 2]];
bad_primes := [2, 3, 5];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 3
;// Number of rational cusps
Nrat_cusps := 1
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["6.9.0.a.1", "60.6.0.b.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3-y^2*z+3375*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := -2^6*3^3*(405*x^2*y^4-251505000*x^2*y^2*z^2+2671044609375*x^2*z^4-64800*x*y^4*z+7832193750*x*y^2*z^3-39650480859375*x*z^5-y^6+5315625*y^4*z^2-179914921875*y^2*z^4+597871125000000*z^6);
//   Coordinate number 1:
map_0_coord_1 := 1*(1366875*x^2*y^2*z^2-13839609375*x^2*z^4-2025*x*y^4*z+41006250*x*y^2*z^3-207594140625*x*z^5+y^6-30375*y^4*z^2);
