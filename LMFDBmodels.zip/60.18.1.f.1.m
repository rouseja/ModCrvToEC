
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.18.1.f.1

// Other names and/or labels
// Cummins-Pauli label: 12B1
// Rouse-Sutherland-Zureick-Brown label: 60.18.1.9

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[9, 50, 16, 27], [27, 20, 11, 21], [31, 30, 6, 29], [37, 30, 30, 53], [43, 4, 34, 35]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 18;

// Curve data
conductor := [[2, 2], [3, 2], [5, 2]];
bad_primes := [2, 3, 5];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 3
;// Number of rational cusps
Nrat_cusps := 1
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["6.9.0.a.1", "60.6.0.c.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3-y^2*z-3375*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := 2^6*((4*y^2+10125*z^2)^3);
//   Coordinate number 1:
map_0_coord_1 := 3^6*5^6*(z^4*(y^2+3375*z^2));
