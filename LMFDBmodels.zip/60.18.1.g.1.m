
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.18.1.g.1

// Other names and/or labels
// Cummins-Pauli label: 12C1
// Rouse-Sutherland-Zureick-Brown label: 60.18.1.3

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[1, 26, 28, 19], [15, 22, 11, 15], [23, 54, 39, 13], [47, 12, 9, 25], [47, 32, 22, 53]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 18;

// Curve data
conductor := [[2, 4], [3, 2], [5, 2]];
bad_primes := [2, 3, 5];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 2
;// Number of rational cusps
Nrat_cusps := 2
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["6.9.0.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3-y^2*z+150*x*z^2+875*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := 2^6*(45*x^2*y^4+1012500*x^2*y^2*z^2+6321796875*x^2*z^4+450*x*y^4*z+2531250*x*y^2*z^3-31608984375*x*z^5+y^6+34875*y^4*z^2+408796875*y^2*z^4+2144285156250*z^6);
//   Coordinate number 1:
map_0_coord_1 := 3^3*5^3*(z^2*(30*x^2*y^2-50625*x^2*z^2+75*x*y^2*z+253125*x*z^3+y^4-3750*y^2*z^2+2531250*z^4));
