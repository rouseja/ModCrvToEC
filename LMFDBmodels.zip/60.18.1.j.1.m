
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.18.1.j.1

// Other names and/or labels
// Cummins-Pauli label: 12C1
// Rouse-Sutherland-Zureick-Brown label: 60.18.1.4

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[17, 16, 22, 25], [17, 42, 24, 13], [19, 6, 57, 17], [23, 8, 55, 53], [27, 8, 26, 51]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 18;

// Curve data
conductor := [[2, 3], [3, 1], [5, 2]];
bad_primes := [2, 3, 5];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 2
;// Number of rational cusps
Nrat_cusps := 2
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["6.9.0.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3+x^2*z-y^2*z+17*x*z^2+38*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := 2^6*(15*x^2*y^4+12500*x^2*y^2*z^2+2890625*x^2*z^4+60*x*y^4*z+18750*x*y^2*z^3-2890625*x*z^5+y^6+1310*y^4*z^2+565625*y^2*z^4+107656250*z^6);
//   Coordinate number 1:
map_0_coord_1 := 5^3*(z^2*(10*x^2*y^2-625*x^2*z^2+15*x*y^2*z+625*x*z^3+y^4-135*y^2*z^2+3750*z^4));
