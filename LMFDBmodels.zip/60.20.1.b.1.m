
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.20.1.b.1

// Other names and/or labels
// Cummins-Pauli label: 10C1
// Rouse-Sutherland-Zureick-Brown label: 60.20.1.2

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[15, 31, 59, 30], [25, 59, 41, 30], [37, 59, 9, 34], [39, 25, 2, 31]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 20;

// Curve data
conductor := [[2, 4], [3, 2], [5, 1]];
bad_primes := [2, 3, 5];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 2
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["5.10.0.a.1", "60.2.0.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w> := PolynomialRing(Rationals(), 4);
// Isomorphic to P^1?
is_P1 := false;

// Embedded model
model_0 := [2*x*z-y*z+3*x*w+y*w,9*x^2+6*x*y+21*y^2+z^2+3*z*w+w^2];

// Singular plane model
model_1 := [36*x^4+105*x^2*y^2+72*x^3*z+80*x*y^2*z+49*x^2*z^2+20*y^2*z^2+13*x*z^3+z^4];

// Maps from this modular curve, if computed

// j-invariant map from the embedded model
//   Coordinate number 0:
map_0_coord_0 := 3^3*(30240000*x*y^5+13860000*x*y^3*w^2-7614000*x*y*w^4-25704000*y^6+36918000*y^4*w^2-5197500*y^2*w^4+342272*z^6+316288*z^5*w+76160*z^4*w^2-447960*z^3*w^3-1691265*z^2*w^4-1152302*z*w^5-218193*w^6);
//   Coordinate number 1:
map_0_coord_1 := 1*(472500*x*y^5+258750*x*y^3*w^2-13500*x*y*w^4-401625*y^6+330750*y^4*w^2-33750*y^2*w^4-67*z^6-739*z^5*w-3662*z^4*w^2-9617*z^3*w^3-13552*z^2*w^4-9625*z*w^5-2163*w^6);

// Map from the embedded model to the plane model of modular curve with label 60.20.1.b.1
//   Coordinate number 0:
map_1_coord_0 := 1*(z);
//   Coordinate number 1:
map_1_coord_1 := 1*(3*y);
//   Coordinate number 2:
map_1_coord_2 := 1*(3*w);
// Codomain equation:
map_1_codomain := [36*x^4+105*x^2*y^2+72*x^3*z+80*x*y^2*z+49*x^2*z^2+20*y^2*z^2+13*x*z^3+z^4];
