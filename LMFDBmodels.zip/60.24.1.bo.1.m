
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.24.1.bo.1

// Other names and/or labels
// Cummins-Pauli label: 12G1
// Rouse-Sutherland-Zureick-Brown label: 60.24.1.34

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[16, 41, 39, 32], [23, 39, 51, 56], [41, 48, 39, 23], [51, 58, 7, 17]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 24;

// Curve data
conductor := [[2, 4], [3, 2], [5, 2]];
bad_primes := [2, 3, 5];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 2
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['4.4.0.a.1', '15.6.0.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["12.12.0.q.1", "15.6.0.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w> := PolynomialRing(Rationals(), 4);
// Isomorphic to P^1?
is_P1 := false;

// Embedded model
model_0 := [y^2+2*x*z,135*x^2-45*x*y+3*y^2-2*x*z+7*y*z+4*z^2+y*w-z*w+w^2];

// Singular plane model
model_1 := [270*x^4+90*x^3*z+8*x^2*z^2+2*x*y*z^2+2*y^2*z^2+7*x*z^3-y*z^3+2*z^4];

// Maps from this modular curve, if computed

// j-invariant map from the embedded model
//   Coordinate number 0:
map_0_coord_0 := -3^6*5^2*(z*(1465688*x*y*z^3-13737600*x*y*z^2*w+9953280*x*y*z*w^2+2066176*x*z^4-5741184*x*z^3*w+4233600*x*z^2*w^2-552960*x*z*w^3+295168*y*z^4-1011584*y*z^3*w+1266816*y*z^2*w^2-645120*y*z*w^3+138240*y*w^4-446761*z^5+2070272*z^4*w-1799936*z^3*w^2+520192*z^2*w^3-184320*z*w^4));
//   Coordinate number 1:
map_0_coord_1 := 1*(8064990*x*y*z^4+49599270*x*y*z^3*w-17040375*x*y*z^2*w^2-10570500*x*y*z*w^3+2460375*x*y*w^4+2031188*x*z^5-3374010*x*z^4*w-2931660*x*z^3*w^2+4920750*x*z^2*w^3-1093500*x*z*w^4+1613168*y*z^5-2986726*y*z^4*w-708435*y*z^3*w^2+3016845*y*z^2*w^3-601425*y*z*w^4-54675*y*w^5-840544*z^6-3911144*z^5*w+2723684*z^4*w^2-1068795*z^3*w^3+293625*z^2*w^4+127575*z*w^5-18225*w^6);

// Map from the embedded model to the plane model of modular curve with label 60.24.1.bo.1
//   Coordinate number 0:
map_1_coord_0 := 1*(y);
//   Coordinate number 1:
map_1_coord_1 := 1*(w);
//   Coordinate number 2:
map_1_coord_2 := 1*(2*z);
// Codomain equation:
map_1_codomain := [270*x^4+90*x^3*z+8*x^2*z^2+2*x*y*z^2+2*y^2*z^2+7*x*z^3-y*z^3+2*z^4];
