
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.24.1.x.1

// Other names and/or labels
// Cummins-Pauli label: 12F1
// Rouse-Sutherland-Zureick-Brown label: 60.24.1.8

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[1, 18, 12, 29], [1, 24, 48, 19], [1, 34, 48, 25], [58, 17, 21, 32], [59, 10, 18, 19]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 24;

// Curve data
conductor := [[2, 3], [3, 1], [5, 2]];
bad_primes := [2, 3, 5];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 4
;// Number of rational cusps
Nrat_cusps := 4
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['3.4.0.a.1', '20.6.0.d.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["6.12.0.a.1", "20.6.0.d.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3+x^2*z-y^2*z-608*x*z^2-5712*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := 1*(20*x^2*y^6+189375*x^2*y^4*z^2+478750000*x^2*y^2*z^4+400791015625*x^2*z^6+830*x*y^6*z+5501250*x*y^4*z^3+13943515625*x*y^2*z^5+11787343750000*x*z^7+y^8+11830*y^6*z^2+50854375*y^4*z^4+106223984375*y^2*z^6+84734218750000*z^8);
//   Coordinate number 1:
map_0_coord_1 := 5^6*(z^4*y^2*(40*x^2+1160*x*z+y^2+8160*z^2));
