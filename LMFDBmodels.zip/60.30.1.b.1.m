
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.30.1.b.1

// Other names and/or labels
// Cummins-Pauli label: 10E1
// Rouse-Sutherland-Zureick-Brown label: 60.30.1.1

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[5, 49, 51, 50], [15, 11, 44, 25], [20, 13, 31, 15], [40, 9, 17, 25]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 30;

// Curve data
conductor := [[2, 4], [3, 2], [5, 1]];
bad_primes := [2, 3, 5];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 3
;// Number of rational cusps
Nrat_cusps := 1
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["5.15.0.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3-y^2*z-12*x*z^2+11*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := 1*(15*x^2*y^8-4860*x^2*y^6*z^2+4107186*x^2*y^4*z^4+5297640084*x^2*y^2*z^6+121801494231*x^2*z^8+105*x*y^8*z-181764*x*y^6*z^3+60243102*x*y^4*z^5+27747125100*x*y^2*z^7+869140400481*x*z^9-y^10-660*y^8*z^2-721710*y^6*z^4+894211812*y^4*z^6+77966350983*y^2*z^8-966146983416*z^10);
//   Coordinate number 1:
map_0_coord_1 := 3^5*(z^3*(9*x^2*y^4*z-729*x^2*y^2*z^3-6561*x^2*z^5-x*y^6+63*x*y^4*z^2-6561*x*z^6-5*y^6*z-72*y^4*z^3+9477*y^2*z^5+72171*z^7));
