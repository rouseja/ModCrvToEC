
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.36.1.dn.1

// Other names and/or labels
// Cummins-Pauli label: 20E1
// Rouse-Sutherland-Zureick-Brown label: 60.36.1.44

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[3, 40, 32, 29], [7, 55, 50, 43], [31, 30, 24, 13], [33, 50, 2, 39], [59, 15, 46, 29]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 36;

// Curve data
conductor := [[2, 4], [3, 2], [5, 2]];
bad_primes := [2, 3, 5];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 4
;// Number of rational cusps
Nrat_cusps := 4
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["10.18.0.a.1", "60.6.0.e.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3-y^2*z-1575*x*z^2-20250*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := 1*(90*x^2*y^10+10341168750*x^2*y^8*z^2+20951234465625000*x^2*y^6*z^4+11318606236742519531250*x^2*y^4*z^6+1268637809631008840332031250*x^2*y^2*z^8+41092642599509990435943603515625*x^2*z^10+170775*x*y^10*z+897001087500*x*y^8*z^3+2564439136330078125*x*y^6*z^5+699420105219571875000000*x*y^4*z^7+66888578184317822955322265625*x*y^2*z^9+1846162138654227015046691894531250*x*z^11+y^12+15032250*y^10*z^2+255408179906250*y^8*z^4+152655976309394531250*y^6*z^6+27109172873815530029296875*y^4*z^8+1399421756819545867858886718750*y^2*z^10+18446587500977102518238067626953125*z^12);
//   Coordinate number 1:
map_0_coord_1 := 3^2*5^2*(z*y^2*(2250*x^2*y^6*z-41006250*x^2*y^4*z^3+266540625000*x^2*y^2*z^5-553584375000000*x^2*z^7+x*y^8+353109375*x*y^4*z^4-3383015625000*x*y^2*z^6+8303765625000000*x*z^8+90*y^8*z-3796875*y^6*z^3+62534531250*y^4*z^5-378282656250000*y^2*z^7+747338906250000000*z^9));
