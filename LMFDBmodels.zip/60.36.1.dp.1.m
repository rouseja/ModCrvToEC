
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.36.1.dp.1

// Other names and/or labels
// Cummins-Pauli label: 15E1
// Rouse-Sutherland-Zureick-Brown label: 60.36.1.48

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[17, 0, 57, 29], [26, 45, 39, 44], [36, 5, 43, 57], [37, 5, 53, 32], [58, 35, 1, 19]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 36;

// Curve data
conductor := [[2, 4], [3, 1], [5, 1]];
bad_primes := [2, 3, 5];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 4
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['5.6.0.a.1', '12.6.0.e.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["12.6.0.e.1", "15.18.0.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w> := PolynomialRing(Rationals(), 4);
// Isomorphic to P^1?
is_P1 := false;

// Embedded model
model_0 := [x^2-y*z,x^2+10*x*y-25*y^2+2*x*z-z^2-w^2];

// Singular plane model
model_1 := [25*x^4-10*x^3*z-x^2*z^2+y^2*z^2-2*x*z^3+z^4];

// Maps from this modular curve, if computed

// j-invariant map from the embedded model
//   Coordinate number 0:
map_0_coord_0 := 2*(118162368*x*z^8-5590589760*x*z^6*w^2-1470771000*x*z^4*w^4+48525000*x*z^2*w^6+625000*x*w^8-1477029600*y^2*z^7+54798660000*y^2*z^5*w^2+6305343750*y^2*z^3*w^4+99609375*y^2*z*w^6+59081184*y*z^8-3173310000*y*z^6*w^2+1204436250*y*z^4*w^4+56484375*y*z^2*w^6+390625*y*w^8-14602464*z^9-192726864*z^7*w^2+1230094350*z^5*w^4+192187500*z^3*w^6+4671875*z*w^8);
//   Coordinate number 1:
map_0_coord_1 := 1*(z*(136762*x*z^7-668140*x*z^5*w^2-23000*x*z^3*w^4+137500*x*z*w^6-1709525*y^2*z^6+10517500*y^2*z^4*w^2-8296875*y^2*z^2*w^4+390625*y^2*w^6+68381*y*z^7+403100*y*z^5*w^2-755625*y*z^3*w^4+171875*y*z*w^6-16901*z^8+108399*z^6*w^2-39075*z^4*w^4-148750*z^2*w^6+15625*w^8));

// Map from the embedded model to the plane model of modular curve with label 60.36.1.dp.1
//   Coordinate number 0:
map_1_coord_0 := 1*(x);
//   Coordinate number 1:
map_1_coord_1 := 1*(w);
//   Coordinate number 2:
map_1_coord_2 := 1*(z);
// Codomain equation:
map_1_codomain := [25*x^4-10*x^3*z-x^2*z^2+y^2*z^2-2*x*z^3+z^4];
