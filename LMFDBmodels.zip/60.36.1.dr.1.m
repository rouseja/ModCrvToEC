
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.36.1.dr.1

// Other names and/or labels
// Cummins-Pauli label: 20E1
// Rouse-Sutherland-Zureick-Brown label: 60.36.1.37

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[17, 5, 20, 57], [43, 35, 20, 39], [47, 30, 28, 23], [49, 35, 2, 9], [51, 40, 40, 1]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 36;

// Curve data
conductor := [[2, 4], [3, 2], [5, 1]];
bad_primes := [2, 3, 5];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 4
;// Number of rational cusps
Nrat_cusps := 4
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['5.6.0.a.1', '12.6.0.g.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["10.18.0.a.1", "12.6.0.g.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3-y^2*z-63*x*z^2-162*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := 1*(2178*x^2*y^10+40896533070*x^2*y^8*z^2+1277170558472520*x^2*y^6*z^4+4591687596550680834*x^2*y^4*z^6+4285533220205407157322*x^2*y^2*z^8+1101996320155783194438441*x^2*z^10+1652751*x*y^10*z+1855142976348*x*y^8*z^3+24617426819450445*x*y^6*z^5+60031245281671783872*x*y^4*z^7+44692110209891028389553*x*y^2*z^9+9917962942523647731137802*x*z^11+y^12+487461618*y^10*z^2+55152269145594*y^8*z^4+334764447857650890*y^6*z^6+453383331638098004091*y^4*z^8+187339448733633069022998*y^2*z^10+19835921952668731670246061*z^12);
//   Coordinate number 1:
map_0_coord_1 := 3*(y^4*(x^2*y^6-17280*x^2*y^4*z^2-1492992*x^2*y^2*z^4-322486272*x^2*z^6-54*x*y^6*z+155520*x*y^4*z^3+13436928*x*y^2*z^5+967458816*x*z^7+1269*y^6*z^2+62208*y^4*z^4+26873856*y^2*z^6+17414258688*z^8));
