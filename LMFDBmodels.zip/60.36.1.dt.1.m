
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.36.1.dt.1

// Other names and/or labels
// Cummins-Pauli label: 15E1
// Rouse-Sutherland-Zureick-Brown label: 60.36.1.182

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[13, 19, 10, 59], [17, 10, 31, 43], [29, 32, 47, 9], [37, 31, 10, 51], [58, 1, 49, 56]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 36;

// Curve data
conductor := [[2, 4], [3, 1], [5, 2]];
bad_primes := [2, 3, 5];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 4
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["15.18.0.a.1", "60.6.0.g.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w> := PolynomialRing(Rationals(), 4);
// Isomorphic to P^1?
is_P1 := false;

// Embedded model
model_0 := [x^2+x*y+y*w,5*x^2-7*x*y+25*y^2+5*z^2+4*x*w+3*y*w+w^2];

// Singular plane model
model_1 := [37*x^4+5*x^2*y^2+18*x^3*z+10*x*y^2*z+11*x^2*z^2+5*y^2*z^2+6*x*z^3+z^4];

// Maps from this modular curve, if computed

// j-invariant map from the embedded model
//   Coordinate number 0:
map_0_coord_0 := 2*3*(691783153583750*x*z^8-17937880600230000*x*z^6*w^2-8183694710935800*x*z^4*w^4+3637323527153760*x*z^2*w^6+45950840034048*x*w^8+35766758219566875*y^2*z^6*w-145334783701118250*y^2*z^4*w^3+27764459752395600*y^2*z^2*w^5+269015657876640*y^2*w^7-118664846416250*y*z^8+10942719397041000*y*z^6*w^2-25842964299500700*y*z^4*w^4-1510404496387200*y*z^2*w^6+42061084353216*y*w^8+8034998551763125*z^8*w-39781602852403875*z^6*w^3+7435723273876350*z^4*w^5+249989299598160*z^2*w^7+14784340543776*w^9);
//   Coordinate number 1:
map_0_coord_1 := 1*(1187179687500*x*z^8-6222532812500*x*z^6*w^2-7236733566900*x*z^4*w^4+192721318980*x*z^2*w^6+159551527896*x*w^8-17313037109375*y^2*z^6*w-47664970802625*y^2*z^4*w^3+12127923572475*y^2*z^2*w^5+934082145405*y^2*w^7-12861113281250*y*z^6*w^2+7808427794850*y*z^4*w^4+1193561473770*y*z^2*w^6+146045431782*y*w^8-2275427734375*z^8*w-7754813442500*z^6*w^3-815621600850*z^4*w^5+385537374540*z^2*w^7+51334515777*w^9);

// Map from the embedded model to the plane model of modular curve with label 60.36.1.dt.1
//   Coordinate number 0:
map_1_coord_0 := 1*(x);
//   Coordinate number 1:
map_1_coord_1 := 1*(z);
//   Coordinate number 2:
map_1_coord_2 := 1*(w);
// Codomain equation:
map_1_codomain := [37*x^4+5*x^2*y^2+18*x^3*z+10*x*y^2*z+11*x^2*z^2+5*y^2*z^2+6*x*z^3+z^4];
