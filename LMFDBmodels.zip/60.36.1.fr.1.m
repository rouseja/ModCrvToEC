
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.36.1.fr.1

// Other names and/or labels
// Cummins-Pauli label: 12J1
// Rouse-Sutherland-Zureick-Brown label: 60.36.1.60

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[3, 50, 56, 57], [5, 18, 48, 59], [25, 44, 19, 31], [33, 52, 14, 45], [45, 58, 7, 15]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 36;

// Curve data
conductor := [[2, 2], [3, 2], [5, 2]];
bad_primes := [2, 3, 5];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 3
;// Number of rational cusps
Nrat_cusps := 1
;// CM discriminants
CM_discs := [-4];
// Modular curve is a fiber product of the following curvesfactors := ['3.3.0.a.1', '20.12.0.o.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["12.18.0.l.1", "20.12.0.o.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3-y^2*z+125*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := -2^6*3^3*(180*x^2*y^10+3375000*x^2*y^8*z^2+16351875000*x^2*y^6*z^4-21642187500000*x^2*y^4*z^6+7806137695312500*x^2*y^2*z^8-728822021484375000*x^2*z^10+10800*x*y^10*z+88425000*x*y^8*z^3-166556250000*x*y^6*z^5+176554687500000*x*y^4*z^7-48267773437500000*x*y^2*z^9+3644110107421875000*x*z^11+y^12+245250*y^10*z^2-178453125*y^8*z^4+2044617187500*y^6*z^6-1432549072265625*y^4*z^8+293531066894531250*y^2*z^10-18295635223388671875*z^12);
//   Coordinate number 1:
map_0_coord_1 := 1*(90*x^2*y^10-590625*x^2*y^8*z^2-253125000*x^2*y^6*z^4+71191406250*x^2*y^4*z^6+26696777343750*x^2*y^2*z^8-1001129150390625*x^2*z^10-3375*x*y^10*z-84375*x*y^8*z^3-2214843750*x*y^6*z^5-783105468750*x*y^4*z^7+93438720703125*x*y^2*z^9+5005645751953125*x*z^11-y^12+65250*y^10*z^2+45562500*y^8*z^4+15187500000*y^6*z^6-3737548828125*y^4*z^8-400451660156250*y^2*z^10+50056457519531250*z^12);
