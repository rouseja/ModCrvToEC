
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.36.1.ft.1

// Other names and/or labels
// Cummins-Pauli label: 12J1
// Rouse-Sutherland-Zureick-Brown label: 60.36.1.64

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[11, 34, 7, 57], [15, 28, 58, 43], [37, 30, 25, 47], [39, 8, 55, 33], [51, 22, 34, 37]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 36;

// Curve data
conductor := [[2, 2], [3, 2], [5, 2]];
bad_primes := [2, 3, 5];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 3
;// Number of rational cusps
Nrat_cusps := 1
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["12.18.0.l.1", "60.12.0.bn.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3-y^2*z-3375*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := -2^6*3^3*(540*x^2*y^10-273375000*x^2*y^8*z^2+35761550625000*x^2*y^6*z^4+1277949529687500000*x^2*y^4*z^6+12445504868803710937500*x^2*y^2*z^8+31373398217493896484375000*x^2*z^10-97200*x*y^10*z+21487275000*x*y^8*z^3+1092775556250000*x*y^6*z^5+31276133226562500000*x*y^4*z^7+230863264050585937500000*x*y^2*z^9+470600973262408447265625000*x*z^11-y^12+6621750*y^10*z^2+130092328125*y^8*z^4+40244200101562500*y^6*z^6+761315311513916015625*y^4*z^8+4211849980480407714843750*y^2*z^10+7088103944810863494873046875*z^12);
//   Coordinate number 1:
map_0_coord_1 := 1*(270*x^2*y^10+47840625*x^2*y^8*z^2-553584375000*x^2*y^6*z^4-4203781347656250*x^2*y^4*z^6+42563286145019531250*x^2*y^2*z^8+43095327221832275390625*x^2*z^10+30375*x*y^10*z-20503125*x*y^8*z^3+14531589843750*x*y^6*z^5-138724784472656250*x*y^4*z^7-446914504522705078125*x*y^2*z^9+646429908327484130859375*x*z^11+y^12+1761750*y^10*z^2-33215062500*y^8*z^4+298935562500000*y^6*z^6+1986286686767578125*y^4*z^8-5746043629577636718750*y^2*z^10-19392897249824523925781250*z^12);
