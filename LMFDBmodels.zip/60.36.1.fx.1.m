
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.36.1.fx.1

// Other names and/or labels
// Cummins-Pauli label: 12M1
// Rouse-Sutherland-Zureick-Brown label: 60.36.1.55

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[5, 12, 39, 7], [21, 32, 14, 57], [37, 12, 27, 55], [53, 46, 2, 47], [53, 54, 54, 35]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 36;

// Curve data
conductor := [[2, 4], [3, 2], [5, 2]];
bad_primes := [2, 3, 5];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 3
;// Number of rational cusps
Nrat_cusps := 1
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["12.18.0.l.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3-y^2*z+150*x*z^2+875*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := -2^6*(180*x^2*y^10-20250000*x^2*y^8*z^2+28704375000*x^2*y^6*z^4+249112968750000*x^2*y^4*z^6+210189067382812500*x^2*y^2*z^8-14400*x*y^10*z+368550000*x*y^8*z^3+533081250000*x*y^6*z^5-1245564843750000*x*y^4*z^7-4203781347656250000*x*y^2*z^9-y^12+686250*y^10*z^2-6433171875*y^8*z^4-10507851562500*y^6*z^6+26079013916015625*y^4*z^8+44665176818847656250*y^2*z^10+39903080760955810546875*z^12);
//   Coordinate number 1:
map_0_coord_1 := 3^6*5^6*(z^4*(120*x^2*y^6-2430000*x^2*y^4*z^2+1366875000*x^2*y^2*z^4-6000*x*y^6*z+12150000*x*y^4*z^3-27337500000*x*y^2*z^5-y^8+169500*y^6*z^2-311343750*y^4*z^4+290460937500*y^2*z^6-129746337890625*z^8));
