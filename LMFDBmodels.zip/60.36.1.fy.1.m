
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.36.1.fy.1

// Other names and/or labels
// Cummins-Pauli label: 30C1
// Rouse-Sutherland-Zureick-Brown label: 60.36.1.181

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[11, 29, 50, 49], [12, 1, 25, 14], [44, 21, 1, 58], [56, 21, 25, 13], [57, 10, 52, 41]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 36;

// Curve data
conductor := [[2, 4], [5, 2]];
bad_primes := [2, 3, 5];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 2
;// Number of rational cusps
Nrat_cusps := 2
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["15.18.0.a.1", "60.6.0.h.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3+x^2*z-y^2*z+92*x*z^2-312*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := -1*(60*x^2*y^10+190625*x^2*y^8*z^2+198437500*x^2*y^6*z^4+21005859375*x^2*y^4*z^6-9487304687500*x^2*y^2*z^8-531158447265625*x^2*z^10-1110*x*y^10*z-1950000*x*y^8*z^3+256640625*x*y^6*z^5+751699218750*x*y^4*z^7+80672607421875*x*y^2*z^9-3442993164062500*x*z^11-y^12+4040*y^10*z^2-5100000*y^8*z^4-8864453125*y^6*z^6-2634091796875*y^4*z^8-103592529296875*y^2*z^10+14632568359375000*z^12);
//   Coordinate number 1:
map_0_coord_1 := 5^15*(z^10*(10*x^2+65*x*z-y^2-285*z^2));
