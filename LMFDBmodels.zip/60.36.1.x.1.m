
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 60.36.1.x.1

// Other names and/or labels
// Cummins-Pauli label: 20D1
// Rouse-Sutherland-Zureick-Brown label: 60.36.1.38

// Group data
level := 60;
// Elements that, together with Gamma(level), generate the group
gens := [[11, 55, 58, 3], [13, 55, 22, 57], [19, 5, 0, 1], [21, 10, 58, 11], [43, 55, 42, 11]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 36;

// Curve data
conductor := [[2, 2], [3, 2], [5, 1]];
bad_primes := [2, 3, 5];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 6
;// Number of rational cusps
Nrat_cusps := 2
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['5.6.0.a.1', '12.6.0.c.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["10.18.0.a.1", "12.6.0.c.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3-y^2*z+33*x*z^2-74*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := 1*(54*x^2*y^10+18781470*x^2*y^8*z^2+350820081720*x^2*y^6*z^4+167464938244266*x^2*y^4*z^6+8546740304585166*x^2*y^2*z^8+224356191853792041*x^2*z^10+7479*x*y^10*z+554246064*x*y^8*z^3+4067091761805*x*y^6*z^5+313163536911804*x*y^4*z^7+50387636391717897*x*y^2*z^9-527896093987518894*x*z^11+y^12+303966*y^10*z^2+17864762706*y^8*z^4+37844021407230*y^6*z^6+5690412910113651*y^4*z^8+382298686156862586*y^2*z^10+11981502460843072749*z^12);
//   Coordinate number 1:
map_0_coord_1 := 3^2*(z*(450*x^2*y^8*z+709074*x^2*y^6*z^3-683971128*x^2*y^4*z^5-169726666464*x^2*y^2*z^7-2467858948992*x^2*z^9+x*y^10-7740*x*y^8*z^2+12979359*x*y^6*z^4+5198700204*x*y^4*z^6-318391263216*x*y^2*z^8-67732044910272*x*z^10+46*y^10*z-105795*y^8*z^3-61241346*y^6*z^5+10609661880*y^4*z^7+3040210985760*y^2*z^9+145335525616512*z^11));
