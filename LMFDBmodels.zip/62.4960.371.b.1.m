
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 62.4960.371.b.1


// Group data
level := 62;
// Elements that, together with Gamma(level), generate the group
gens := [[7, 23, 0, 55], [59, 11, 47, 34]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 4960;

// Curve data
conductor := [[2, 418], [31, 732]];
bad_primes := [2, 31];
// Genus
g := 371;
// Rank
r := 183
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 80
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["31.2480.162.a.1", "62.992.75.b.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
