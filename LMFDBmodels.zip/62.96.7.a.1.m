
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 62.96.7.a.1

// Other names and/or labels
// Curve name: X0(62)
// Cummins-Pauli label: 62A7
// Rouse-Sutherland-Zureick-Brown label: 62.96.7.1

// Group data
level := 62;
// Elements that, together with Gamma(level), generate the group
gens := [[7, 8, 0, 21], [37, 40, 0, 19], [39, 61, 0, 53]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 96;

// Curve data
conductor := [[2, 3], [31, 7]];
bad_primes := [2, 31];
// Genus
g := 7;
// Rank
r := 0
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 4
;// Number of rational cusps
Nrat_cusps := 4
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['2.3.0.a.1', '31.32.2.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["2.3.0.a.1", "31.32.2.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v> := PolynomialRing(Rationals(), 7);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x*z-y*t,x*y-y*z+x*v+w*v,x*y+x*z+x*v+y*v,x*y-x*w+w*t+t^2,x^2-x*z+x*w-w*t-x*v+t*v,x*z+x*w+x*t+w*t+x*v+w*v,x*z+z*t+z*v+t*v,x*y+y^2-w*v-t*v,y^2-y*w+z*w+z*t,x*z+y*w+w^2+w*t+x*u-z*u-w*u-t*u+u^2-2*u*v];

// Singular plane model
model_1 := [-x^9-4*x^8*y-6*x^8*z-8*x^7*y^2-23*x^7*y*z-14*x^7*z^2-9*x^6*y^3-33*x^6*y^2*z-46*x^6*y*z^2-12*x^6*z^3-5*x^5*y^4-28*x^5*y^3*z-43*x^5*y^2*z^2-30*x^5*y*z^3-4*x^5*z^4-2*x^4*y^5-x^4*y^4*z-15*x^4*y^3*z^2-8*x^4*y^2*z^3-4*x^4*y*z^4-2*x^3*y^6-5*x^3*y^5*z+7*x^3*y^4*z^2-2*x^3*y^3*z^3-x^2*y^7-x^2*y^6*z-3*x^2*y^5*z^2+4*x^2*y^4*z^3+2*x*y^6*z^2+y^8*z];

// Maps from this modular curve, if computed

// j-invariant map from the canonical model
//   Coordinate number 0:
map_0_coord_0 := 2*(134994600000*x*u^7-39093889504*x*u^6*v+109877710992*x*u^5*v^2+234437872477*x*u^4*v^3-1447888423276*x*u^3*v^4+159004263022*x*u^2*v^5+522129490601*x*u*v^6-152450107264*x*v^7+57531060000*y*u^7-296283868092*y*u^6*v+823743263303*y*u^5*v^2+638040660938*y*u^4*v^3-2116419931907*y*u^3*v^4+364725383884*y*u^2*v^5+589991861839*y*u*v^6-157169065128*y*v^7+8*z^8+48*z^7*v+5848*z^6*v^2+23120*z^5*v^3+1445800*z^4*v^4+2868336*z^3*v^5+64631089440*z^2*u^6-264472364956*z^2*u^5*v-157210517513*z^2*u^4*v^2+279276017607*z^2*u^3*v^3+91930934063*z^2*u^2*v^4-40801023656*z^2*u*v^5+131328128*z^2*v^6-40520275552*z*t*u^6-1293593390012*z*t*u^5*v+568798131569*z*t*u^4*v^2+2293356404087*z*t*u^3*v^3-959586048890*z*t*u^2*v^4-525903397632*z*t*u*v^5+193248377320*z*t*v^6-57531060000*z*u^7+304130148924*z*u^6*v-1291955004319*z*u^5*v^2-191524959279*z*u^4*v^3+2755598065213*z*u^3*v^4-835238727548*z*u^2*v^5-549428994864*z*u*v^6+193251188344*z*v^7-7341896160*w^2*u^5*v-220512916080*w^2*u^4*v^2-51728956142*w^2*u^3*v^3+380624282036*w^2*u^2*v^4-77473018063*w^2*u*v^5-31490176088*w^2*v^6+135547776000*w*t*u^6-1108873121760*w*t*u^5*v-997685145652*w*t*u^4*v^2+1957997036879*w*t*u^3*v^3+203938958333*w*t*u^2*v^4-531924707492*w*t*u*v^5+52064834168*w*t*v^6+10484694720*w*u^6*v-27213113460*w*u^5*v^2-190196239625*w*u^4*v^3+227840253479*w*u^3*v^4-156058114881*w*u^2*v^5-16920210915*w*u*v^6+17683698040*w*v^7-106001892000*t^2*u^6-903995013600*t^2*u^5*v+465664092304*t^2*u^4*v^2+1525223781142*t^2*u^3*v^3-619816654786*t^2*u^2*v^4-293970128091*t^2*u*v^5+109869543912*t^2*v^6+20680920000*t*u^7+198878073664*t*u^6*v-1827713879248*t*u^5*v^2+841702078215*t*u^4*v^3+3377547006119*t*u^3*v^4-1801634755547*t*u^2*v^5-461895377709*t*u*v^6+263016164104*t*v^7+12964803840*u^7*v+197611648084*u^6*v^2-568919630469*u^5*v^3-134647590481*u^4*v^4+945957779951*u^3*v^5-367129440272*u^2*v^6-37197671236*u*v^7+28400117792*v^8);
//   Coordinate number 1:
map_0_coord_1 := 1*(5359332*x*u^7+5049212*x*u^6*v-4914980*x*u^5*v^2-3402704*x*u^4*v^3-1578160*x*u^3*v^4-2262288*x*u^2*v^5+1896146*x*u*v^6-1262284*x*v^7+2071984*y*u^7+3820659*y*u^6*v-11322722*y*u^5*v^2-3392996*y*u^4*v^3+1362902*y*u^3*v^4-996390*y*u^2*v^5+465246*y*u*v^6-695636*y*v^7+16*z^6*v^2+64*z^5*v^3-352*z^4*v^4-768*z^3*v^5+2189576*z^2*u^6+5766984*z^2*u^5*v+2701108*z^2*u^4*v^2-3824184*z^2*u^3*v^3+1520762*z^2*u^2*v^4-730564*z^2*u*v^5+5168*z^2*v^6-2001449*z*t*u^6+4836764*z*t*u^5*v+5995308*z*t*u^4*v^2-5217148*z*t*u^3*v^3+8753034*z*t*u^2*v^4-5349424*z*t*u*v^5+1993936*z*t*v^6-2493668*z*u^7-2497873*z*u^6*v+10484990*z*u^5*v^2+8942484*z*u^4*v^3-11971030*z*u^3*v^4+9730358*z*u^2*v^5-5278208*z*u*v^6+1993008*z*v^7+319216*w^2*u^6-809512*w^2*u^5*v+3352704*w^2*u^4*v^2+2640944*w^2*u^3*v^3-169880*w^2*u^2*v^4+1788434*w^2*u*v^5-1024524*w^2*v^6+5339504*w*t*u^6+18939904*w*t*u^5*v+14218594*w*t*u^4*v^2-4633592*w*t*u^3*v^3+1282704*w*t*u^2*v^4+1522220*w*t*u*v^5-1152632*w*t*v^6-193212*w*u^7+951567*w*u^6*v+2805084*w*u^5*v^2-1145068*w*u^4*v^3+5603100*w*u^3*v^4-9667660*w*u^2*v^5+5616710*w*u*v^6-1271308*w*v^7-3918434*t^2*u^6+3453280*t^2*u^5*v+11011358*t^2*u^4*v^2+30716*t^2*u^3*v^3+1703144*t^2*u^2*v^4-870310*t^2*u*v^5+399212*t^2*v^6+517308*t*u^7-14105482*t*u^6*v-3439866*t*u^5*v^2+11975876*t*u^4*v^3+2930996*t*u^3*v^4+392216*t*u^2*v^5-602374*t*u*v^6+1288348*t*v^7+304092*u^8-789072*u^7*v-1931948*u^6*v^2+4313940*u^5*v^3-924720*u^4*v^4+5275380*u^3*v^5-5665528*u^2*v^6+2003424*u*v^7);

// Map from the canonical model to the plane model of modular curve with label 62.96.7.a.1
//   Coordinate number 0:
map_1_coord_0 := 1*(x);
//   Coordinate number 1:
map_1_coord_1 := 1*(y);
//   Coordinate number 2:
map_1_coord_2 := 1*(u);
// Codomain equation:
map_1_codomain := [-x^9-4*x^8*y-6*x^8*z-8*x^7*y^2-23*x^7*y*z-14*x^7*z^2-9*x^6*y^3-33*x^6*y^2*z-46*x^6*y*z^2-12*x^6*z^3-5*x^5*y^4-28*x^5*y^3*z-43*x^5*y^2*z^2-30*x^5*y*z^3-4*x^5*z^4-2*x^4*y^5-x^4*y^4*z-15*x^4*y^3*z^2-8*x^4*y^2*z^3-4*x^4*y*z^4-2*x^3*y^6-5*x^3*y^5*z+7*x^3*y^4*z^2-2*x^3*y^3*z^3-x^2*y^7-x^2*y^6*z-3*x^2*y^5*z^2+4*x^2*y^4*z^3+2*x*y^6*z^2+y^8*z];
