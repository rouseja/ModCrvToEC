
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 62.992.75.a.1


// Group data
level := 62;
// Elements that, together with Gamma(level), generate the group
gens := [[5, 47, 57, 26], [43, 51, 25, 10]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 992;

// Curve data
conductor := [[2, 90], [31, 146]];
bad_primes := [2, 31];
// Genus
g := 75;
// Rank
r := 29
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 16
;// Number of rational cusps
Nrat_cusps := 1
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['2.2.0.a.1', '31.496.30.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["2.2.0.a.1", "31.496.30.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
