
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 63.1134.85.d.1


// Group data
level := 63;
// Elements that, together with Gamma(level), generate the group
gens := [[21, 29, 58, 49], [27, 19, 46, 59]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 1134;

// Curve data
conductor := [[3, 310], [7, 156]];
bad_primes := [3, 7];
// Genus
g := 85;
// Rank
r := 55
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 18
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["21.42.1.b.1", "63.567.40.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
