
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 63.144.11.i.1

// Other names and/or labels
// Cummins-Pauli label: 63A11
// Rouse-Sutherland-Zureick-Brown label: 63.144.11.17

// Group data
level := 63;
// Elements that, together with Gamma(level), generate the group
gens := [[27, 11, 40, 18], [47, 29, 29, 49], [47, 54, 30, 10]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 144;

// Curve data
conductor := [[3, 38], [7, 16]];
bad_primes := [3, 7];
// Genus
g := 11;
// Rank
r := 2
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 4
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["21.48.3.c.1", "63.18.0.d.1", "63.72.6.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r,s,a,b> := PolynomialRing(Rationals(), 11);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x*y+x*r+y*z,x*u-x*b+y*z+z*u,x*z-x*u-x*v-x*a+y*u,x*y+x*z+x*u-x*a+y*u+z*w+z*v-w*s,y*u-z^2+z*u+z*v+z*a+u*r,y^2+y*r+y*b+u*r,x*w+2*x*v+x*b-y*s,y*s+z*w+2*z*v+z*b+r*s,x*z+x*w+x*t-x*v+x*r+x*a-y^2-y*u+y*s-z*u,z*s+w*u+2*u*v-u*s+u*b-v*s-s*a,x*z-y*w-y*v-z^2+2*z*s-w*u,x*z+y*v+y*s+y*b-z^2-w*u-2*w*s-t*s,x*z+x*u-x*r-x*a+y*b-z^2-z*w-z*t-z*u-z*a-w*s,y^2-y*w+2*y*u-w^2-2*w*v-w*r-w*b-v*r,x*u-x*b+2*y*u+y*v+y*a-z*u-2*w*u-t*u,3*x^2+x*z+y^2+y*z-2*y*w-y*t+z^2,x*z-x*v-x*a-x*b-y*z-y*w-y*t-y*u+y*r+y*b+z*u-z*r-2*z*b+w^2+2*w*v-w*r-w*b-t*r-t*b-u*r-r*a,x*u-x*v+x*r-y*w+y*s+y*a+y*b-2*z^2-z*w-z*v+2*w^2+w*t-w*u+w*v+w*s-w*a-t*u-t*a+r*s,y*t+2*y*u-y*v-y*r+y*s-y*b+z*b+w^2+w*t+w*u+w*v+w*r+w*a+w*b+t*v+t*r+t*b+u*r+r*s+r*a,x*y+x*z+x*r+3*x*s-y^2-y*z+y*w-y*u+y*v+y*b-z^2-z*r-z*b+w*u+w*a-w*b-t*v-t*b,3*x*z-2*x*w-x*t-x*u+x*a-y*z+2*y*w+y*t-y*u+y*b-z^2-z*w-z*v-z*r-w^2+w*r+w*s+t*r+u*r,2*x^2+x*y+x*r-x*s+2*y^2-y*z+2*y*w-2*y*t-y*u-y*a-2*z*w-z*t+z*u+z*r+w^2+w*u-w*r-t*r-u^2-u*a-s^2,x*y-x*z+3*x*w-4*x*t+x*u+2*x*r-x*a-x*b+2*y^2-3*y*z+2*y*w+y*t+y*u-y*r-z^2+z*u-z*r-w^2+w*r+t*r+u*s,2*x*w-4*x*t+x*u+x*r+x*a+y^2-y*z-2*y*w-y*t+y*u-2*y*b+z^2-z*w-z*v+3*z*r+z*a+z*b+2*w^2+2*w*b-t*r+t*b+u^2+u*r+u*s+v*r-r*s+r*a,x*y-x*z+2*x*w+x*t-x*u-2*x*v-x*a+x*b+y*t-y*u-y*v+y*r+2*y*s+y*b+z^2-z*w+z*u-z*v+2*z*s-w^2-3*w*t-w*u+w*v-w*r-w*s-w*a-t^2-t*r-t*s-t*a-u*r+r*s,4*y^2-y*u-y*r-y*b-5*w^2+w*v-u^2-u*r+v^2,x^2-x*y-2*x*z+2*x*w+x*t-x*u+2*x*r+x*s-x*a-x*b-y*z+y*w+3*y*t-y*u-y*v-y*s-y*a-z^2+z*w+z*r-z*a-3*w^2+3*w*t-w*s+w*a+t^2+t*u+t*a-u^2-u*v+v^2-r*s+s^2,x^2-x*y-x*z+2*x*r+x*s-y^2-y*z+y*w+3*y*t-y*u-y*r+y*s+y*b+z^2-z*r-2*z*b-w^2-w*t+w*v-w*b+t^2-t*b+u^2-u*r-2*u*s+u*a-v^2-v*s-v*a+r*s-r*a+s^2-s*a+s*b-a*b,x^2+2*x*y+2*x*z-2*x*w+x*t+x*v-x*r+x*s-x*a-x*b-2*y*z-2*y*w+y*t+y*v+y*b+z^2-z*w+2*z*t+2*z*u+z*v+z*r+w^2+2*w*t-w*u-2*w*v+w*s-w*a-w*b+2*t^2-t*v-t*b+u^2-u*r-2*u*s+u*a-v^2-v*a+r*s-r*a+s^2-s*a+s*b-a*b,4*x^2-x*y+x*z+x*s+x*a+2*x*b-y^2+2*y*z+3*y*w+y*u+3*y*r+y*s+y*a-y*b+z*w+z*t-z*u-z*v-z*r-z*s+w*t-w*v+w*s-w*a-w*b+t*r-t*a+u^2-2*u*r+u*s+u*a-v*r+v*s+r*s+s^2+s*a,2*x*z+x*v+x*r+2*x*a+y*w-2*y*t+y*u+y*v+y*r-2*y*b-z^2-z*w-2*z*v-2*z*r-z*s-z*a+z*b+2*w^2+w*u-w*v+3*w*r+w*s+w*b-2*t*r+t*b+u^2-u*r-u*a+u*b+v^2+v*b+r*a+a*b,3*x^2+x*y+2*x*w+x*t-x*u-x*v-x*b-2*y*z+y*w+3*y*t-y*r+y*b+z^2+z*u+2*z*v+z*r+z*a+3*w^2+w*t+w*r+w*s-2*w*b-t^2+2*t*r-t*b-u^2+u*v+u*s+v^2-v*r+v*a-r*a-s*b,x^2-2*x*y+x*z-2*x*w-x*t+x*s+y*z-y*w+y*u+y*r+y*a+y*b+z^2-2*z*w-z*t-z*u-3*z*r+z*s-2*z*b+w^2+4*w*t-w*u+w*r-2*w*b+t^2+2*t*r-t*b+u*v-u*r+u*a+u*b-v*r-r*a+s^2,3*x^2-x*y-x*z+x*w+x*t-2*x*v+2*x*b+y*z+3*y*w-y*v+2*y*s+y*b+2*z*w-4*z*t-z*v+4*z*r-z*b+w*t-w*v-w*a-w*b+t*r-t*a-u^2-u*v-v*r+v*s+r*s+s*a+s*b,2*x^2+x*y-x*z-x*w-x*t+x*u+x*r-x*s-x*a-y^2-2*y*z-2*y*t-y*v+y*r+y*s+y*b-z*w+2*z*u-z*v+z*r-2*z*s-3*w^2+w*t-w*v+3*w*r-w*s-w*a-2*w*b-t*u-t*r-t*s-t*a-2*u^2+u*r-u*a-v^2-2*v*r-3*v*b+5*r^2+r*s-r*b-s^2-b^2,2*x*y+x*w-2*x*t-x*u-x*v-4*x*r+y^2+y*z-3*y*w+y*t-y*u+y*r+y*a-y*b-z^2-2*z*t-z*v-z*r+z*a-z*b+2*w^2+w*t+2*w*v-3*w*r-w*a+w*b-t*u+t*r-t*a-u^2-u*s-u*a-2*v^2+v*r-2*v*s-2*v*a-v*b-s*a-a^2-a*b];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 63.72.6.a.1
//   Coordinate number 0:
map_0_coord_0 := 1*(x);
//   Coordinate number 1:
map_0_coord_1 := 1*(z);
//   Coordinate number 2:
map_0_coord_2 := 1*(y);
//   Coordinate number 3:
map_0_coord_3 := 1*(w);
//   Coordinate number 4:
map_0_coord_4 := 1*(w+t);
//   Coordinate number 5:
map_0_coord_5 := 1*(r);
// Codomain equation:
map_0_codomain := [x*z+y*z+x*u,2*x*y-x*z-z^2+x*w+x*t,2*y^2-y*z+z^2+y*w+y*t+z*u,3*x^2+x*y+y^2+y*z+z^2-z*w-z*t,2*x*y-y^2+2*x*z-y*z-2*x*w+z*w-w^2-2*x*t+z*t-y*u-z*u+t*u,2*y^2+2*x*z-z^2-y*w+2*z*w-w^2-y*t+2*z*t-2*w*t-t^2-x*u-y*u];
