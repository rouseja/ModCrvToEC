
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 65.140.9.a.1

// Other names and/or labels
// Cummins-Pauli label: 65A9
// Rouse-Sutherland-Zureick-Brown label: 65.140.9.1

// Group data
level := 65;
// Elements that, together with Gamma(level), generate the group
gens := [[17, 31, 24, 58], [22, 11, 14, 43], [36, 49, 23, 19], [56, 37, 63, 49]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 140;

// Curve data
conductor := [[5, 18], [13, 9]];
bad_primes := [5, 13];
// Genus
g := 9;
// Rank
r := 3
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 4
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['5.10.0.a.1', '13.14.0.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["5.10.0.a.1", "13.14.0.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r,s> := PolynomialRing(Rationals(), 9);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x^2-x*z+2*z^2+x*w-w^2+x*t-z*t+x*u+w*r+2*x*s+y*s+v*s-r*s+s^2,x^2+x*z+z^2-2*x*w-z*w-w^2-x*t-z*t-w*u-z*r+2*w*r+t*r+u*r+x*s+v*s,x^2+x*z+2*z^2-x*w-3*z*w+w^2-2*z*t+w*t+x*u-z*u+x*r+x*s+z*s-w*s-t*s,x*y-x*z+2*y*z-3*z^2+x*w-y*w-z*w+w^2+x*t-y*t+z*t+w*t+x*u-z*u+x*s+z*s-w*s-t*s-v*s,x^2+x*y-x*z-2*y*z+z^2-y*w+z*w-x*t-y*t+z*t-x*u-z*u+x*v-w*r-u*r-2*x*s-2*y*s+z*s-w*s-t*s-v*s,x*y-x*z-2*y*z+z^2+2*w^2+2*w*t+x*u-w*u+2*x*r+2*w*r+2*u*r-r^2-2*y*s+u*s-v*s+r*s-s^2,2*x^2-x*y+y*z+z^2-2*x*w-2*z*w+w^2+y*t-2*z*t-2*x*u-y*u+z*u+w*u-x*v-u*v-x*r+z*r-w*r-t*r-x*s+y*s-z*s+w*s+t*s+v*s,2*x^2-x*y+x*z+z^2+x*w+w^2+y*t-2*z*t-w*t-x*u+2*w*u+u^2-u*v-2*x*r+y*r-3*w*r-t*r-u*r-v*r+y*s+u*s-v*s+s^2,x*z-z^2-x*w+z*w+2*w^2-x*t+z*t+w*t+2*w*u+t*u+u^2-z*r+w*r+t*r+u*r+u*s-v*s,2*x*y+y*z-z^2-x*w-y*w-z*w-w^2-x*t-y*t-z*t+w*t+t^2-w*u+x*v-u*r+x*s,2*x*z-x*w-z*w-x*t-z*t+x*u+y*u-z*u-w*u+x*v+z*v-w*v-t*v+x*r+y*r-z*r-w*r-v*r+x*s+u*s+r*s,x*z-z^2+y*w+w^2+w*t+2*x*u+y*u-z*u+x*v+z*v+u*v+2*x*r+x*s-t*s-s^2,2*x^2+2*x*y-2*x*z-z*w-z*t+x*u-z*u-w*u+x*v+z*v-z*s+u*s,x*z-y*z+z^2-y*w+w^2-x*t-y*t+z*t+w*t-w*u+x*r-z*r+w*r+t*r+u*r-x*s-y*s+z*s-2*w*s-t*s+r*s,x^2+2*x*y-2*x*z+y*z-x*w-y*w-z*w+w^2-y*t+w*t+x*u-w*u+x*v+2*x*r+z*s-w*s-t*s+u*s,x*y-2*x*z-y*z+2*x*w+z*w+w^2+x*t+w*t+2*x*u+y*u-2*z*u-w*u+w*v+t*v+u*v+x*r-z*r+w*r+v*r+x*s-y*s+z*s-w*s-t*s+u*s-v*s-r*s,2*x^2+x*y+y*z-2*z^2-y*w-2*z*w-x*t-y*t+z*t-x*u-z*u-w*u+z*v-t*v-u*v-x*r+z*r-w*r-v*r-x*s-w*s+u*s-v*s+r*s+s^2,x*z+z^2-z*w-w^2-z*t+x*u-w*u+x*r+x*s-y*s+2*z*s+w*s+u*s,2*x*z-y*z-x*w+2*z*w-x*t+z*t-y*u+z*u-x*v+z*v-y*r+2*w*r+t*r+u*r+v*r-y*s-u*s-s^2,2*x*z+y*z+z^2-x*w-y*w-y*t+x*u-z*u+w*u-z*v+2*x*r+z*r-u*r+y*s-w*s-t*s-u*s-r*s,x^2-y^2+x*z+z^2+x*w+2*y*w+z*w-x*t+z*t-w*t-x*u+y*u-z*u+x*v+y*v-w*v-t*v-u*v+v^2-z*r-2*w*r-2*u*r+v*r+r^2-x*s+z*s-2*w*s-t*s-v*s-r*s+s^2];

// Maps from this modular curve, if computed
