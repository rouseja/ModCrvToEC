
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 65.1560.113.c.1


// Group data
level := 65;
// Elements that, together with Gamma(level), generate the group
gens := [[40, 23, 46, 25], [54, 17, 36, 26], [58, 32, 54, 3]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 1560;

// Curve data
conductor := [[5, 220], [13, 226]];
bad_primes := [5, 13];
// Genus
g := 113;
// Rank
r := 87
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 24
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["65.780.57.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
