
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 65.546.36.a.1


// Group data
level := 65;
// Elements that, together with Gamma(level), generate the group
gens := [[16, 5, 58, 56], [53, 45, 6, 12], [56, 35, 55, 48], [61, 40, 61, 43]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 546;

// Curve data
conductor := [[5, 30], [13, 67]];
bad_primes := [5, 13];
// Genus
g := 36;
// Rank
r := 16
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 14
;// Number of rational cusps
Nrat_cusps := 2
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['5.6.0.a.1', '13.91.3.b.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["5.6.0.a.1", "13.91.3.b.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
