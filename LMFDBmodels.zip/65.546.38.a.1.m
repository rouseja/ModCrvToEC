
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 65.546.38.a.1


// Group data
level := 65;
// Elements that, together with Gamma(level), generate the group
gens := [[25, 34, 24, 51], [45, 37, 1, 46], [46, 54, 64, 32]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 546;

// Curve data
conductor := [[5, 32], [13, 71]];
bad_primes := [5, 13];
// Genus
g := 38;
// Rank
r := 17
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 14
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['5.6.0.a.1', '13.91.3.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["5.6.0.a.1", "13.91.3.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
