
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 65.910.66.a.1


// Group data
level := 65;
// Elements that, together with Gamma(level), generate the group
gens := [[8, 35, 35, 57], [16, 58, 9, 49], [59, 26, 17, 19], [61, 62, 64, 11]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 910;

// Curve data
conductor := [[5, 126], [13, 123]];
bad_primes := [5, 13];
// Genus
g := 66;
// Rank
r := 60
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 14
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-3, -12, -27, -43];
// Modular curve is a fiber product of the following curvesfactors := ['5.10.0.a.1', '13.91.3.b.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["5.10.0.a.1", "13.91.3.b.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
