
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 66.330.22.b.1

// Other names and/or labels
// Cummins-Pauli label: 66D22
// Rouse-Sutherland-Zureick-Brown label: 66.330.22.5

// Group data
level := 66;
// Elements that, together with Gamma(level), generate the group
gens := [[7, 34, 34, 59], [41, 11, 44, 19], [45, 14, 2, 21], [54, 13, 37, 45]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 330;

// Curve data
conductor := [[2, 30], [3, 42], [11, 44]];
bad_primes := [2, 3, 11];
// Genus
g := 22;
// Rank
r := 7
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 5
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["33.165.7.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
