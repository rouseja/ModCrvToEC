
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 66.330.22.c.1

// Other names and/or labels
// Cummins-Pauli label: 66D22
// Rouse-Sutherland-Zureick-Brown label: 66.330.22.3

// Group data
level := 66;
// Elements that, together with Gamma(level), generate the group
gens := [[3, 20, 61, 63], [5, 13, 2, 59], [21, 53, 31, 0], [64, 45, 33, 2]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 330;

// Curve data
conductor := [[2, 30], [3, 24], [11, 44]];
bad_primes := [2, 3, 11];
// Genus
g := 22;
// Rank
r := 15
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 5
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-3, -4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["33.165.7.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
