
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 66.660.46.b.1


// Group data
level := 66;
// Elements that, together with Gamma(level), generate the group
gens := [[31, 5, 60, 1], [49, 45, 12, 65], [53, 50, 6, 17], [53, 55, 12, 35], [65, 28, 6, 29]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 660;

// Curve data
conductor := [[2, 18], [3, 30], [11, 92]];
bad_primes := [2, 3, 11];
// Genus
g := 46;
// Rank
r := 17
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 20
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-3, -12];
// Modular curve is a fiber product of the following curvesfactors := ['2.3.0.a.1', '3.4.0.a.1', '11.55.1.b.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["6.12.0.a.1", "22.165.8.a.1", "33.220.14.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
