
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 66.660.49.e.1


// Group data
level := 66;
// Elements that, together with Gamma(level), generate the group
gens := [[0, 17, 61, 19], [19, 26, 47, 3], [37, 40, 57, 29]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 660;

// Curve data
conductor := [[2, 36], [3, 90], [11, 98]];
bad_primes := [2, 3, 11];
// Genus
g := 49;
// Rank
r := 28
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 10
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-3];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["66.220.13.f.1", "66.330.25.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
