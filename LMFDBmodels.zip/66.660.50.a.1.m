
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 66.660.50.a.1


// Group data
level := 66;
// Elements that, together with Gamma(level), generate the group
gens := [[23, 59, 56, 21], [25, 28, 31, 63], [63, 50, 23, 3]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 660;

// Curve data
conductor := [[2, 38], [3, 92], [11, 96]];
bad_primes := [2, 3, 11];
// Genus
g := 50;
// Rank
r := 29
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 10
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-3];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["66.220.13.f.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
