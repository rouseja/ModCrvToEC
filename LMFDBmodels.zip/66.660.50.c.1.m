
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 66.660.50.c.1


// Group data
level := 66;
// Elements that, together with Gamma(level), generate the group
gens := [[8, 3, 15, 14], [9, 35, 43, 24], [19, 57, 24, 29], [32, 39, 39, 7]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 660;

// Curve data
conductor := [[2, 60], [3, 66], [11, 94]];
bad_primes := [2, 3, 11];
// Genus
g := 50;
// Rank
r := 23
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 10
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["33.330.20.b.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
