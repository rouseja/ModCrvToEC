
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 66.990.69.b.1


// Group data
level := 66;
// Elements that, together with Gamma(level), generate the group
gens := [[8, 3, 65, 22], [41, 26, 2, 25], [48, 55, 37, 40], [50, 25, 7, 16]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 990;

// Curve data
conductor := [[2, 54], [3, 122], [11, 138]];
bad_primes := [2, 3, 11];
// Genus
g := 69;
// Rank
r := 37
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 15
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["66.18.0.d.1", "66.330.19.b.1", "66.495.32.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
