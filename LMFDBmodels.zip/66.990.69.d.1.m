
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 66.990.69.d.1


// Group data
level := 66;
// Elements that, together with Gamma(level), generate the group
gens := [[5, 44, 58, 17], [15, 16, 26, 51], [19, 25, 58, 23], [65, 57, 24, 31]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 990;

// Curve data
conductor := [[2, 54], [3, 122], [11, 138]];
bad_primes := [2, 3, 11];
// Genus
g := 69;
// Rank
r := 39
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 15
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-4];
// Modular curve is a fiber product of the following curvesfactors := ['6.18.0.d.1', '11.55.1.b.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["6.18.0.d.1", "66.330.19.d.1", "66.495.32.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
