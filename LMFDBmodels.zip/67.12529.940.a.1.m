
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 67.12529.940.a.1

// Other names and/or labels
// Curve name: XS4(67)
// Rouse-Sutherland-Zureick-Brown label: 67.12529.940.1
// Sutherland label: 67S4

// Group data
level := 67;
// Elements that, together with Gamma(level), generate the group
gens := [[26, 31, 5, 35], [63, 24, 10, 6]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 12529;

// Curve data
conductor := [[67, 1865]];
bad_primes := [67];
// Genus
g := 940;
// Rank
r := 506
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 187
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["1.1.0.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
