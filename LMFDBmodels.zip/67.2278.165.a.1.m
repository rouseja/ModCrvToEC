
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 67.2278.165.a.1

// Other names and/or labels
// Curve name: Xsp+(67)
// Rouse-Sutherland-Zureick-Brown label: 67.2278.165.1
// Sutherland label: 67Ns

// Group data
level := 67;
// Elements that, together with Gamma(level), generate the group
gens := [[0, 59, 65, 0], [44, 0, 0, 22]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 2278;

// Curve data
conductor := [[67, 325]];
bad_primes := [67];
// Genus
g := 165;
// Rank
r := 162
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 34
;// Number of rational cusps
Nrat_cusps := 1
;// CM discriminants
CM_discs := [-3, -7, -8, -11, -12, -27, -28, -43];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["1.1.0.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
