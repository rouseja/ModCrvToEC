
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 67.4422.336.b.1

// Other names and/or labels
// Rouse-Sutherland-Zureick-Brown label: 67.4422.336.1
// Sutherland label: 67Nn.2.21

// Group data
level := 67;
// Elements that, together with Gamma(level), generate the group
gens := [[46, 63, 16, 50], [51, 41, 46, 16]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 4422;

// Curve data
conductor := [[67, 667]];
bad_primes := [67];
// Genus
g := 336;
// Rank
r := 237
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 66
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["67.2211.160.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
