
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 68.1088.83.a.1


// Group data
level := 68;
// Elements that, together with Gamma(level), generate the group
gens := [[24, 65, 47, 33], [39, 49, 3, 28], [41, 19, 33, 44], [63, 58, 66, 25]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 1088;

// Curve data
conductor := [[2, 282], [17, 166]];
bad_primes := [2, 17];
// Genus
g := 83;
// Rank
r := 38
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 16
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['4.8.0.a.1', '17.136.6.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["4.8.0.a.1", "34.272.19.a.1", "68.544.38.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
