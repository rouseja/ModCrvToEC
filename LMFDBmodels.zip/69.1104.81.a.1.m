
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 69.1104.81.a.1


// Group data
level := 69;
// Elements that, together with Gamma(level), generate the group
gens := [[11, 3, 39, 35], [26, 17, 60, 65], [37, 18, 27, 35], [37, 27, 18, 55]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 1104;

// Curve data
conductor := [[3, 51], [23, 155]];
bad_primes := [3, 23];
// Genus
g := 81;
// Rank
r := 46
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 24
;// Number of rational cusps
Nrat_cusps := 2
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['3.4.0.a.1', '23.276.15.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["3.4.0.a.1", "23.276.15.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
