
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 69.144.11.b.1

// Other names and/or labels
// Cummins-Pauli label: 69A11
// Rouse-Sutherland-Zureick-Brown label: 69.144.11.1

// Group data
level := 69;
// Elements that, together with Gamma(level), generate the group
gens := [[25, 63, 51, 22], [47, 64, 28, 46], [58, 60, 11, 23], [59, 0, 22, 25]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 144;

// Curve data
conductor := [[3, 11], [23, 11]];
bad_primes := [3, 23];
// Genus
g := 11;
// Rank
r := 2
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 4
;// Number of rational cusps
Nrat_cusps := 4
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['3.6.0.b.1', '23.24.2.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["3.6.0.b.1", "69.72.6.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r,s,a,b> := PolynomialRing(Rationals(), 11);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x^2+x*y+x*s-x*a-x*b+y*s-y*a+s*a-s*b,x*z-2*x*w+2*x*t+x*u-2*x*v+x*s-x*a+x*b-2*y*w+y*t+y*u-2*y*v+y*s+a*b-b^2,x*y+x*z+2*x*t+x*u-x*v-x*r-x*a+y*z-y*w+y*t+y*u-y*v-2*y*r-y*s-y*a-z*u+r*b+s*a-s*b+b^2,x^2+x*y-x*z+x*w+2*x*t+y*t-y*r-y*s-z*u+r*a+s*a-s*b+a*b,x*z-2*x*w-x*v-x*r+y^2-y*w-y*v+y*r+y*s+y*a+z*u+u*b-r*b-s*a+s*b-b^2,x*w+x*t-x*r-x*s+y*z-y*r-y*s-z*u+t*s+u*b+r*a-r*b+a*b,x^2+x*y-x*z+x*w-x*t+x*v+x*r+y*w-y*t+y*v-w*t+t*b-u*b-r*a-a*b+b^2,x*y+x*w-x*u+x*v-x*r-x*b+y*w-y*u+y*v+y*s-y*a+w*t+t*s-t*b+u*b+a^2-a*b,x*y+x*w-x*t+x*v-x*s-x*b-y*t+y*v-y*s-z*t-z*u+t*s-t*b-r*s+r*a,x*t+x*u-x*r-x*b+y*z+y*t+y*u-y*r-2*y*a+z*t+w*t+w*s+r*s+s*a+a*b-b^2,x*w-x*t-x*u+y^2+2*y*w-2*y*u+y*r-t*s-r^2-r*b-2*a*b+b^2,x^2+x*y-x*z+x*r+x*a-y*z+y*u+y*r+y*s+z*u+v*b+r^2+r*s-r*a+a*b-b^2,x^2+x*y-x*z+x*v+x*a-x*b+y*u-u*b-v*a+v*b+s*a-s*b,x*w-x*a+x*b-y*a+w*s-u*a+s*b-a*b,x*z+x*t-x*v-x*r+x*b-y*w+y*t+y*u-y*v-y*r-y*s+y*a-t*s-u*s+u*b+v*s+r^2+r*b,x*y+x*t-x*v+x*s-x*a+y^2-y*w+y*u-y*v+y*a-z*t-w*t-u*s-r*s-a*b,x^2+x*z-x*w-x*t-x*v+x*s-x*b-y*u+y*r+y*s+z*t+z*u-t*s-t*a+v*a-b^2,x*y+2*x*z-x*v-x*r-x*a-y*u-y*r-w*u-u*r-a*b+b^2,x^2-x*z-x*t+x*v+x*a-x*b+y*z+y*w-y*t+y*v+z*t+z*u-w*t-t*r-t*s-u*b-r*a-a*b,x*y+y^2-y*z+y*t+y*r+y*s-y*a+w*t+w*s+t*u+u*b+r*s-r*b+s*b-b^2,x^2-x*z+x*w+x*v-x*r-x*s+x*a-x*b+y*z+y*w+y*v-y*r-y*s+z*t+w*b+t*b+b^2,x^2+x*y-x*z+x*r-y*z+y*r+y*s+z*b-r*b-b^2,x*y-x*a+y*s-y*a+z*a-r*a-a*b,x*z-x*w-x*v+x*s-x*a-y*w-y*v+y*s-y*b,x^2+x*s-x*a-y^2+y*s+z*t-w*t-t^2+t*r+t*s+a*b,x*w-x*t+x*v-x*s+x*a-y^2+y*w-y*t+y*v-y*s-z*u-t^2+t*v-t*b-u*b+v*b,x*w+x*r+x*b-y*a+w*s-w*a+r*s-r*a+s*b-a*b,x*y+x*w+x*t-x*s+x*b+y*t-y*r-y*s-z*u+z*s-t*s-a*b,x*y+x*r-y*w+y*u-z*r+r^2+r*b,x^2+x*y+x*w+x*r+x*b-z*w,x^2-x*u+x*r+x*s-y*w+y*a-w*r-w*s-r*s+r*a-s*b+a*b,x^2+x*z-x*t-x*r-x*b+y*w-y*u+y*v+z*v-t*s-a*b,x*w+x*t-x*r-x*b+y*z+y*v-y*r+z*t+z*u-w^2-w*r+t*s+t*b+u*b-v*s+b^2,x*w-x*u+x*v-x*r-x*s+x*b+y^2+y*z-y*r-y*s+w*u-w*s+u*b+v*r+v*b-s*b+b^2,x*z-x*t+x*r+x*s-x*a+x*b-y*z-y*t+y*r+y*s-z^2+z*r+t*s+a*b,x^2-x*z+x*w-x*u+x*v-x*r+x*b+y*w-y*u-y*r-z*u+w*u-w*v+w*r-u^2+u*v];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 69.72.6.a.1
//   Coordinate number 0:
map_0_coord_0 := 1*(x);
//   Coordinate number 1:
map_0_coord_1 := 1*(-y);
//   Coordinate number 2:
map_0_coord_2 := 1*(t-r);
//   Coordinate number 3:
map_0_coord_3 := 1*(-z+w+t-2*u+r);
//   Coordinate number 4:
map_0_coord_4 := 1*(y+z-w+u-v-s);
//   Coordinate number 5:
map_0_coord_5 := 1*(-z+w+t-u+r+b);
// Codomain equation:
map_0_codomain := [2*x^2-y^2+z*w-z*u+t*u,2*x*z+x*t-y*t+w*u-2*u^2,x^2-x*y+2*y^2-z*w+2*z*u,z^2-x*w-y*w+z*t+3*x*u+y*u,z^2+x*w-y*w-2*x*u+3*y*u,3*x*z-2*y*z+w^2+x*t-2*y*t-3*w*u+2*u^2];
