
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 69.1518.104.a.1


// Group data
level := 69;
// Elements that, together with Gamma(level), generate the group
gens := [[8, 26, 38, 61], [26, 5, 49, 2], [52, 10, 2, 40]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 1518;

// Curve data
conductor := [[3, 109], [23, 203]];
bad_primes := [3, 23];
// Genus
g := 104;
// Rank
r := 68
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 22
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["69.759.49.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
