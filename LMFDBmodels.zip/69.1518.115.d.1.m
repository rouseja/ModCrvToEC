
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 69.1518.115.d.1


// Group data
level := 69;
// Elements that, together with Gamma(level), generate the group
gens := [[27, 17, 58, 42], [55, 38, 55, 52], [67, 31, 37, 2]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 1518;

// Curve data
conductor := [[3, 204], [23, 224]];
bad_primes := [3, 23];
// Genus
g := 115;
// Rank
r := 84
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 22
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["69.506.31.b.1", "69.759.49.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
