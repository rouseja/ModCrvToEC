
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 69.1656.127.a.1


// Group data
level := 69;
// Elements that, together with Gamma(level), generate the group
gens := [[10, 9, 48, 32], [14, 18, 27, 35], [26, 23, 46, 26], [29, 39, 24, 40]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 1656;

// Curve data
conductor := [[3, 184], [23, 242]];
bad_primes := [3, 23];
// Genus
g := 127;
// Rank
r := 55
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 24
;// Number of rational cusps
Nrat_cusps := 2
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['3.3.0.a.1', '23.552.35.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["23.552.35.a.1", "69.72.6.a.1", "69.828.55.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
