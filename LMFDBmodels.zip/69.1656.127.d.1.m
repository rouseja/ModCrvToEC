
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 69.1656.127.d.1


// Group data
level := 69;
// Elements that, together with Gamma(level), generate the group
gens := [[19, 23, 26, 50], [46, 47, 13, 28], [66, 19, 40, 0]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 1656;

// Curve data
conductor := [[3, 224], [23, 242]];
bad_primes := [3, 23];
// Genus
g := 127;
// Rank
r := 88
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 24
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["69.552.35.b.1", "69.828.55.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
