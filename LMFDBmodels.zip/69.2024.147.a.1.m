
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 69.2024.147.a.1


// Group data
level := 69;
// Elements that, together with Gamma(level), generate the group
gens := [[28, 44, 54, 56], [41, 14, 36, 52], [55, 15, 9, 52]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 2024;

// Curve data
conductor := [[3, 85], [23, 294]];
bad_primes := [3, 23];
// Genus
g := 147;
// Rank
r := 61
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 44
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['3.4.0.a.1', '23.506.31.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["23.506.31.a.1", "69.1012.74.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
