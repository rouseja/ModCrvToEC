
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 69.4554.340.d.1


// Group data
level := 69;
// Elements that, together with Gamma(level), generate the group
gens := [[26, 51, 61, 43], [61, 8, 39, 5], [61, 22, 58, 54]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 4554;

// Curve data
conductor := [[3, 371], [23, 669]];
bad_primes := [3, 23];
// Genus
g := 340;
// Rank
r := 177
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 66
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["69.1518.110.d.1", "69.2277.163.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
