
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 69.96.7.a.1

// Other names and/or labels
// Curve name: X0(69)
// Cummins-Pauli label: 69A7
// Rouse-Sutherland-Zureick-Brown label: 69.96.7.1

// Group data
level := 69;
// Elements that, together with Gamma(level), generate the group
gens := [[17, 23, 0, 47], [34, 64, 0, 44], [50, 15, 0, 62], [59, 67, 0, 5]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 96;

// Curve data
conductor := [[3, 3], [23, 7]];
bad_primes := [3, 23];
// Genus
g := 7;
// Rank
r := 0
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 4
;// Number of rational cusps
Nrat_cusps := 4
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['3.4.0.a.1', '23.24.2.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["3.4.0.a.1", "23.24.2.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v> := PolynomialRing(Rationals(), 7);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x*y+x*z+y*u,y^2-y*u+z*v,x*y-x*u-x*v-u*v,x^2-x*y-x*w+z*u,y*w+w^2+y*u+x*v-w*v-u*v,x^2+y*z+z*w-y*u-z*v,x*w+z*w+x*u-y*u+y*v+w*v+u*v,x*y-y^2-y*z-z^2-y*w,x^2-x*y-y^2-y*w+x*v+y*v,x*z+y*z+x*t+3*y*t+2*z*t+2*w*t+t^2-t*u-3*t*v];

// Maps from this modular curve, if computed

// j-invariant map from the canonical model
//   Coordinate number 0:
map_0_coord_0 := 1*(-581073552*t^3*u^5+5196833349*w^2*u^6+1835906544*y*t*u^6+1721080656*z*t*u^6+547863552*w*t*u^6+1140007104*t^2*u^6-2927126385*x*u^7+592143559*y*u^7-2302535583*z*u^7+6*w*u^7-706969440*t*u^7-u^8-2253650400*t^3*u^4*v+24611184985*w^2*u^5*v+9285529968*y*t*u^5*v+9565186896*z*t*u^5*v+3991145904*w*t*u^5*v+7700294160*t^2*u^5*v-10493829609*x*u^6*v+3436594177*y*u^6*v-5261061431*z*u^6*v-7499368157*w*u^6*v-5254327872*t*u^6*v-8123959761*u^7*v-989203536*t^3*u^3*v^2+27462226334*w^2*u^4*v^2+3791604384*y*t*u^4*v^2+12312743184*z*t*u^4*v^2+3658827456*w*t*u^4*v^2+12897705456*t^2*u^4*v^2+3765952101*x*u^5*v^2+13859713065*y*u^5*v^2+17063337654*z*u^5*v^2-31467420986*w*u^5*v^2-13907455056*t*u^5*v^2-39677260887*u^6*v^2+2708478288*t^3*u^2*v^3-16595359552*w^2*u^3*v^3+4509448704*y*t*u^3*v^3+2007614016*z*t*u^3*v^3+4647693312*w*t*u^3*v^3+2323225296*t^2*u^3*v^3+26692863101*x*u^4*v^3+23700913750*y*u^4*v^3+48836355723*z*u^4*v^3-24696898772*w*u^4*v^3-17268405120*t*u^4*v^3-44428593863*u^5*v^3+607770288*t^3*u*v^4-25096501136*w^2*u^2*v^4-9654156144*y*t*u^2*v^4-16826908608*z*t*u^2*v^4-12436647264*w*t*u^2*v^4-17808864768*t^2*u^2*v^4+2865586799*x*u^3*v^4+1321348524*y*u^3*v^4-4643643480*z*u^3*v^4+33456898870*w*u^3*v^4-11141029008*t*u^3*v^4+20319336462*u^4*v^4+649366416*t^3*v^5-10428322660*w^2*u*v^5-4311030960*y*t*u*v^5-5345551584*z*t*u*v^5-6437968992*w*t*u*v^5-6068912832*t^2*u*v^5-4161616257*x*u^2*v^5-25041785079*y*u^2*v^5-37619952765*z*u^2*v^5+16811604895*w*u^2*v^5+26792613360*t*u^2*v^5+50757895920*u^3*v^5-4632186606*w^2*v^6-2392206912*y*t*v^6-3896198496*z*t*v^6-2392206912*w*t*v^6-3896198496*t^2*v^6-1136816217*x*u*v^6-11797691478*y*u*v^6-15975050644*z*u*v^6+10862364880*w*u*v^6+9012273840*t*u*v^6+17239538048*u^2*v^6-2119786725*x*v^7-4955954853*y*v^7-7805969477*z*v^7+2272013943*w*v^7+6288405408*t*v^7+10044842016*u*v^7-1332323001*v^8);
//   Coordinate number 1:
map_0_coord_1 := 1*(-3280*t^3*u^5+39247*w^2*u^6+26240*y*t*u^6+16400*z*t*u^6+13120*w*t*u^6+13120*t^2*u^6-9953*x*u^7-19567*z*u^7-9840*t*u^7-54725*t^3*u^4*v+642567*w^2*u^5*v+221325*y*t*u^5*v+208027*z*t*u^5*v+84423*w*t*u^5*v+169702*t^2*u^5*v-187811*x*u^6*v+166037*y*u^6*v-242733*z*u^6*v-58813*w*u^6*v-128097*t*u^6*v-49200*u^7*v-224400*t^3*u^3*v^2+2931568*w^2*u^4*v^2+754683*y*t*u^4*v^2+1018402*z*t*u^4*v^2+257267*w*t*u^4*v^2+848905*t^2*u^4*v^2-656643*x*u^5*v^2+849988*y*u^5*v^2-843332*z*u^5*v^2-895126*w*u^5*v^2-597410*t*u^5*v^2-879244*u^6*v^2-264647*t^3*u^2*v^3+5120061*w^2*u^3*v^3+1423270*y*t*u^3*v^3+2244646*z*t*u^3*v^3+781043*w*t*u^3*v^3+1972649*t^2*u^3*v^3+439172*x*u^4*v^3+2091213*y*u^4*v^3+562362*z*u^4*v^3-3942739*w*u^4*v^3-1603083*t*u^4*v^3-4279374*u^5*v^3-85385*t^3*u*v^4+3740959*w^2*u^2*v^4+1075028*y*t*u^2*v^4+1972375*z*t*u^2*v^4+874663*w*t*u^2*v^4+1813023*t^2*u^2*v^4+2985487*x*u^3*v^4+3871768*y*u^3*v^4+4347715*z*u^3*v^4-5836073*w*u^3*v^4-3122640*t*u^3*v^4-7759754*u^4*v^4-6264*t^3*v^5+991152*w^2*u*v^5+352882*y*t*u*v^5+611214*z*t*u*v^5+317226*w*t*u*v^5+544792*t^2*u*v^5+2944346*x*u^2*v^5+3554234*y*u^2*v^5+4649797*z*u^2*v^5-3380857*w*u^2*v^5-2816662*t*u^2*v^5-5824946*u^3*v^5+16814*w^2*v^6+18792*y*t*v^6+37584*z*t*v^6+18792*w*t*v^6+37584*t^2*v^6+820837*x*u*v^6+1136796*y*u*v^6+1514201*z*u*v^6-685786*w*u*v^6-847122*t*u*v^6-1599693*u^2*v^6-41179*x*v^7+72107*y*v^7+42231*z*v^7+20409*w*v^7-56376*t*v^7-72468*u*v^7);
