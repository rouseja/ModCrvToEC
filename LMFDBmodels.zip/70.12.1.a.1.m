
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 70.12.1.a.1

// Other names and/or labels
// Cummins-Pauli label: 10A1
// Rouse-Sutherland-Zureick-Brown label: 70.12.1.1

// Group data
level := 70;
// Elements that, together with Gamma(level), generate the group
gens := [[21, 9, 4, 35], [23, 33, 47, 18], [41, 45, 56, 29]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 12;

// Curve data
conductor := [[2, 2], [5, 1], [7, 2]];
bad_primes := [2, 5, 7];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 2
;// Number of rational cusps
Nrat_cusps := 2
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['5.6.0.a.1', '14.2.0.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["5.6.0.a.1", "14.2.0.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z> := PolynomialRing(Rationals(), 3);
// Isomorphic to P^1?
is_P1 := false;

// Weierstrass model
model_0 := [x^3-x^2*z-y^2*z-1780*x*z^2+44472*z^3];

// Maps from this modular curve, if computed

// j-invariant map from the Weierstrass model
//   Coordinate number 0:
map_0_coord_0 := -1*(98*x^2*y^2+2401*x^2*z^2+4557*x*y^2*z-29167348*x*z^3+y^4-19747*y^2*z^2-1479073624*z^4);
//   Coordinate number 1:
map_0_coord_1 := 7^5*(z^3*(x+51*z));
