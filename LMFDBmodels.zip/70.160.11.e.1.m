
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 70.160.11.e.1

// Other names and/or labels
// Cummins-Pauli label: 70B11
// Rouse-Sutherland-Zureick-Brown label: 70.160.11.7

// Group data
level := 70;
// Elements that, together with Gamma(level), generate the group
gens := [[58, 57, 69, 7], [61, 64, 14, 39], [62, 21, 53, 3], [65, 8, 3, 11]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 160;

// Curve data
conductor := [[2, 12], [5, 22], [7, 17]];
bad_primes := [2, 5, 7];
// Genus
g := 11;
// Rank
r := 3
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 4
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["35.80.5.a.1", "70.20.0.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r,s,a,b> := PolynomialRing(Rationals(), 11);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [t*s-v*b,x*b+y*s+z*b,v^2+v*r+v*a+r*s-s^2,x*b-z*v-z*r-z*a-u*s,x*t+z*r-z*s-u*v,x*t+y*v+z*t,t*v+t*r+t*a+r*b-s*b,x*v-2*z*v-w*s,x*v+x*s-x*a+z*t+z*b,y*r-y*s+z*v+t*u+u*v-u*r+u*s,x*t-y*t-y*v-y*r+y*s-z*t-t*u,x*t+x*b-y*s-y*b+z*r-z*b+u*r+u*s+u*a,x*b+y*v+y*r-y*s+y*a-y*b-z*b-u*b,x*t-2*z*t-w*b,2*x*v+x*r-x*s+z*t,x*s-y*t-z*t-z*r-z*s+w*v-w*s-u*v-u*r+u*s,x*t+x*r-x*s-z*r+z*s+w*v+w*r+w*a-u*v,x*t+x*r+x*a-y*t+y*s+y*a-y*b-z*v-w*r+w*b+2*u*r-u*b,x*r+x*a+y*t+y*r-z*b+w*t-w*r-t*u+u*v+u*r+u*s,x*y+2*x*z+x*u-y*z,2*x*y-x*z-3*x*u-y^2+y*u-z^2-z*u+u^2,x^2+x*y-2*x*z-x*w+x*u-y*z+y*w+4*z^2+z*w+w^2-3*w*u,7*y*w+t*v,7*x*w+7*z*w-v^2,t*v-4*t*b+2*v^2-3*v*r-3*v*s-2*v*a+v*b-3*r^2+4*r*s-3*r*a+r*b+s^2+s*a,7*x^2-2*x*y-2*x*z-y^2-3*y*z+y*u-z^2+6*z*u+t*b+u^2-v^2+v*s+r^2-r*s+r*a,3*x^2-3*x*y+3*x*z+4*x*w-3*x*u+3*y*z+3*y*w+5*z^2+3*z*w-4*w^2-2*w*u-2*t^2-t*v+2*t*r+t*s-4*t*b+v*r-v*s+r^2+r*s-2*r*b+a^2-a*b-b^2,4*x^2+x*z+3*x*w+3*x*u+2*y^2+3*y*z-3*y*w-2*y*u-3*z^2+4*z*w-5*z*u-3*w^2-5*w*u-2*t^2-2*t*v+2*t*r+t*s-5*t*b-2*u^2-3*v*s-v*a+r*s-r*a-2*r*b+s^2+a^2-a*b-b^2,x^2+4*x*y-x*z-x*w-x*u+6*y^2-2*y*z+y*w-6*y*u-4*z^2+z*w-z*u+w^2-3*w*u+t^2+t*v-t*r+4*t*b-6*u^2+v*r+v*a-v*b-r*s+2*r*b-a^2+a*b+b^2,4*x^2-2*x*y-2*x*z+3*x*w+2*x*u-2*y^2-y*z-3*y*w+2*y*u+4*z*w-9*z*u+4*w^2+2*w*u+t^2-t*r+t*b+2*u^2-v*r+v*s+r*a,5*x^2+3*x*y-2*x*z+2*x*w+x*u+y^2+2*y*z-2*y*w-y*u-2*z*w-6*z*u-2*w^2+6*w*u-t^2-t*v+2*t*r+t*s+t*a-t*b-u^2-v^2+v*r+v*s+2*r^2-2*r*s+2*r*a-2*r*b-s*a-s*b+a^2-a*b-b^2,2*x^2-3*x*y-x*z-2*x*w+3*x*u-3*y^2-5*y*z+2*y*w+3*y*u-2*z^2-5*z*w-3*z*u-5*w^2+w*u+t*v-t*r-t*a+3*t*b+3*u^2+2*v*r+v*s+v*a+r^2-r*s+r*b+2*s*b-a^2+a*b+b^2,x^2+5*x*z-x*w+2*x*u-y^2+9*y*z+y*w+y*u+3*z^2+z*w-z*u+w^2-3*w*u+u^2-v*b,7*x*w-7*z*w-7*w*u+t*v+v^2+v*r-v*s,3*x^2+x*y+2*x*z+4*x*w-x*u-6*y^2+4*y*z+3*y*w-y*u-z^2+3*z*w+z*u-4*w^2-2*w*u-t^2-t*a-3*t*b-8*u^2-3*v*s-v*a-r^2+r*s-2*r*a+s^2+s*b,3*x^2-2*x*y+x*z-3*x*w+x*u+2*y^2-2*y*z+3*y*w+12*y*u-4*z*w+2*z*u-4*w^2-2*w*u-t^2+t*v+t*r-9*u^2+v*r-v*s+r^2-r*s+s^2+s*b];

// Singular plane model
model_1 := [2401*x^8*y^2-13720*x^6*y^4+39445*x^6*y^3*z-27440*x^6*y^2*z^2+5145*x^6*y*z^3+11025*x^4*y^6-44100*x^4*y^5*z+51940*x^4*y^4*z^2-13965*x^4*y^3*z^3-2450*x^4*y^2*z^4+1470*x^4*y*z^5-245*x^4*z^6-1575*x^2*y^6*z^2+6125*x^2*y^4*z^4-3500*x^2*y^3*z^5+700*x^2*y^2*z^6+225*y^6*z^4+450*y^5*z^5+75*y^4*z^6-150*y^3*z^7+25*y^2*z^8];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 35.80.5.a.1
//   Coordinate number 0:
map_0_coord_0 := 1*(x);
//   Coordinate number 1:
map_0_coord_1 := 1*(-y);
//   Coordinate number 2:
map_0_coord_2 := 1*(z);
//   Coordinate number 3:
map_0_coord_3 := 1*(y+z-u);
//   Coordinate number 4:
map_0_coord_4 := 1*(w);
// Codomain equation:
map_0_codomain := [2*x*y-3*x*z-y*z+x*w,x*y-y^2+x*z+y*z+z^2-2*x*w-3*y*w+z*w-w^2,x^2-2*x*y-x*z+y*z+4*z^2-x*w-x*t+2*y*t-2*z*t+3*w*t+t^2];

// Map from the canonical model to the plane model of modular curve with label 70.160.11.e.1
//   Coordinate number 0:
map_1_coord_0 := 1*(b);
//   Coordinate number 1:
map_1_coord_1 := 1*(7*x);
//   Coordinate number 2:
map_1_coord_2 := 1*(7*y);
// Codomain equation:
map_1_codomain := [2401*x^8*y^2-13720*x^6*y^4+39445*x^6*y^3*z-27440*x^6*y^2*z^2+5145*x^6*y*z^3+11025*x^4*y^6-44100*x^4*y^5*z+51940*x^4*y^4*z^2-13965*x^4*y^3*z^3-2450*x^4*y^2*z^4+1470*x^4*y*z^5-245*x^4*z^6-1575*x^2*y^6*z^2+6125*x^2*y^4*z^4-3500*x^2*y^3*z^5+700*x^2*y^2*z^6+225*y^6*z^4+450*y^5*z^5+75*y^4*z^6-150*y^3*z^7+25*y^2*z^8];
