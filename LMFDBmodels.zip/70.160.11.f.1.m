
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 70.160.11.f.1

// Other names and/or labels
// Cummins-Pauli label: 70B11
// Rouse-Sutherland-Zureick-Brown label: 70.160.11.8

// Group data
level := 70;
// Elements that, together with Gamma(level), generate the group
gens := [[9, 9, 17, 18], [38, 5, 23, 47], [63, 59, 57, 52], [68, 47, 21, 60]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 160;

// Curve data
conductor := [[2, 12], [5, 22], [7, 17]];
bad_primes := [2, 5, 7];
// Genus
g := 11;
// Rank
r := 1
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 4
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["35.80.5.a.1", "70.20.0.b.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r,s,a,b> := PolynomialRing(Rationals(), 11);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x*v-y*u-y*v+z*u-t*u+t*r,x*v+y*u+y*v+y*r+z*v,u^2+u*r-2*u*a-u*b+v*r-v*a,x*u-2*z*u+w*u-w*r+w*a,x*v-y*u+y*r+z*u-z*r-t*v-t*r,y*u-y*r+2*z*u-z*r-t*u,2*u^2-u*v-2*u*r+u*s-u*a+v*r-v*a+r^2-r*a,x*u+x*v+x*r-2*x*a-x*b+y*a+y*b+z*v+z*a+t*s+t*b,x*u-x*v+x*a+x*b-y*u+y*r-y*a-y*b-z*v+z*a+w*r-w*a-t*r-t*s-t*b,x*u+x*v-x*r+z*u+w*v+w*r-w*s-w*b-t*u-t*v-t*r,x*v+y*u-y*b+z*r+z*s-2*z*a+2*t*u+t*s-t*a,2*x*u-x*r+x*a+y*v+y*b-z*u+z*v-z*s-w*u-t*s+t*a,2*x*v-x*s-x*a-2*x*b-z*a-w*u+w*a-t*s,x*v-2*z*v+w*u+w*v+w*r-2*w*a-w*b,2*x*v-y*v+y*s+y*b+z*s-z*a+z*b+t*a,y*s-y*a-z*s-z*a-z*b-t*u-t*v-t*r-2*t*s+t*a-t*b,x*y+2*x*z+x*t-y*z,x*u+x*r-x*s-x*b+y*v+y*a+2*y*b+z*v+z*s-z*a+w*u+w*v+w*s-w*a-t*v+t*a+t*b,2*x*r+2*x*b+y*u-2*y*r-z*r+z*b-w*u+t*u,u^2+u*v-2*u*a-u*b-v^2-2*v*r+v*s+v*b-r^2+2*r*a+r*b,2*x*y-x*z-3*x*t-y^2+y*t-z^2-z*t+t^2,x^2+x*y-2*x*z-x*w+x*t-y*z+y*w+4*z^2+z*w+w^2-3*w*t,2*u^2+3*u*v+u*r+5*u*s+2*u*b+v^2+2*v*s-v*a-r^2-r*s+r*a-s*b,2*u^2+2*u*v+2*u*s+3*u*a+u*b+v^2-2*v*s-2*v*a-4*v*b-2*r^2-2*r*s+3*r*a+r*b+s^2+3*s*a+4*s*b-3*a^2-3*a*b+3*b^2,x^2+x*y-2*x*z-x*w+x*t-y*z+8*y*w+4*z^2-6*z*w+w^2+11*w*t+u*s-u*a+v*s+v*b+r*a+r*b,x^2-3*x*y-4*x*z-x*w+3*x*t+11*y^2-5*y*z+y*w-4*y*t-6*z^2+z*w-10*z*t+w^2-3*w*t+3*t^2-u*v-u*a+v*r+v*a+v*b+r^2-r*a-r*b-s*a-s*b+a^2+a*b-b^2,4*x*y-7*x*z+3*x*t+11*y^2-5*y*z+10*y*t-10*z^2+4*z*t-4*t^2+u*v+u*r-v*r+v*a-r^2+r*a,x*y-6*x*z+7*x*t-10*y^2-2*y*z+10*y*t-3*z^2+11*z*t+10*t^2-u*r+u*s+u*a+u*b-v*r-v*a-v*b-r^2+r*a+r*b+s*a+s*b-a^2-a*b+b^2,x^2+x*y-2*x*z-x*w+x*t-y*z-13*y*w+4*z^2+15*z*w+w^2+4*w*t-u^2-2*u*v-u*r-v^2-v*r,13*x^2-2*x*y-x*z-13*x*w+4*x*t-10*y^2+y*z-y*w-11*y*t-7*z^2-8*z*w-3*z*t+13*w^2+3*w*t+3*t^2-2*u^2-u*v+2*u*r-u*s+v*r+v*s+v*b+r^2+r*s-r*a+s*b,5*x^2+2*x*z-5*x*w-6*x*t+10*y^2+y*z+12*y*w-3*y*t-5*z^2-2*z*w+17*z*t+5*w^2-w*t+4*t^2-2*u^2+2*u*r+2*u*s-u*a+2*u*b+2*v*s+v*a+2*v*b-r*b-s*a-s*b+a^2+a*b-b^2,2*x^2+2*x*y-4*x*z-2*x*w+2*x*t-2*y*z-12*y*w+8*z^2-19*z*w+2*w^2+w*t+u^2+u*v+u*r+u*s-u*a+v*s+v*b+r*a+r*b,6*x*y+6*x*z+17*y^2+16*y*z+11*y*t+3*z^2+3*z*t+4*t^2-u^2-u*v+u*r-2*u*a+v*r+v*a+v*b+r^2-r*a-r*b-s*a-s*b+a^2+a*b-b^2,14*x^2-x*y-3*x*z-14*x*w+5*x*t-10*y^2-11*y*t-3*z^2-7*z*w-3*z*t-21*w^2+3*t^2+u^2-u*r-3*u*s+u*a-2*u*b+v*r-3*v*s-v*a-2*v*b-r*a-s*b,14*x^2-x*y-3*x*z+21*x*w+5*x*t-10*y^2-11*y*t-3*z^2-7*z*w-3*z*t+14*w^2+3*t^2-u^2+2*u*r-u*a+2*v*s+2*v*b+r*s+r*b+s*b,x^2-14*x*y+2*x*z-x*w-8*x*t+4*y^2-15*y*z+y*w+17*y*t+z^2+z*w+4*z*t+w^2-3*w*t+3*t^2-u^2-u*v+u*r-2*u*a+v*r-v*s+v*a-r*s+2*r*a-r*b+s^2-s*a+s*b];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 35.80.5.a.1
//   Coordinate number 0:
map_0_coord_0 := 1*(x);
//   Coordinate number 1:
map_0_coord_1 := 1*(-y);
//   Coordinate number 2:
map_0_coord_2 := 1*(z);
//   Coordinate number 3:
map_0_coord_3 := 1*(y+z-t);
//   Coordinate number 4:
map_0_coord_4 := 1*(w);
// Codomain equation:
map_0_codomain := [2*x*y-3*x*z-y*z+x*w,x*y-y^2+x*z+y*z+z^2-2*x*w-3*y*w+z*w-w^2,x^2-2*x*y-x*z+y*z+4*z^2-x*w-x*t+2*y*t-2*z*t+3*w*t+t^2];
