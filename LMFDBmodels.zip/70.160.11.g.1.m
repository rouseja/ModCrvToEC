
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 70.160.11.g.1

// Other names and/or labels
// Cummins-Pauli label: 70B11
// Rouse-Sutherland-Zureick-Brown label: 70.160.11.2

// Group data
level := 70;
// Elements that, together with Gamma(level), generate the group
gens := [[6, 15, 27, 4], [7, 13, 38, 53], [24, 57, 1, 31], [39, 3, 23, 10]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 160;

// Curve data
conductor := [[2, 12], [5, 22], [7, 11]];
bad_primes := [2, 5, 7];
// Genus
g := 11;
// Rank
r := 4
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 4
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['7.8.0.a.1', '10.20.0.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["10.20.0.a.1", "35.80.5.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r,s,a,b> := PolynomialRing(Rationals(), 11);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [y*t+u*r,x*t+w*t+r^2,x*u-y*r+w*u,z*u+z*r+u*s-r^2-r*a,x*u+2*z*w+w*s+v*r,x*t-y*t-z*u+z*r-w*t-t*v-u*s+r*s+r*a,x*s+2*x*a+y*z-y*a+z*w-z*v-v*s-v*b,2*z^2+3*z*s-r^2-r*b+s^2,2*x^2-2*x*w+y^2-y*v+z^2+z*s-v^2+r*s+r*a,2*x*y+y^2+2*y*v+z*u-u*a+u*b,x*z-x*u+x*s-x*a-x*b+y*u+y*a+z*w+z*v+w*s+u*v+v*r+v*s+v*b,x*r+x*s-x*b+y*a-z*w+w*b+u*v-v*r+v*s+v*b,x*u-y*z-y*u-z*w+z*v-w*s-w*a+w*b-u*v-v*r+v*s,x*z-x*r-x*a-z*v-w*r-w*b-v*s,x*r+x*s-x*b+z*w-w*u-w*r-w*a,y*r+y*b-z*w-2*z*v-w*s-v*s+v*a-v*b,x*s-x*b+z*w+z*t-w*u+w*r-w*a+t*s,x*u+x*r-y*u-y*b-z*w+w*r+t*s+t*a-t*b-v*a+v*b,x*a-y*u-z*v-w*r+w*s+w*b-t*r+v*r,x*u+z*t-2*w*u-t*r-t*a,x*z+2*x*s+x*a-x*b-y*z-y*s,x*r+x*s-y*z-y*u+z*t-w*u-t*u+u*v+v*r+v*s,x^2-x*w+z*r-2*w^2+r*s,x*y+2*x*w+x*v-y*w,2*x*w+x*v+y*w-z*u-u*s,x^2-x*y-x*w-z^2+z*u-z*r-z*s+z*b+w*v-u*r-u*a+r^2-r*s,y^2-y*w-y*v+z^2+z*s-2*w*v-v^2-r^2+r*s+r*a-r*b,x^2+2*x*y-x*w-x*t-y^2+z*b+w*t-w*v+t*v-u*r-v^2+r^2+s*b,x^2+2*x*w-x*v-2*y^2+y*t-y*v-z^2-z*s+z*b-w^2-u*b+v^2-r*s-r*a,x*y-x*v-y^2-y*w+z^2+w*t+t^2-t*v-u^2-u*r-u*s-u*b-v^2+r*s,x^2-x*v+y^2-y*v-z^2+z*r-w*t+2*w*v-t^2+t*v+u^2+u*s-v^2,x*s+x*a+x*b+y*u+2*z*t-z*v-w*s-w*b-t*a-u*v-v*r,x*y+2*y^2+y*w+y*t-y*v+z^2+z*u-z*r+z*s-z*a-u*a+u*b-r*s-s*a,2*x^2-x*y+x*v-y^2-y*t+2*z^2-z*u+z*s-z*a+u*r+u*a-v^2-r^2+r*s,2*x*t-y*t+2*z^2+z*u-z*r+z*s-w*t+t*v-u^2+u*r+r*a+r*b,2*x*w+y*t-2*z^2-z*s+z*b+w^2+w*t+t^2-t*v-u*r+u*s+u*a-u*b-r*s-r*b+a^2-a*b-b^2];

// Singular plane model
model_1 := [81*x^6*y^12+1480*x^4*y^14+225*x^2*y^16+4536*x^5*y^12*z-4020*x^3*y^14*z+225*x*y^16*z+16800*x^4*y^12*z^2-3145*x^2*y^14*z^2-225*y^16*z^2-10530*x^5*y^10*z^3+21921*x^3*y^12*z^3+335*x*y^14*z^3+77670*x^4*y^10*z^4-26377*x^2*y^12*z^4+1790*y^14*z^4+1620*x^5*y^8*z^5+41450*x^3*y^10*z^5-3901*x*y^12*z^5+10935*x^4*y^8*z^6+79240*x^2*y^10*z^6+3476*y^12*z^6+176790*x^3*y^8*z^7-34315*x*y^10*z^7+16200*x^4*y^6*z^8+3215*x^2*y^8*z^8-26185*y^10*z^8-40275*x^3*y^6*z^9+86730*x*y^8*z^9-2025*x^4*y^4*z^10+208925*x^2*y^6*z^10-83435*y^8*z^10-40500*x^3*y^4*z^11-177200*x*y^6*z^11+31800*x^2*y^4*z^12+38400*y^6*z^12+43375*x*y^4*z^13+12375*x^2*y^2*z^14-11900*y^4*z^14+62250*x*y^2*z^15+43625*y^2*z^16-15625*z^18];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 35.80.5.a.1
//   Coordinate number 0:
map_0_coord_0 := 1*(x);
//   Coordinate number 1:
map_0_coord_1 := 1*(-y);
//   Coordinate number 2:
map_0_coord_2 := 1*(w);
//   Coordinate number 3:
map_0_coord_3 := 1*(y+w-v);
//   Coordinate number 4:
map_0_coord_4 := 1*(t);
// Codomain equation:
map_0_codomain := [2*x*y-3*x*z-y*z+x*w,x*y-y^2+x*z+y*z+z^2-2*x*w-3*y*w+z*w-w^2,x^2-2*x*y-x*z+y*z+4*z^2-x*w-x*t+2*y*t-2*z*t+3*w*t+t^2];

// Map from the canonical model to the plane model of modular curve with label 70.160.11.g.1
//   Coordinate number 0:
map_1_coord_0 := 1*(b);
//   Coordinate number 1:
map_1_coord_1 := 1*(t);
//   Coordinate number 2:
map_1_coord_2 := 1*(r);
// Codomain equation:
map_1_codomain := [81*x^6*y^12+1480*x^4*y^14+225*x^2*y^16+4536*x^5*y^12*z-4020*x^3*y^14*z+225*x*y^16*z+16800*x^4*y^12*z^2-3145*x^2*y^14*z^2-225*y^16*z^2-10530*x^5*y^10*z^3+21921*x^3*y^12*z^3+335*x*y^14*z^3+77670*x^4*y^10*z^4-26377*x^2*y^12*z^4+1790*y^14*z^4+1620*x^5*y^8*z^5+41450*x^3*y^10*z^5-3901*x*y^12*z^5+10935*x^4*y^8*z^6+79240*x^2*y^10*z^6+3476*y^12*z^6+176790*x^3*y^8*z^7-34315*x*y^10*z^7+16200*x^4*y^6*z^8+3215*x^2*y^8*z^8-26185*y^10*z^8-40275*x^3*y^6*z^9+86730*x*y^8*z^9-2025*x^4*y^4*z^10+208925*x^2*y^6*z^10-83435*y^8*z^10-40500*x^3*y^4*z^11-177200*x*y^6*z^11+31800*x^2*y^4*z^12+38400*y^6*z^12+43375*x*y^4*z^13+12375*x^2*y^2*z^14-11900*y^4*z^14+62250*x*y^2*z^15+43625*y^2*z^16-15625*z^18];
