
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 70.160.11.h.1

// Other names and/or labels
// Cummins-Pauli label: 70B11
// Rouse-Sutherland-Zureick-Brown label: 70.160.11.1

// Group data
level := 70;
// Elements that, together with Gamma(level), generate the group
gens := [[7, 43, 6, 33], [10, 47, 23, 0], [11, 36, 6, 23], [49, 9, 4, 51]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 160;

// Curve data
conductor := [[2, 12], [5, 22], [7, 11]];
bad_primes := [2, 5, 7];
// Genus
g := 11;
// Rank
r := 4
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 4
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-7];
// Modular curve is a fiber product of the following curvesfactors := ['7.8.0.a.1', '10.20.0.b.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["10.20.0.b.1", "35.80.5.a.1"];

// Models for this modular curve, if computed
Pol<x,y,z,w,t,u,v,r,s,a,b> := PolynomialRing(Rationals(), 11);
// Isomorphic to P^1?
is_P1 := false;

// Canonical model
model_0 := [x*u+y*v+y*r+z*u,2*v^2-2*v*r-v*s-v*b-r*b,u*v+u*b-v^2+v*s-v*a+2*v*b,y*u+2*y*v-z*v+z*r+t*r,x*u-y*u-y*v+z*v-t*u-t*v+t*r,x*v-2*z*v+w*v+w*b,2*x*u+x*v-x*r+z*v+w*r+w*a-t*v-t*r,y*r+y*a+z*v+z*r+z*a+z*b-t*v-t*b,x*v+y*u+y*v-y*r+z*u-z*r+w*v+w*b-t*v,x*u-2*z*u+w*v-w*s+w*a-2*w*b,x*y+2*x*z+x*t-y*z,2*u*v-u*r-u*s-u*b-v*r+r*s-r*a+2*r*b,2*x*t+2*y^2-y*z+y*t-z^2+z*t-t^2-v*r-r*b,2*x*y-x*z-x*t+y^2-y*z+2*y*t-2*z^2-v*r-r*b,x*z-x*t+y*z-y*t+2*z^2-2*t^2-v*r-v*a,2*y*w-2*z*w-w*t-u*v-u*r-v^2-v*r,x*u+x*v+x*r+x*a-y*u+y*r+y*a-z*a+z*b-w*u-w*a+w*b+t*u+t*r-t*b,5*x^2+3*x*y-x*z-2*y^2-y*z-y*t-z^2+3*z*t+t^2+2*v*r+v*a+r^2+r*a+r*b,4*x^2+x*w-2*x*t-2*y^2+y*z+2*y*t-2*z*w+z*t-w^2+2*t^2-u^2-u*v-u*s+v*s+2*v*a-r*s+r*a-2*r*b-s^2-s*b,x^2+x*y-2*x*z-x*w+x*t-y*z+2*y*w+4*z^2+w^2-w*t+u^2-u*r+u*s+v^2+v*a-v*b-r*s+r*a-r*b,x*y-x*z+2*y*t+2*z*t-t^2-u^2-u*v+u*r-u*a+2*u*b+v^2+v*r-2*v*s-3*v*a+v*b+r*s-r*a+r*b+s^2+2*s*b-a^2-a*b+b^2,5*x^2-x*y-x*z+x*t-y^2+y*z+2*y*t-z^2-2*t^2-u^2-u*s-u*a-v^2-v*r-v*a-v*b+r*s-r*a+r*b+s*b-a^2-a*b+b^2,x^2-x*y+2*x*z-x*w+3*y*t-z^2+2*z*w-2*z*t+w^2+t^2+u^2+u*s-u*a-2*u*b+2*v^2+v*a-r^2-r*s-r*b-s*a-s*b,x^2+x*y+x*z-x*w+2*y*w+2*z^2+4*z*t+w^2-w*t+u^2+u*v+u*s+u*a+u*b+v*s+2*v*a+v*b,3*y*w+2*z*w+w*t+v^2+v*r,y*w-z*w+2*w*t+u^2-u*r+u*s+v^2+v*a-v*b-r*s+r*a-r*b,x*v+x*r-x*b-y*u-y*a+z*v-z*a+z*b-w*r-w*a-w*b+t*r+t*b,x*u+x*v+x*s-x*a+x*b+y*v-z*u+z*v-2*z*a+z*b-w*b+t*v-t*s,x*u+x*v+x*s-x*a+x*b-y*u+y*v-y*s-y*b+z*v-z*r-z*a-w*b+t*u-t*r+t*a+t*b,2*x*v+x*b+y*u+y*a+z*u+z*a-z*b-w*v+t*v-t*b,x*u-x*v+2*x*s-x*a-x*b+y*u+2*z*r-z*s+z*a-z*b-w*v+w*r-t*r+t*s,x*u-x*r-x*s-y*v+y*a+z*u-2*z*v+2*z*s+z*a+z*b-w*v+w*a+t*r-t*b,x*v+x*s+2*x*b+2*y*u-y*v+y*r+y*s+z*u+z*r-z*s+z*a-z*b+w*r+w*b-t*v-t*r+t*s,x*y+x*z+y^2+3*y*z+2*y*t+2*z^2+2*z*t+v^2+v*b,x*y+x*t-3*y^2+2*y*t+z^2+3*z*t+t^2+u^2+u*v-u*r+2*u*a-u*b-v*r+2*v*s+2*v*a+v*b+r^2+r*a-s^2+s*a-2*s*b+a^2+a*b-b^2,5*x*w+u^2-u*v-2*u*r+u*s+v*a-v*b+r^2-r*s+r*a-r*b];

// Maps from this modular curve, if computed

// Map from the canonical model to the canonical model of modular curve with label 35.80.5.a.1
//   Coordinate number 0:
map_0_coord_0 := 1*(x);
//   Coordinate number 1:
map_0_coord_1 := 1*(-y);
//   Coordinate number 2:
map_0_coord_2 := 1*(z);
//   Coordinate number 3:
map_0_coord_3 := 1*(y+z-t);
//   Coordinate number 4:
map_0_coord_4 := 1*(w);
// Codomain equation:
map_0_codomain := [2*x*y-3*x*z-y*z+x*w,x*y-y^2+x*z+y*z+z^2-2*x*w-3*y*w+z*w-w^2,x^2-2*x*y-x*z+y*z+4*z^2-x*w-x*t+2*y*t-2*z*t+3*w*t+t^2];
