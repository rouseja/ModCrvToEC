
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 70.210.15.c.1

// Other names and/or labels
// Cummins-Pauli label: 70A15
// Rouse-Sutherland-Zureick-Brown label: 70.210.15.4

// Group data
level := 70;
// Elements that, together with Gamma(level), generate the group
gens := [[1, 37, 51, 28], [13, 45, 24, 29], [29, 4, 48, 41]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 210;

// Curve data
conductor := [[2, 16], [5, 30], [7, 30]];
bad_primes := [2, 5, 7];
// Genus
g := 15;
// Rank
r := 8
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 3
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["35.105.7.a.1", "70.42.1.b.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
