
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 70.30.1.b.1

// Other names and/or labels
// Cummins-Pauli label: 10E1
// Rouse-Sutherland-Zureick-Brown label: 70.30.1.2

// Group data
level := 70;
// Elements that, together with Gamma(level), generate the group
gens := [[9, 29, 45, 62], [17, 13, 14, 33], [21, 69, 10, 29]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 30;

// Curve data
conductor := [[2, 2], [5, 1], [7, 2]];
bad_primes := [2, 5, 7];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 3
;// Number of rational cusps
Nrat_cusps := 1
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["5.15.0.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
