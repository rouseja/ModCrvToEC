
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 70.378.24.a.1

// Other names and/or labels
// Cummins-Pauli label: 70A24
// Rouse-Sutherland-Zureick-Brown label: 70.378.24.1

// Group data
level := 70;
// Elements that, together with Gamma(level), generate the group
gens := [[37, 44, 16, 15], [41, 55, 48, 3], [51, 22, 50, 33], [59, 13, 20, 7], [63, 60, 52, 21]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 378;

// Curve data
conductor := [[2, 12], [5, 20], [7, 48]];
bad_primes := [2, 5, 7];
// Genus
g := 24;
// Rank
r := 7
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 12
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Modular curve is a fiber product of the following curvesfactors := ['2.3.0.a.1', '5.6.0.a.1', '7.21.0.a.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["10.18.0.a.1", "14.63.2.a.1", "35.126.6.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
