
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 70.42.1.a.1

// Other names and/or labels
// Cummins-Pauli label: 14E1
// Rouse-Sutherland-Zureick-Brown label: 70.42.1.1

// Group data
level := 70;
// Elements that, together with Gamma(level), generate the group
gens := [[5, 39, 53, 38], [13, 54, 55, 43], [44, 25, 37, 47]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 42;

// Curve data
conductor := [[2, 2], [5, 2], [7, 2]];
bad_primes := [2, 5, 7];
// Genus
g := 1;
// Rank
r := 0
;// Exact gonality known
gamma := 2;

// Modular data
// Number of cusps
Ncusps := 3
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["7.21.0.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
