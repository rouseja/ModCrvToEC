
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 70.420.29.c.1


// Group data
level := 70;
// Elements that, together with Gamma(level), generate the group
gens := [[11, 31, 24, 27], [15, 61, 26, 55], [59, 10, 55, 39], [63, 17, 3, 30]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 420;

// Curve data
conductor := [[2, 32], [5, 49], [7, 58]];
bad_primes := [2, 5, 7];
// Genus
g := 29;
// Rank
r := 17
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 6
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["35.210.13.a.1", "70.42.1.b.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
