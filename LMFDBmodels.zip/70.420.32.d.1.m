
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 70.420.32.d.1


// Group data
level := 70;
// Elements that, together with Gamma(level), generate the group
gens := [[15, 3, 28, 55], [20, 51, 51, 15], [32, 7, 63, 4], [69, 8, 22, 51]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 420;

// Curve data
conductor := [[2, 38], [5, 64], [7, 58]];
bad_primes := [2, 5, 7];
// Genus
g := 32;
// Rank
r := 22
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 6
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["35.210.13.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
