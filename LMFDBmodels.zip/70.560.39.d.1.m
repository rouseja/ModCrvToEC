
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 70.560.39.d.1


// Group data
level := 70;
// Elements that, together with Gamma(level), generate the group
gens := [[39, 60, 2, 41], [40, 29, 9, 2], [57, 64, 32, 33], [63, 43, 11, 32]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 560;

// Curve data
conductor := [[2, 42], [5, 76], [7, 67]];
bad_primes := [2, 5, 7];
// Genus
g := 39;
// Rank
r := 32
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 8
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-3, -27];
// Modular curve is a fiber product of the following curvesfactors := ['5.10.0.a.1', '14.56.1.b.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["14.56.1.b.1", "35.280.18.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
