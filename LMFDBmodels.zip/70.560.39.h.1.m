
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 70.560.39.h.1


// Group data
level := 70;
// Elements that, together with Gamma(level), generate the group
gens := [[20, 63, 17, 50], [23, 66, 45, 47], [31, 5, 55, 46], [33, 19, 62, 67]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 560;

// Curve data
conductor := [[2, 42], [5, 78], [7, 67]];
bad_primes := [2, 5, 7];
// Genus
g := 39;
// Rank
r := 32
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 8
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-3, -27];
// Modular curve is a fiber product of the following curvesfactors := ['7.28.0.a.1', '10.20.0.b.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["10.20.0.b.1", "35.280.18.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
