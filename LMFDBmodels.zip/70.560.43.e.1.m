
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 70.560.43.e.1


// Group data
level := 70;
// Elements that, together with Gamma(level), generate the group
gens := [[3, 49, 49, 66], [5, 36, 46, 37], [25, 34, 6, 45], [32, 37, 57, 66]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 560;

// Curve data
conductor := [[2, 50], [5, 86], [7, 75]];
bad_primes := [2, 5, 7];
// Genus
g := 43;
// Rank
r := 17
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 8
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["35.280.18.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
