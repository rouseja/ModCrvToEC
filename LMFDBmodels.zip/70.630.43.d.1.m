
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 70.630.43.d.1


// Group data
level := 70;
// Elements that, together with Gamma(level), generate the group
gens := [[12, 53, 25, 3], [33, 9, 51, 32], [53, 25, 36, 17], [69, 69, 68, 1]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 630;

// Curve data
conductor := [[2, 48], [5, 69], [7, 86]];
bad_primes := [2, 5, 7];
// Genus
g := 43;
// Rank
r := 34
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 9
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-4, -11];
// Modular curve is a fiber product of the following curvesfactors := ['5.15.0.a.1', '14.42.1.b.1']
// Groups containing given group, corresponding to curves covered by given curve
covers := ["35.315.19.a.1", "70.210.15.d.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
