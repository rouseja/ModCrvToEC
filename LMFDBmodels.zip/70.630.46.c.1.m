
// Modular curves downloaded from the LMFDB on 30 December 2025.
// Magma code for modular curve with label 70.630.46.c.1


// Group data
level := 70;
// Elements that, together with Gamma(level), generate the group
gens := [[13, 13, 40, 29], [23, 30, 25, 33], [28, 5, 61, 57], [37, 45, 10, 67]];
// Group contains -1?
ContainsMinus1 := true;
// Index in Gamma(1)
index := 630;

// Curve data
conductor := [[2, 54], [5, 77], [7, 82]];
bad_primes := [2, 5, 7];
// Genus
g := 46;
// Rank
r := 26
;// Exact gonality known
gamma := None;

// Modular data
// Number of cusps
Ncusps := 9
;// Number of rational cusps
Nrat_cusps := 0
;// CM discriminants
CM_discs := [-4];
// Groups containing given group, corresponding to curves covered by given curve
covers := ["35.315.19.a.1"];

// Models for this modular curve, if computed
// Isomorphic to P^1?
is_P1 := false;

// Maps from this modular curve, if computed
